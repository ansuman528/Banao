require('dotenv').config();
const cors = require("cors");
const express = require('express');
const cron = require('node-cron');
const app = express();
const port = process.env.PORT || 8000;
const utility=require("./server/utility/utility.js");
// middle wares
const corsOptions = {
  origin: "*",
  credentials: true,
  optionSuccessStatus: 200,
};
const session = require("express-session");

//use cors
app.use(cors(corsOptions)); 

// Initialize session middleware
app.use(
  session({
    token:"",
    secret: "your-secret-key",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: true },
  })
);

// connecting DB
const sequelize = require("./server/database/connection");

const expressLayouts = require("express-ejs-layouts");
const formData = require('express-form-data');
var cookieParser = require('cookie-parser')
const bodyParser = require('body-parser');

sequelize.sync().then(()=>{
    console.log("DB is Ready");
});

// app.use(express.json());
// app.use(express.urlencoded({extended:false}));
app.use(cors(corsOptions));
app.use(expressLayouts);
app.use(formData.parse());
app.use(cookieParser())

app.use(express.json({limit: '50mb'}));
app.use(express.urlencoded({limit: '50mb', extended: true, parameterLimit: 1000000}));


//adding middlewares
app.use(function (req, res, next) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');
    

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type,auth');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);
    
    // Pass to next layer of middleware
    next();
});
app.set("view engine", "ejs");
// load routers
app.use('/', require('./server/routes/router'));
app.use('/', require('./server/routes/PP_Router'));
cron.schedule('*/30 * * * *',async () => {
    await utility.runPeople();
    console.log('country codes updated');
  });
// listening port
app.listen(port, ()=>{
    console.log(`server is runnning at ${port}`);
})

import React , {useState , useEffect} from 'react'
import '../components/home.css'
import axios from 'axios'

const Home = () => {
    const [data , setData]= useState([])
    const [records , setRecord] = useState([])
    useEffect(()=>{
        axios.get('https://jsonplaceholder.typicode.com/users')
        .then(res =>{
            setData(res.data)
            setRecord(res.data)
        })
        .catch(err => console.log(err))
    },[])
    const Filter = (event) =>{
        setRecord(data.filter(f => f.name.toLowerCase().includes(event.target.value)))
    }
    return (
        <div>
            <h1>Website Details</h1>
            <input type="text" placeholder='Search' className='form-control' onChange={Filter} />
            <br></br>
            <br></br>
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">Name</th>
                        <th scope="col">Total Crawled</th>
                        <th scope="col">Total Scraped</th>
                        <th scope="col">Crawled Today</th>
                        <th scope="col">Scraped Today</th>
                        <th scope="col">Edit</th>
                    </tr>
                </thead>
                <tbody>
                    {records.map((d,i) => (
                    <tr key={i}>
                        <td>{d.name}</td>
                        <td>10000</td>
                        <td>1000</td>
                        <td>2000</td>
                        <td>3000</td>
                        <td>Edit</td>
                    </tr>
                    ))}
                 
                </tbody>
            </table>
            <br></br>
        </div>
    )
}

export default Home


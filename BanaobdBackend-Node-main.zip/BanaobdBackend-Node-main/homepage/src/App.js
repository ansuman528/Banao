
import './App.css';
import {BrowserRouter as Router , Routes , Route} from 'react-router-dom'
import Home from './components/home'
import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "../node_modules/bootstrap/dist/js/bootstrap.bundle"

function App() {
  return (
    <div>
      <Router>
        <Routes>
          <Route path='/'  element={<Home/>}/>
        </Routes>
      </Router>

    </div>
  );
}

export default App;

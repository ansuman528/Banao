const sequelize = require("../database/connection")
const Sequelize = require("sequelize")
module.exports = sequelize.define("crawling_links",{
    id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      website: {
        type: Sequelize.STRING(100),
        allowNull: false,
       references: {model: 'scraping_website', key: 'url'},
      },
      url_links: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      is_status: {
        type: Sequelize.INTEGER,
      },
      data: {
        type: Sequelize.TEXT,
      },
      created_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      },
      updated_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      }   
},{
    timestamps: false
})
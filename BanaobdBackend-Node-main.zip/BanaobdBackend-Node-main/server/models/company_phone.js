const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("company_phones", {
  id: {
    allowNull: false,
    autoIncrement: true,
    primaryKey: true,
    type: Sequelize.INTEGER(11),
  },
  company_id: {
    type: Sequelize.INTEGER(11),
    references: { model: 'company_details', key: 'id' },
    onUpdate: 'CASCADE',
    onDelete: 'SET NULL',
    primaryKey: true
  },
  phone_id: {
    type: Sequelize.INTEGER(11),
    references: { model: 'phones', key: 'id' },
    onUpdate: 'CASCADE',
    onDelete: 'SET NULL',
    primaryKey: true
  },
}, {
  timestamps: false
});
const sequelize = require("../database/connection")
const Sequelize = require("sequelize")
module.exports = sequelize.define("user_invitation_details",{
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    user_id:{
        allowNull: false,
        refrences:{model: 'users', key: 'id'},
        type: Sequelize.INTEGER(11)
    },
    connection_name:{
        type: Sequelize.STRING(50)
    },
    send_date:{
        type: Sequelize.STRING(20)
    },

},{
    timestamps:false
})
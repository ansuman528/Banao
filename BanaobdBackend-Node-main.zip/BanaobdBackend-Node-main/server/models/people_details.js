const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define(
  "people_details",
  {
    id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: Sequelize.INTEGER(11),
    },
    name:{
      type:Sequelize.STRING(50),
    },
    email: {
      type: Sequelize.STRING(300),
    },
    position: {
      type: Sequelize.STRING(200),
    },
    location: {
      type: Sequelize.STRING(300),
    },
    posts: {
      type: Sequelize.JSON,
    },
    link: {
      type: Sequelize.STRING(50),
    },
    website_link: {
      type: Sequelize.STRING(50),
    },
    number: {
      type: Sequelize.STRING(20),
    },
    about: {
      type: Sequelize.STRING(3000),
    },
    connects: {
      type: Sequelize.STRING(20),
    },
    education: {
      type: Sequelize.JSON,
    },
    skills: {
      type: Sequelize.STRING(300),
    },
    experience: {
      type: Sequelize.JSON,
    },
    certification: {
      type: Sequelize.JSON,
    },
    people_id: {
      type: Sequelize.INTEGER(11),
    },
    company_id: {
      type: Sequelize.INTEGER(11),
    },
    cb_rank: {
      type: Sequelize.STRING(50),
    },
    twitter: {
      type: Sequelize.STRING(300),
    },
    linkedin: {
      type: Sequelize.STRING(300),
    },
    facebook: {
      type: Sequelize.STRING(300),
    },
    gender: {
      type: Sequelize.STRING(50),
    },
    priority:{
        type: Sequelize.INTEGER(11),
        defaultValue: 0
    },
  },
  {
    timestamps: true,
  }
);

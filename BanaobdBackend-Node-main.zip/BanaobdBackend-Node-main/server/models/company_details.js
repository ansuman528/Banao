const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define(
  "company_details",
  {
    id: {
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
      type: Sequelize.INTEGER(11),
    },
    description: {
      type: Sequelize.STRING(5000),
    },
    domain: {
      type: Sequelize.STRING(1000),
    },
    website: {
      type: Sequelize.STRING(200),
    },
    employeeSize: {
      type: Sequelize.STRING(20),
    },
    companyType: {
      type: Sequelize.STRING(50),
    },
    fundingType: {
      type: Sequelize.STRING(50),
    },
    location: {
      type: Sequelize.STRING(100),
    },
    posts: {
      type: Sequelize.JSON,
    },
    companyEmail: {
      type: Sequelize.STRING(100),
    },
    number: {
      type: Sequelize.BIGINT(20),
    },
    rank: {
      type: Sequelize.STRING(20),
    },
    followers: {
      type: Sequelize.INTEGER(10),
    },
    following: {
      type: Sequelize.INTEGER(10),
    },
    headquarter: {
      type: Sequelize.STRING(200),
    },
    founded: {
      type: Sequelize.STRING(10),
    },
    company_id: {
      type: Sequelize.INTEGER(11),
    },
    name:{
      type: Sequelize.STRING(200),
    },
    category:{
      type: Sequelize.STRING(200),
    },
    linkedin:{
      type: Sequelize.STRING(200),
    },
    facebook:{
      type: Sequelize.STRING(200),
    },
    twitter:{
      type: Sequelize.STRING(200),
    },
    instagram:{
      type: Sequelize.STRING(200),
    },
    insta_status:{
      type: Sequelize.INTEGER(1),
      defaultValue: 0
    },
    insta_posts:{
      type: Sequelize.INTEGER(11)
    },
    insta_followers:{
      type: Sequelize.INTEGER(11)
    },
    insta_category:{
      type: Sequelize.STRING(200)
    },
    insta_description:{
      type: Sequelize.STRING(500)
    },
    insta_website:{
      type: Sequelize.STRING(500)
    },
    contact_us:{
      type: Sequelize.STRING(200),
    },
    industry:{
      type: Sequelize.STRING(200),
    },
    play_store:{
      type: Sequelize.STRING(200),
    },
    app_store:{
      type: Sequelize.STRING(200),
    },
    isScraped_linkedin:{
      type : Sequelize.BOOLEAN,
      defaultValue: false
    },
    isScraped_twitter:{
      type : Sequelize.INTEGER(10),
      defaultValue: 0
    },
    priority :{
      type: Sequelize.INTEGER(11),
      defaultValue: 0
    },
    web_location:{
      type: Sequelize.STRING(600),
    },
    crawl_status: {
      type: Sequelize.INTEGER(2),
      defaultValue: 0
    },
    linkedin_api_searched : {
      type: Sequelize.INTEGER(2),
      defaultValue: 0
    },
    tweets: {
      type: Sequelize.JSON,
    },
    gmap_address: {
      type: Sequelize.STRING(255)
    },
    gmap_rating:{
      type: Sequelize.FLOAT(5)
    },
    gmap_num_rating:{
      type: Sequelize.INTEGER(11)
    },
    gmap_status:{
      type: Sequelize.STRING(100)
    }
  },
  {
    timestamps: true,
  }
);

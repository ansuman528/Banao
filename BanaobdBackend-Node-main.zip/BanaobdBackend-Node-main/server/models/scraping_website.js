const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("scraping_website", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
      },
      url:{
        type: Sequelize.STRING(100)
      },
      name:{
        type: Sequelize.STRING(50)
      },
      priority:{
        type: Sequelize.INTEGER(11)
      },
      scrapping_frquency:{
        type: Sequelize.INTEGER(11)
      },
      starting_url:{
        type: Sequelize.STRING(100)
      },
      url_element:{
        type: Sequelize.STRING(50)
      },
      py_script:{
        type: Sequelize.STRING(50)
      },
      pagination_element:{
        type: Sequelize.STRING(50)
      },
      data:{
        type: Sequelize.JSON()
      },
      status:{
        type: Sequelize.INTEGER(11)
      },
    },
    {
    timestamps: false
});
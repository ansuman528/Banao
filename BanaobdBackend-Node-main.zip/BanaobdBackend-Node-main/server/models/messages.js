const sequelize = require("../database/connection")
const Sequelize = require("sequelize")
module.exports = sequelize.define("messages",{
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    user_id:{
        allowNull: false,
        refrences:{model: 'users', key: 'id'},
        type: Sequelize.INTEGER(11),
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
    },
    connection_id:{
        allowNull: false,
        refrences:{model: 'user_connection_details', key: 'id'},
        type: Sequelize.INTEGER(11),
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
    },
    sendDate:{
        type: Sequelize.DATEONLY
    },
    message:{
        type: Sequelize.STRING(500)
    },
    time:{
        type: Sequelize.TIME
    },
    sender:{
        type: Sequelize.STRING(50)
    }

},{
    timestamps:false
})
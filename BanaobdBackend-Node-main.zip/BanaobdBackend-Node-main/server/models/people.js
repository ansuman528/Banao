const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("people", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    url : {
        type: Sequelize.STRING(100),
        unique: true
    },
    name : {
        type: Sequelize.STRING(50),
    },
    status:{
        type: Sequelize.ENUM("not_scraped", "scraped", "processing"),
        defaultValue: "not_scraped"
    },
    source:{
        type: Sequelize.ENUM("Linkedin", "crunchbase", "website"),
        defaultValue: "Linkedin"
    },
    priority:{
        type: Sequelize.INTEGER(11),
        defaultValue: 0
    },
    linkedin_id:{
        type : Sequelize.STRING(20),
    },
    fetch_status:{
        type: Sequelize.INTEGER(11),
        defaultValue: 0
    },
    origin:{
        type: Sequelize.STRING(200),
    },
},{
    timestamps:true
});
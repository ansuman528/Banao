const sequelize = require("../database/connection")
const Sequelize = require("sequelize")

module.exports = sequelize.define("temp-companies",{
    id:{
        type: Sequelize.INTEGER(11),
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
    },
    name:{
        type: Sequelize.STRING(50)
    },
    is_searched:{
        type: Sequelize.BOOLEAN,
    },
    linkedin_profile:{
        type: Sequelize.STRING(200)
    },
    origin:{
        type: Sequelize.STRING(200)
    },
    status: {
        type: Sequelize.INTEGER,
        defaultValue: 0
      },
    },
    {
        timestamps:false
    })
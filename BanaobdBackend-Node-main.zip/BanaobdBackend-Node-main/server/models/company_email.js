const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("company_emails", {
  id: {
    allowNull: false,
    autoIncrement: true,
    primaryKey: true,
    type: Sequelize.INTEGER(11),
  },
  company_id: {
    type: Sequelize.INTEGER(11),
    references: { model: 'companies', key: 'id' },
    onUpdate: 'CASCADE',
    onDelete: 'SET NULL',
    primaryKey: true
  },
  email_id: {
    type: Sequelize.INTEGER(11),
    references: { model: 'emails', key: 'id' },
    onUpdate: 'CASCADE',
    onDelete: 'SET NULL',
    primaryKey: true
  },
}, {
  timestamps: false
});
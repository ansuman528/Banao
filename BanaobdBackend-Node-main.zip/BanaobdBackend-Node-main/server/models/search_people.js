const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("search_peoples", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    url : {
        type: Sequelize.STRING(100),
        unique: true
    },
    name : {
        type: Sequelize.STRING(50),
    },
    status:{
        type: Sequelize.ENUM("not_scraped", "scraped", "processing"),
        defaultValue: "not_scraped"
    },
    source:{
        type: Sequelize.ENUM("Linkedin", "crunchbase"),
        defaultValue: "Linkedin"
    },
    pageCount : {
        type: Sequelize.INTEGER(11),
        defaultValue : 1
    },
},{
    timestamps:false
});
const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("gs_contact", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    group: {
        type:Sequelize.STRING(100)
    },
    location: {
        type: Sequelize.STRING(100)
    },
    email: {
        type: Sequelize.STRING(100)
    },
    phone: {
        type: Sequelize.STRING(20)
    },
    url: {
        type: Sequelize.STRING(500)
    },
    fetch_status:{
        type: Sequelize.BOOLEAN,
        defaultValue: false
    }

}, {
    timestamps: true
});
const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("search_companies", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    url : {
        type: Sequelize.STRING(1000),
        unique: true
    },
    name : {
        type: Sequelize.STRING(500),
    },
    linkedin_id:{
        type : Sequelize.STRING(20),
    },
    source:{
        type: Sequelize.ENUM("Linkedin", "crunchbase"),
        defaultValue: "Linkedin"
    },
    status:{
        type: Sequelize.ENUM("not_scraped", "scraped", "processing"),
        defaultValue: "not_scraped"
    }
},{
    timestamps:false
});
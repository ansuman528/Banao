const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("scrapping_website_logs", {
    id: {
            type: Sequelize.INTEGER,
            primaryKey: true,
            autoIncrement: true
    },
    website: {
      type: Sequelize.STRING(100),
      allowNull: false,
      references: {model: 'scraping_website', key: 'url'},
    },
    log: {
        type: Sequelize.TEXT,
        allowNull: false
      },
      createdAt: {
            type: Sequelize.DATE,
            allowNull: false,
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
          },
          updatedAt: {
            type: Sequelize.DATE,
            allowNull: false,
            defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
          }
});
const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("job_details", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    jobUrl : {
        type: Sequelize.STRING(200),
        unique: true
    },
    jobTitle : {
        type: Sequelize.STRING(100),
    },
    companyName:{
        type : Sequelize.STRING(100),
    },
    location: {
        type: Sequelize.STRING(100),
    },
    datePosted:{
        type : Sequelize.STRING(100),
    },
    activelyHiring:{
        type : Sequelize.BOOLEAN,
        defaultValue: true
    },
    status:{
        type: Sequelize.ENUM("traversed", "not_traversed"),
        defaultValue: "not_traversed"
    }
},{
    timestamps:false
});

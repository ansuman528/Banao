const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("location_details", {
  id: {
    allowNull: false,
    autoIncrement: true,
    primaryKey: true,
    type: Sequelize.INTEGER(11),
  },
  location: {
    type: Sequelize.TEXT(),
    defaultValue : null
  },
  company_id: {
    type: Sequelize.INTEGER(11),
    references: { model: 'companies', key: 'id' },
    onUpdate: 'CASCADE',
    onDelete: 'SET NULL',
    primaryKey: true
  }
}, {
  timestamps: false
});
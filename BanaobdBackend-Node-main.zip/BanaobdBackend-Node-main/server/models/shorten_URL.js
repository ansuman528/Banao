const sequelize = require("../database/connection");
const Sequelize = require("sequelize");

module.exports = sequelize.define("shorten_URL", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    url : {
        type: Sequelize.STRING(100),
        unique: true
    },
    short_url : {
        type: Sequelize.STRING(100),
        unique: true
    },
    created_by : {
        type: Sequelize.STRING(50),
    },
    created_at:{
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
    },
    updated_at:{
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
    },
}, {timestamps: false});


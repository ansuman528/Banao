const sequelize = require("../database/connection")
const Sequelize = require("sequelize")
module.exports = sequelize.define("updated_userStats",{
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    user_id:{
        allowNull: false,
        refrences:{model: 'users', key: 'id'},
        type: Sequelize.INTEGER(11)
    },
    date:{
        allowNull: false,
        type: Sequelize.DATEONLY,
    },
    location:{
        type: Sequelize.STRING(25)
    },
    status:{
        type: Sequelize.STRING(11)
    },
    requestSend:{
        type: Sequelize.INTEGER(11)
    },
    accepted:{
        type: Sequelize.INTEGER(11)
    },
    messaged:{
        type: Sequelize.INTEGER(11),
    },
    extension:{
        type: Sequelize.STRING(50)
    },
    note:{
        type: Sequelize.STRING(50)
    }
},{
    timestamps: false
})
const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("website", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    website: {
        type: Sequelize.STRING(50),
    },
}, {
    timestamps: false
});
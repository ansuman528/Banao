const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("ml_people", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    name: {
        type:Sequelize.STRING(250)
    },
    email: {
        type: Sequelize.STRING(100)
    },
    position: {
        type: Sequelize.STRING(100)
    },
    linkedin: {
      type: Sequelize.INTEGER(11),
      references: { model: 'people', key: 'id' },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL',
    },
    phone: {
        type: Sequelize.STRING(20)
    },
    gs_website_id: {
      type: Sequelize.INTEGER(11),
      references: { model: 'gs_websites', key: 'id' },
      onUpdate: 'CASCADE',
      onDelete: 'SET NULL',
    }

}, {
    timestamps: true
});
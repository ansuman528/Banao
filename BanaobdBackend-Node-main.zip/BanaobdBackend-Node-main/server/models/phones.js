const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("phones", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    phone_no: {
        type: Sequelize.STRING(20),
    },
}, {
    timestamps: false
});
const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("emails", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    email_id: {
        type: Sequelize.STRING(50),
    },
}, {
    timestamps: false
});
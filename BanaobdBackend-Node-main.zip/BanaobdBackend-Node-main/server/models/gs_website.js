const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("gs_website", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    website: {
        type: Sequelize.STRING(200),
    },
    group: {
        type:Sequelize.STRING(100)
    },
    industry:{
        type: Sequelize.STRING(70),
        allowNull: true
    },
    location: {
        type: Sequelize.STRING(100)
    },
    crawl_status: {
        type: Sequelize.INTEGER(2),
        defaultValue: 0
    },
    email_search: {
        type: Sequelize.INTEGER(2),
        defaultValue: 0
    },
    events_found: {
        type: Sequelize.INTEGER(2),
        defaultValue: 0
    },
    jobs_found: {
        type: Sequelize.INTEGER(2),
        defaultValue: 0
    },
    education_found: {
        type: Sequelize.INTEGER(2),
        defaultValue: 0
    },
    contact_us_link: {
        type: Sequelize.TEXT,
        allowNull: true
    },
    web_location: {
        type: Sequelize.TEXT,
        allowNull: true
    },
    contact_us_status: {
        type: Sequelize.STRING(200),
        allowNull: true
    },
    generated_contact_message: {
        type: Sequelize.TEXT(),
        allowNull: true
    },
    fetch_status:{
        type: Sequelize.INTEGER(11),
        defaultValue: 0
    },
    email_fetch_status:{
        type: Sequelize.INTEGER(11),
        defaultValue: 0
    },
    title: {
        type: Sequelize.STRING(300),
        allowNull: true
    },
    priority: {
        type: Sequelize.INTEGER(11),
        allowNull: true
    },
    contact_submitted_on: {
        type: Sequelize.DATE,
        allowNull: true
    },
    rank: {
        type: Sequelize.STRING(20),
        allowNull: true
    },
    twitter: {
        type: Sequelize.STRING(300),
    },
    linkedin: {
        type: Sequelize.STRING(300),
    },
    facebook: {
        type: Sequelize.STRING(300),
    },
    instagram: {
        type: Sequelize.STRING(300),
    },

}, {
    timestamps: true
});
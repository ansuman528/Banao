const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("people_website", {
    id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
    },
    people_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'people', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
    },
    website: {
        type: Sequelize.INTEGER(11),
        references: { model: 'website', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
    },
}, {
    timestamps: false
});
const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("google_search_items", {
    id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
    },
    items: {
        type: Sequelize.STRING(300),
    },
    fetched_status: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
    },
    skill: {
        type: Sequelize.STRING(30),
        defaultValue: null
    }
}, {
    timestamps: false
});
const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("companies", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    bing_search:{
        type: Sequelize.INTEGER(5),
        defaultValue: 0
    },
    url : {
        type: Sequelize.STRING(20),
        unique: true
    },
    name : {
        type: Sequelize.STRING(50),
    },
    searchStatus:{
        type: Sequelize.ENUM("not_searched", "searched", "processing"),
        defaultValue: "not_searched"
    },
    linkedin_id:{
        type : Sequelize.STRING(20),
    },
    status:{
        type: Sequelize.ENUM("not_scraped", "scraped", "processing"),
        defaultValue: "not_scraped"
    },
    people_status:{
        type: Sequelize.INTEGER,
        defaultValue: 0
    },
    source:{
        type: Sequelize.ENUM("Linkedin", "crunchbase", "website", "yourstory"),
        defaultValue: "Linkedin"
    },
    priority :{
        type: Sequelize.INTEGER(11),
        defaultValue: 0
    },
    origin:{
        type: Sequelize.STRING(200),
    },
    fetch_status:{
        type: Sequelize.INTEGER(11),
        defaultValue: 0
    },
    linkedin_api_location_searched : {
        type: Sequelize.INTEGER(2),
        defaultValue: 0
      }
},{
    timestamps:true
});
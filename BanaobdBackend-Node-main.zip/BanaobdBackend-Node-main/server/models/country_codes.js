const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("country_codes", {
  id: {
    allowNull: false,
    autoIncrement: true,
    primaryKey: true,
    type: Sequelize.INTEGER(11),
  },
  country: {
    type: Sequelize.STRING(50),
   
  },
  country_code: {
    type: Sequelize.STRING(5),
  },
  uim_count_0:{
    type:Sequelize.INTEGER(11)
  },
  uim_count_1:{
    type:Sequelize.INTEGER(11)
  },
  uim_count_2:{
    type:Sequelize.INTEGER(11)
  },
  createdAt:{
    allowNull: false,
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  },
  updatedAt:{
    allowNull: false,
    type: Sequelize.DATE,
    defaultValue: Sequelize.NOW
  }
}, {
  timestamps: true
});
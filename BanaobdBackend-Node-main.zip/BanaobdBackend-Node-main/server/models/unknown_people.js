const sequelize = require("../database/connection")
const Sequelize = require("sequelize")
module.exports = sequelize.define("unknown_people",{
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    company_id:{
        allowNull: false,
        references:{model: 'companies', key: 'id'},
        type: Sequelize.INTEGER(11)
    },
    position:{
        type: Sequelize.STRING(50)
    },
    location:{
        type: Sequelize.STRING(22)
    },
    is_scraped:{
        type: Sequelize.INTEGER(11),
        defaultValue: false
    },
})
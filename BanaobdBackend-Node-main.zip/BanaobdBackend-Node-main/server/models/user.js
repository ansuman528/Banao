const sequelize = require("../database/connection");
const Sequelize = require("sequelize");
module.exports = sequelize.define("users", {
    id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    name : {
        type: Sequelize.STRING(50),
    },
    token:{
        type: Sequelize.STRING(50),
    },
    location:{
        type: Sequelize.STRING(50)
    },
    status:{
        type: Sequelize.ENUM("Active", "Blocked"),
        defaultValue: "Blocked"
    },
    type:{
        type: Sequelize.ENUM("Normal", "Captain", "Admin"),
        defaultValue:"Normal"
    },
    captain:{
        type: Sequelize.STRING(50),
    },
    last_company_scraped:{
        type: Sequelize.TEXT(),
        defaultValue: null
    },
    scrapeCount : {
        type: Sequelize.INTEGER(11),
        defaultValue : 0
    },
    peopleScrapeCount : {
        type: Sequelize.INTEGER(11),
        defaultValue : 0
    },
   
    CompanyCount : {
        type: Sequelize.INTEGER(11),
        defaultValue : 10
    },
    createdAt: {
        allowNull: true,
        type: Sequelize.DATE
    },
    last_scraped: {
        allowNull: true,
        type:  Sequelize.DATE
    },
     crunchbasePeopleCount : {
        type: Sequelize.INTEGER(11),
        defaultValue : 0
    },
    location:{
        type: Sequelize.STRING(50),
    },
    email:{
        type: Sequelize.STRING(80),
    }
},{
    timestamps:false,
    updatedAt: 'last_scraped'
});
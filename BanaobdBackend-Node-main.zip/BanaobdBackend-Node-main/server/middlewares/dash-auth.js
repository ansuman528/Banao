const userModel = require("../models/user");

const verifyTokenDash = async(req, res, next)=>{
    try{
        console.log("inside middleware")
        const reqToken = req.cookies.token;
        console.log(reqToken);
        const User =  await userModel.findAll({where:{token: reqToken}});
        console.log(User);
        if(User[0].status === "Active"){
            next();
        }else{
            console.log("user blocked")
            res.render("login", {layout:false, "message": "You are blocked"});
        }
    }catch(error){
        console.log("user blocked inside catch block");
        res.render("login", {layout:false, "message": "You are blocked"});
    }
}

module.exports = verifyTokenDash;

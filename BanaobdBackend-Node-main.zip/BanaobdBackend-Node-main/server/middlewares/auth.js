const userModel = require("../models/user");

const verifyToken = async(req, res, next)=>{
    try{
        console.log("inside middleware")
        const reqToken = req.headers['auth'];
        console.log(reqToken);
        const User =  await userModel.findAll({where:{token: reqToken}});
        console.log(User);
        if(User[0].status === "Active"){
            next();
        }else{
            console.log("user blocked")
            res.status(200).json("User Blocked");
        }
    }catch(error){
        console.log("user blocked inside catch block");
        res.status(200).json("User Blocked")
    }
}

module.exports = verifyToken;

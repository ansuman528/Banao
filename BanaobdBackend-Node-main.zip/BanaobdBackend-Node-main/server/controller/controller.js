const config = require("../models/config");
const company = require("../models/company");
const companyDetails = require("../models/company_details");
const People = require("../models/people");
const peopleDetails = require("../models/people_details");
const userModel = require("../models/user");
const worksIn = require("../models/worksIn");
const searchPeople = require("../models/search_people");
const emailsTable = require("../models/emails");
const companyEmails = require("../models/company_email");
const peopleEmails = require("../models/people_email");
const websiteTable = require("../models/website");
const companyWebsite = require("../models/companyWebsite");
const peopleWebsite = require("../models/peopleWebsite");
const userStats = require("../models/user_stats")
const dashboard = require("../models/updated_userStats")
const messagesModel = require("../models/messages")
const unknownPeople = require("../models/unknown_people")
const emailvalidator = require("email-validator");
const searchComp = require("../models/search_company");
const jobs = require("../models/jobs_details");
const tempCompanies = require("../models/temp_companies");
const sequelize = require("sequelize");
const locationDetails = require("../models/location_details");
const people = require("../models/people");
const shortenUrl = require("../models/shorten_URL");
const excel = require("exceljs");
const path = require("path");
const fs = require("fs");
const fs_extra = require("fs-extra");
const user1 = require("../models/user1");
const Op = sequelize.Op;
const googlePeople = require("../models/google_peoples");
const googleSearchItems = require("../models/google_search_items");
const gsWebsite = require("../models/gs_website");
const gsContact = require("../models/gs_contact");
const mlPeople = require("../models/ml_people");
const yourStory = require("../models/your_story");
const userConnectionDetails = require("../models/user_connection_details")
const userInvitationDetails = require("../models/user_invitation_details")
const { query } = require("express");
const { stringify } = require("csv-stringify");
const seq = require("../database/connection");
var appRoot = require("app-root-path");
const user = require("../models/user");
const { once } = require("events");
const nlp = require('compromise');
const _ = require('lodash');

const { where, Sequelize } = require("sequelize");
const { globalAgent } = require("http");

// const { where } = require("sequelize");
// const { count } = require("console");
// const { use } = require("../routes/router");

const createCsvWriter = require("csv-writer").createArrayCsvWriter;
const csv = require('fast-csv');
const { type } = require("os");
var Global_id;
var Global_user_id;
var Global_date;
let result = []

// setting Association
company.hasMany(worksIn, { foreignKey: "company_id" });
worksIn.belongsTo(company, { foreignKey: "company_id" });
people.hasMany(worksIn, { foreignKey: "people_id" });
worksIn.belongsTo(people, { foreignKey: "people_id" });
people.hasMany(peopleDetails, { foreignKey: "people_id" });
peopleDetails.belongsTo(people, { foreignKey: "people_id" });

people.hasMany(googlePeople, { foreignKey: "people_id" });
googlePeople.belongsTo(people, { foreignKey: "people_id" });
googleSearchItems.hasMany(googlePeople, { foreignKey: "google_search_id" });
googlePeople.belongsTo(googleSearchItems, { foreignKey: "google_search_id" });

gsWebsite.hasMany(mlPeople, { foreignKey: "gs_website_id" });
mlPeople.belongsTo(gsWebsite, { foreignKey: "gs_website_id" });

people.hasMany(peopleWebsite, { foreignKey: "people_id" });
peopleWebsite.belongsTo(people, { foreignKey: "people_id" });
user.hasMany(userStats,{foreignKey: "user_id"})
userStats.belongsTo(user,{foreignKey: "user_id"}) 
user.hasMany(userConnectionDetails,{foreignKey: "user_id"})
userConnectionDetails.belongsTo(user,{foreignKey: "user_id"}) 
user.hasMany(userInvitationDetails,{foreignKey: "user_id"})
userInvitationDetails.belongsTo(user,{foreignKey: "user_id"}) 
user.hasMany(dashboard,{foreignKey: "user_id"})
dashboard.belongsTo(user,{foreignKey: "user_id"}) 
user.hasMany(messagesModel,{foreignKey: "user_id"})
messagesModel.belongsTo(user,{foreignKey: "user_id"}) 
userConnectionDetails.hasMany(messagesModel,{foreignKey: "connection_id"})
messagesModel.belongsTo(userConnectionDetails,{foreignKey: "connection_id"}) 
company.hasMany(unknownPeople,{foreignKey:"company_id"})
unknownPeople.belongsTo(company,{foreignKey:"company_id"})
company.hasOne(companyDetails, { foreignKey: "company_id" });
companyDetails.belongsTo(company, { foreignKey: "company_id" });
// websiteTable.hasOne(gsWebsite, {foreignKey: 'website'})
// gsWebsite.belongsTo(websiteTable, {foreignKey: 'website'})

// defining function for validating url in different api routes
function isValidURL(string) {
  var res = string.match(
    /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)/g
  );
  return res !== null;
}

//get website domain from url
function getDomain(url) {
  url = url.toLowerCase();
  var site_sp = url.split("://");
  var siteWithoutProto;
  var siteWithoutW;
  if (site_sp.length > 1) {
    siteWithoutProto = site_sp[1];
  } else {
    siteWithoutProto = site_sp[0];
  }

  var domain = siteWithoutProto.split("/")[0];
  var siteWithoutWList = domain.split("www.");

  if (siteWithoutWList.length > 1) {
    siteWithoutW = siteWithoutWList[1];
  } else {
    siteWithoutW = siteWithoutWList[0];
  }

  return siteWithoutW;
}
exports.postDashboard = async (req, res) => {
  try {
    console.log("postDashboard")
    const data = req.body.newObj;
    const loc = req.body.loc;
    if (loc) {
      console.log(loc)
      const findUser = await userModel.findOne({
        where: { token: loc.token }
      })
      const updateLocation = await findUser.update({
        location: loc.location
      })
      const success = await updateLocation.save();
    }
    if (data) {
      // console.log(data)
      const findUser = await userModel.findOne({
        where: { token: data.token }
      })
      // console.log(findUser)
      const findRecord = await dashboard.findOne({
        where: { user_id: findUser.id, date: data.date }
      })
      if (findRecord === null) {

        const addToDashboard = await new dashboard({
          user_id: findUser.id,
          date: data.date,
          note: data.note,
          status: data.status,
        })
        const success = await addToDashboard.save();
      } else {
        const addToDashboard = await findRecord.update({
          user_id: findUser.id,
          date: data.date,
          note: data.note,
          status: data.status,
        })
        const success = await addToDashboard.save();
      }
    }



    // console.log(success)
    res.send("success")

  } catch (e) {
    res.status(500).json(e);

  }
}
function msToTime(duration) {
  let check=duration>(1.5*60*60*1000) 
  let milliseconds = Math.floor((duration % 1000) / 100),
    seconds = Math.floor((duration / 1000) % 60),
    minutes = Math.floor((duration / (1000 * 60)) % 60),
    hours = Math.floor((duration / (1000 * 60 * 60)) % 24);
  hours = (hours < 10) ? "0" + hours : hours;
  minutes = (minutes < 10) ? "0" + minutes : minutes;
  seconds = (seconds < 10) ? "0" + seconds : seconds;

  return {"time":hours + ":" + minutes + ":" + seconds,"check":check};
}
exports.getUserScoreList= async(req,res)=>{
  try{
    let det = []
    // console.log("107")
    const page = req.query.page
    console.log(page)
    const token = req.body.token
    const userDetails =await userModel.findOne({
      where:{token: token}
    })
    if(!userDetails){
      console.log("not found");
      res.status(200).send({"success":false,"message":"Not a valid token"})
    }else{
      const userType = userDetails.type;
    det.push({"userType": userType})
    if(userType === 'Normal'){
      console.log("hello")
        console.log(userDetails)
        result.push({
          "id": userDetails.id,
          "name": userDetails.name,
          "token": userDetails.token,
          "userType":  userDetails.type,
          "captain": userDetails.captain,
          "location": userDetails.location,
        })
        det.push({"result":result})
        result = [];
    }
    else if(userType === 'Captain'){
      
      const { rows, count } = await userModel.findAndCountAll({
        
        where: {status: "Active", captain: token},
        attributes: ['id', 'name','captain','token','type','location'],
        order: [
          ['id', 'ASC'],
        ],
      });
    
      const capUsers = await userModel.findAndCountAll({
        
        where: {status: "Active", captain: token},
        attributes: ['id', 'name','captain','token','type','location'],
        order: [
          ['id', 'ASC'],
        ],
      })
      for(let i=0; i<capUsers.rows.length;i++){
        result.push({
          "id": capUsers.rows[i].id,
          "name": capUsers.rows[i].name,
          "token": capUsers.rows[i].token,
          "userType":  capUsers.rows[i].type,
          "captain": capUsers.rows[i].captain,
          "location": capUsers.rows[i].location,
        })
       
       
      }
      det.push({"result":result})
      result = [];
    }
    else if(userType === 'Admin'){
      const { rows, count } = await userModel.findAndCountAll({
      
        where: {status: "Active"},
        attributes: ['id', 'name','captain','token','type','location'],
        order: [
          ['id', 'ASC'],
        ],
      });
     
      const allUsers = await userModel.findAndCountAll({
       
        where:{status: "Active"},
        attributes: ['id', 'name','captain','token','type','location'],
        order: [
          ['id', 'ASC'],
        ],
      })
      
      for(let i=0; i<allUsers.rows.length;i++){
        result.push({
          "id": allUsers.rows[i].id,
          "name": allUsers.rows[i].name,
          "token": allUsers.rows[i].token,
          "userType":  allUsers.rows[i].type,
          "captain": allUsers.rows[i].captain,
          "location": allUsers.rows[i].location,
        })
      }
      det.push({"result":result})
      result = [];
    }
    res.status(200).send({det})
  }
  }catch(error){
    res.status(500).json(error)
  }
}
exports.getUserScore = async(req,res) =>{
  try{
    let det = []
    // console.log("107")
    const page = req.query.page
    console.log(page)
    const dates = req.body.dates;
    const token = req.body.token
    console.log(req.body.dates)
    const userDetails = await userModel.findOne({
      where: { token: token }
    })
    if (!userDetails) {
      console.log("not found");
      res.status(200).send({ "success": false, "message": "Not a valid token" })
    } else {
      const userType = userDetails.type;
      det.push({ "userType": userType })
      if (userType === 'Normal') {
        console.log("hello")
        det.push({"current_page": +page})
        det.push({"pages": 1})

        await getUserData(dates, userDetails)
        det.push({"result":result})
        result = [];
      }
      else if (userType === 'Captain') {

        const { rows, count } = await userModel.findAndCountAll({
          limit: 10,
          offset: (page - 1) * 10, 
          order: [
            ['id', 'ASC'],
          ],
          where: {status: "Active", captain: token}
          
        });
        const totalPages = Math.ceil(count / 10);
        det.push({"current_page": +page})
        det.push({"pages": totalPages})
        const capUsers = await userModel.findAndCountAll({
          limit: 10,
          offset: (page-1)*10,
          order: [
            ['id', 'ASC'],
          ],
          where: {status: "Active", captain: token}

        })
        for (let i = 0; i < capUsers.rows.length; i++) {
          await getUserData(dates, capUsers.rows[i])
         
         
        }
        det.push({"result":result})
        result = [];
      }
      else if (userType === 'Admin') {
        const { rows, count } = await userModel.findAndCountAll({
          limit: 10,
          order: [
            ['id', 'ASC'],
          ],
          offset: (page - 1) * 10, 
          where: {status: "Active"}
          
        });
        const totalPages = Math.ceil(count / 10);
        det.push({"current_page": +page})
        det.push({"pages": totalPages})
        const allUsers = await userModel.findAndCountAll({
          limit: 10,
          order: [
            ['id', 'ASC'],
          ],
          offset:( page-1)*10,
          where:{status: "Active"}
        })
        // det.push(allUsers.rows[0])
        for (let i = 0; i < allUsers.rows.length; i++) {
          await getUserData(dates, allUsers.rows[i])
         
        }
        det.push({"result":result})
        result = [];
      }
      res.status(200).send({ det })
    }

  } catch (e) {
    res.status(500).json(e)
  }

}
exports.authenticateUser= async(req,res)=>{
    const token = req.body.token
    let userDetails;
    if(token)
    userDetails =await userModel.findOne({
      where:{token: token}
    })
    if(!userDetails){
      console.log("not found");
      res.status(401).send({"success":false,"message":"Not a valid token"})
    }
    else{
      res.status(200).send({"success":true,"message":"Authentication success",data:userDetails})
    }
}
exports.getSpecificUserData = async(req,res)=>{
  try{
   let token=req.body.token
   let dates=req.body.dates
   
   const userDetails =await userModel.findOne({
    where:{token: token}
  })
  await getUserData(dates,userDetails)
  let data=result
  result=[]
  res.status(200).send({"result":data})
  
  }catch(error){
    res.status(500).json(error)
  }
}
async function getUserData(dates, userDet){
  
  for(let j=0;j<dates.length;j++){

    const findDashboard = await dashboard.findOne({
      where: { user_id: userDet.id, date: dates[j] }
    })
    console.log(findDashboard)
    console.log("helloo")
    let status = true
    let msgCount = 0;
    let sendCount = 0;
    let stats = []
    let location = userDet.location
    console.log("122", location)
    const user_con_det = await userConnectionDetails.findAll({
      where: { user_id: userDet.id, accept_date: dates[j] }
    })
    console.log("125", user_con_det.length)
    if (user_con_det.length !== 0) {
      for (let k = 0; k < user_con_det.length; k++) {
        if (!user_con_det[k].isMessaged) {
          status = false;
        }
        else {
          msgCount++;
        }
      }
    }

    // console.log("132",user_con_det)
    // user_con.push(user_con_det) 

    const userstats = await userStats.findAll({
      order: [["createdAt", "DESC"]],
      where: { user_id: userDet.id }
    })

    console.log("144",userstats.length)
    
    let extension = [],tempExt=[]
    for(let k=0;k<userstats.length;k++){
      const dt =(userstats[k].createdAt).toISOString()
      const ut =(userstats[k].updatedAt).toISOString()
      const st=userstats[k].start_time
      const dur=new Date(ut).getTime()-new Date(dt).getTime()

      // console.log(userstats[k])
      if (dt.slice(0, 10) === dates[j]) {
        stats.push(userstats[k])
        if(userstats[k].extensionName && !tempExt.includes(userstats[k].extensionName))
         {
          tempExt.push(userstats[k].extensionName)
          extension.push({"name":userstats[k].extensionName,"dur":msToTime(dur)});
          }
      }else{
        console.log(status, k, "158")
        status = false

      }
    }

    const distinct = (value, index, self) => {
      return self.indexOf(value) === index;
    }

    const ext = extension.filter(distinct)
    // if(ext.length === 0){
    //   ext.push(null)
    // }
    console.log("187", stats.length)
    const findInvitesDet = await userInvitationDetails.findAll({
      where: { user_id: userDet.id, send_date: dates[j] }
    })
    const findConnDet = await userConnectionDetails.findAll({
      where: { user_id: userDet.id, accept_date: dates[j], reqSendThatDay: 1 }
    })
    if (findInvitesDet === null && findConnDet === null) {
      sendCount = 0;
    }
    else if (findInvitesDet === null && findConnDet != null) {
      sendCount = findConnDet.length;
    }
    else if (findInvitesDet != null && findConnDet === null) {
      sendCount = findInvitesDet.length;
    }
    else {
      sendCount = findConnDet.length + findInvitesDet.length;
    }



    console.log("181")
    const LM = sendCount + "/" + user_con_det.length + "/" + msgCount;
    console.log("183")

    // location = stats[stats.length -1].location
    if (sendCount >= 25 && user_con_det.length === msgCount) {
      status = true;
    }
    else {
      status = false;
    }
    if (userstats.length === 0) {
      status = false;
    }


    if (findDashboard === null) {
      console.log(location)
      if (status) {
        const details = {
          "id": userDet.id,
          "name": userDet.name,
          "token": userDet.token,
          "userType":  userDet.type,
          "captain": userDet.captain,
          "date": dates[j],
          "location": location,
          "LM": LM,
          "EM": "___",
          "ext": ext,
          "status": "P",
          "note": null,
          "updated": false
        }
        result.push(details);

      }
      else {
        console.log("hello 325")
        const details = {
          "id": userDet.id,
          "name": userDet.name,
          "token": userDet.token,
          "userType":  userDet.type,
          "captain": userDet.captain,
          "date": dates[j],
          "location": location,
          "LM": LM,
          "EM": "___",
          "ext": ext,
          "status": "A",
          "note": null,
          "updated": false
        }
        result.push(details);
        console.log(result)
      }
    }
    else {
      // console.log("not found")


      const details = {
        "id": userDet.id,
        "name": userDet.name,
        "token":userDet.token,
        "userType":  userDet.type,
        "captain": userDet.captain,
        "date": dates[j],
        "location": location,
        "LM": LM,
        "EM": "___",
        "ext": ext,
        "status": findDashboard.status,
        "note": findDashboard.note,
        "updated": true
      }
      result.push(details);
    }
  }

}
exports.companyWebsites = async (req, res) => {
  try {
    //company email social
    //create company phone table
    var count = req.query.count;
    console.log("count", count);
    if (count == null || count == "") {
      count = 20;
    }

    var sites = await companyDetails.findAll({
      limit: parseInt(count),
    });
    const respones = sites.map(item => { return { 'company_id': item.company_id, 'companyDetails_id': item.id, 'website': item.website } });
    res.json(respones);
  } catch (err) {
    res.json(err);
  }
};

// retrieve data from config table, company table and send json
exports.configCompany = async (req, res) => {
  try {
    const getData = await config.findAll({ raw: true });
    console.log(getData);
    if (getData.length === 0) {
      res.status(200).json(null);
    } else {
      // checking companyCount
      const reqToken = req.headers["auth"];
      const User = await userModel.findOne({
        raw: true,
        where: { token: reqToken },
      });
      let companyCount = User.CompanyCount;

      // checking search company rows
      // const search_company = await searchComp.findAll({ limit: companyCount, where: { status: 'not_scraped', source: "Linkedin" } });
      // if (search_company.length != 0) {
      //     res.status(200).json(search_company);
      //     for (let i = 0; i < search_company.length; i++) {
      //         search_company[i]['status'] = 'processing';
      //         await search_company[i].save();
      //     }
      // } else {
      let fromCompany = [], fromCompanyDetails = [];

      fromCompanyDetails = await companyDetails.findAll({
        order: [["priority", "DESC"]],
        limit: companyCount,
        where: {
          [Op.and]: [
            { isScraped_linkedin: false },
            sequelize.where(sequelize.fn('char_length', sequelize.col('linkedin')), {
              [Op.ne]: 0
            })
          ]
        },
      });
      for (let i = 0; i < fromCompanyDetails.length; i++)
        fromCompanyDetails[i]["table"] = "company_details";
      fromCompanyDetails = []
      fromCompany = await company.findAll({
        order: [["priority", "DESC"]],
        limit: companyCount - fromCompanyDetails.length,
        where: {
          [Op.and]: [
            { status: "not_scraped", source: "Linkedin" },
            sequelize.where(sequelize.fn('char_length', sequelize.col('url')), {
              [Op.ne]: 0
            })
          ]
        },
      });
      for (let i = 0; i < fromCompany.length; i++)
        fromCompany[i]["table"] = "company";

      const getCompany = fromCompanyDetails.concat(fromCompany);
      // console.log(getCompany);
      if (getCompany.length === 0) {
        res.status(200).json(getData);
      } else {
        res.status(201).json(getCompany);
        for (let i = 0; i < getCompany.length; i++) {
          getCompany[i]["status"] = "processing";
          await getCompany[i].save();
        }
      }
      // }
    }
  } catch (error) {
    res.status(500).json(error);
  }
};
// 2nd api
exports.saveCompany = async (req, res) => {
  try {
    const companies = req.body.companies;
    console.log(companies.length);
    for (let i = 0; i < companies.length; i++) {
      try {
        // validating existence in table
        const getCompany = await company.findOne({
          where: { url: companies[i].url },
        });

        if (getCompany === null) {
          // validating url
          if (isValidURL(companies[i]["url"])) {
            const addCompany = await new company({
              url: companies[i]["url"],
              name: companies[i]["name"],
              source: companies[i]["source"],
              linkedin_id: companies[i]["linkedin_id"],
            });
            const saveCompany = await addCompany.save();
          }
        }
      } catch (error) {
        res.status(500).json(`Error raise in saving company:  ${error}`);
      }
    }

    // updating single row of config collection
    const getData = await config.findAll();
    if (getData.length === 0) {
      const newConfig = await new config({
        company_letter: req.body.letter,
        page_no: req.body.page,
      });
      const updateConfig = await newConfig.save();
    } else {
      (getData[0]["company_letter"] = req.body.letter),
        (getData[0]["page_no"] = req.body.page);
      const updateConfig = await getData[0].save();
      // console.log(updateConfig);
    }
    res.status(201).json(true);
  } catch (error) {
    res.status(500).json(error);
  }
};
// 3rd api
exports.companyDetails = async (req, res) => {
  try {
    //we are using url of company to get the company id from company collections
    details = req.body;
    console.log("details", details);
    let arrCount = 0;
    const arr1 = [];
    for (let i = 0; i < details.length; i++) {
      if (details[i] != undefined) {
        try {
          arrCount += 1;
          const checkCompany = await company.findOne({
            where: { url: details[i].url },
          });
          if (checkCompany === null) {
            // validating url
            if (isValidURL(details[i]["url"])) {
              const addCompany = await new company({
                url: details[i]["url"],
                name: details[i]["name"],
                source: details[i]["source"],
                linkedin_id: details[i]["linkedin_id"],
              });
              const saveCompany = await addCompany.save();
            }
          }
          const getCompany = await company.findOne({
            where: { url: details[i].url },
          });
          // getting again this details due to search companies then we will update linkedin_id.
          let id = getCompany.id;
          arr1.push(id);
          getCompany.status = "scraped";
          getCompany.linkedin_id = details[i].linkedin_id;

          if (req.headers['api'] == '1') {
            getCompany.linkedin_api_location_searched = 1;
            let run_id = req.headers['run_id']
            if (run_id) {
              let user_stats_obj = await userStats.findOne({ where:{id:run_id}})
              await user_stats_obj.update({runCount :user_stats_obj.runCount + 1})
            }
          }
          const updatedCompanyStatus = await getCompany.save();
          // console.log("--------------------------------------");
          // console.log("status updated");
          /***  company other attributes added*/

          let num = null;
          if (details[i].number != 0) {
            num = details[i].number;
          }

          // if details already present then we update them with new details.
          const checkDetails = await companyDetails.findOne({
            where: { company_id: getCompany.id },
          });
          if (checkDetails === null) {
            const addDetails = await new companyDetails({
              description: details[i].description,
              website: details[i].website,
              domain: details[i].domain,
              employeeSize: details[i].employeeSize,
              followers: details[i].followers,
              company_id: id,
              headquarter: details[i].headquarters,
              companyType: details[i].companyType,
              fundingType: details[i].fundingType,
              location: details[i].location,
              posts: details[i].posts,
              companyEmail: details[i].companyEmail,
              number: num,
              rank: details[i].rank,
              founded: details[i].founded,
            });
            const detailsAdded = await addDetails.save();
          } else {
            // updating fields
            (checkDetails.description = details[i].description),
              (checkDetails.website = details[i].website),
              (checkDetails.domain = details[i].domain),
              (checkDetails.employeeSize = details[i].employeeSize),
              (checkDetails.followers = details[i].followers),
              (checkDetails.company_id = id),
              (checkDetails.headquarter = details[i].headquarters),
              (checkDetails.companyType = details[i].companyType),
              (checkDetails.fundingType = details[i].fundingType),
              (checkDetails.location = details[i].location),
              (checkDetails.posts = details[i].posts),
              (checkDetails.companyEmail = details[i].companyEmail),
              (checkDetails.number = num),
              (checkDetails.rank = details[i].rank),
              (checkDetails.founded = details[i].founded);
            await checkDetails.save();
          }
          // console.log("--------------------------------------");
          // console.log("status updated");
          // console.log("---------------------------------->")
          // console.log(` emails checking:  ${details[i].companyEmail.length}`);
          if ( details[i].companyEmail != null &&
            details[i].companyEmail.length != 0 &&
            emailvalidator.validate(details[i].companyEmail)
          ) {
            try {
              const findEmails = await emailsTable.findOne({
                where: { email_id: details[i].companyEmail },
              });
              let emailsTable_id = null;
              // checking for already existence
              if (findEmails === null) {
                const addingEmail = await new emailsTable({
                  email_id: details[i].companyEmail,
                });
                const emailSaved = await addingEmail.save();
                emailsTable_id = emailSaved.id;
              } else {
                emailsTable_id = findEmails.id;
              }
              // checking for already existence
              const findCompanyEmail = await companyEmails.findOne({
                where: { company_id: id, email_id: emailsTable_id },
              });
              if (findCompanyEmail === null) {
                const addingCompanyEmail = await new companyEmails({
                  company_id: id,
                  email_id: emailsTable_id,
                });
                const savingCompanyEmail = await addingCompanyEmail.save();
              }
            } catch (error) {
              console.log("getting error in saving email");
            }
          }

          // console.log("---------------------------------->")
          // console.log(` website checking:  ${details[i].website.length}`);
          if (
            details[i].website != null &&
            details[i].website.length != 0 &&
            isValidURL(details[i].website)
          ) {
            try {
              const findWebsite = await websiteTable.findOne({
                where: { website: details[i].website },
              });
              let websiteTable_id = null;
              // checking for already existence
              if (findWebsite === null) {
                const addingWebsite = await new websiteTable({
                  website: details[i].website,
                });
                const websiteSaved = await addingWebsite.save();
                websiteTable_id = websiteSaved.id;
              } else {
                websiteTable_id = findWebsite.id;
              }
              // checking for already existence
              const findCompanyWebsite = await companyWebsite.findOne({
                where: { company_id: id, website: websiteTable_id },
              });
              if (findCompanyWebsite === null) {
                const addingCompanyWebsite = await new companyWebsite({
                  company_id: id,
                  website: websiteTable_id,
                });
                const savingCompanyWebsite = await addingCompanyWebsite.save();
              }
            } catch (error) {
              console.log("getting error in saving website");
            }
          }

          /** people should be array of object so that we can get url as well as name */
          // console.log("adding peoples in table");
          const requestPeople = details[i].people;
          if ( requestPeople != null && requestPeople.length != 0) {
            for (let i = 0; i < requestPeople.length; i++) {
              try {
                if (requestPeople[i]["url"] != "") {
                  const checkPeople = await People.findOne({
                    where: { url: requestPeople[i]["url"] },
                  });
                  let p_id = null;
                  if (checkPeople == null) {
                    const addPeople = await new People({
                      url: requestPeople[i]["url"],
                      name: requestPeople[i]["name"],
                      source: requestPeople[i]["source"],
                      company_id: id,
                    });
                    const peopleAdded = await addPeople.save();
                    p_id = peopleAdded.id;
                  } else {
                    p_id = checkPeople.id;
                  }
                  let checkPeopleDetails = await peopleDetails.findOne({
                    where: { people_id: p_id }
                  })
                  if (checkPeopleDetails == null) {
                    let addpeopleDetails = await new peopleDetails({
                      people_id: p_id,
                      position: requestPeople[i]["position"],
                      location: requestPeople[i]["location"]
                    })

                    const peopleDetailsAdded = await addpeopleDetails.save()
                  }
                  // adding data in worksIn table
                  console.log("adding work related details.......");
                  try {
                    const checkWorks = await worksIn.findOne({
                      where: {
                        company_id: id,
                        people_id: p_id,
                        Designation: requestPeople[i]["position"],
                      },
                    });
                    if (checkWorks === null) {
                      const addingWork = await new worksIn({
                        company_id: id,
                        people_id: p_id,
                        Designation: requestPeople[i]["position"],
                        from_date: requestPeople[i]["from"],
                        to_date: requestPeople[i]["to"],
                        presently: requestPeople[i]["present"],
                      });
                      const worksAdded = await addingWork.save();
                    }
                    // console.log("details added successfully");
                  } catch (error) {
                    res
                      .status(500)
                      .json(
                        `some error occured during saving data in worksIn table ${error}`
                      );
                  }
                }
              } catch (error) {
                res
                  .status(500)
                  .json(`some error Occured during saving peoples ${error}`);
              }
            }
          }
          const unknownPep = details[i].unknown;
          if (unknownPep != undefined) {
            for (let i = 0; i < unknownPep.length; i++) {
              try {
                // console.log(unknownPep.length)
                const addUnknown = await new unknownPeople({
                  position: unknownPep[i]["position"],
                  location: unknownPep[i]["location"],
                  company_id: id,
                });
                const peopleAdded = await addUnknown.save();
              } catch (error) {
                res.status(500).json(`some error Occured during saving peoples ${error}`)
              }
            }
          }
          console.log("adding details in from search to worksIn.");
          // finding company in search company table.
          if (
            details[i].linkedin_id != undefined ||
            details[i].linkedin_id != null
          ) {
            const findSearchCompany = await searchComp.findOne({
              where: { linkedin_id: details[i].linkedin_id },
            });
            if (findSearchCompany != null) {
              const peoplesWorking = await worksIn.findAll({
                where: { search_company_id: findSearchCompany.id },
              });
              // adding company_id in worksIn table
              for (let i = 0; i < peoplesWorking.length; i++) {
                peoplesWorking[i].company_id = id;
                await peoplesWorking[i].save();
              }
              // destroying search_company_id
              const deletedData = await findSearchCompany.destroy();
            }
          }
        } catch (error) {
          res
            .status(500)
            .json(`some error Occured during saving company details ${error}`);
        }
      }
    }
    // adding companys in user table
    const reqtoken = req.headers["auth"];
    const userData = await userModel.findOne({ where: { token: reqtoken } });
    const oldDate = new Date(userData["last_scraped"]);
    const newDate = new Date();
    // console.log(newDate);
    // console.log(oldDate);
    // checking for updating date
    if (newDate.getFullYear() === oldDate.getFullYear()) {
      if (newDate.getMonth() === oldDate.getMonth()) {
        if (newDate.getDate() === oldDate.getDate()) {
          userData["scrapeCount"] += arrCount;
        } else if (newDate.getDate() > oldDate.getDate()) {
          console.log("inside date checking");
          userData["scrapeCount"] = arrCount;
          userData["last_company_scraped"] = "";
        }
      } else if (newDate.getMonth() > oldDate.getMonth()) {
        console.log("inside month checking");
        userData["scrapeCount"] = arrCount;
        userData["last_company_scraped"] = "";
      }
    } else if (newDate.getFullYear() > oldDate.getFullYear()) {
      console.log("inside year checking");
      userData["scrapeCount"] = arrCount;
      userData["last_company_scraped"] = "";
    }
    // console.log(userData);
    // console.log(arr1.toString());
    userData["last_company_scraped"] += arr1.toString() + ",";
    await userData.save();
    res.status(201).json(`Details added successfully, ${true}`);
  } catch (error) {
    res.status(500).json(`some error Occured in getting request ${error}`);
  }
};
exports.getCompanyInstagram = async (req, res) => {
  try {
    let count = 10;
    let insta_url = []
    const getCompanyDet = await companyDetails.findAll({ where: { insta_status: 0, instagram: { [Op.not]: null }, }, limit: count })
    console.log(getCompanyDet.length);
    if (getCompanyDet.length < count) {
      count = getCompanyDet.length
    }
    for (let i = 0; i < count; i++) {
      insta_url.push(getCompanyDet[i].instagram)
      getCompanyDet[i].insta_status = 1;
      await getCompanyDet[i].save();

    }
    res.send(insta_url)
  } catch (err) {
    res.send(500).json(err)
  }
}
exports.postInstagramDetails = async (req, res) => {
  try {
    const instaDet = req.body;
    console.log(instaDet)

    for (let i = 0; i < instaDet.length; i++) {
      const find = await companyDetails.findOne({ where: { instagram: instaDet[i].instaUrl } })
      console.log(find)
      if (find) {
        find.insta_posts = instaDet[i].posts;
        find.insta_followers = instaDet[i].followers;
        find.insta_category = instaDet[i].category;
        find.insta_description = instaDet[i].description;
        find.insta_website = instaDet[i].website;
        find.insta_status = 2
        await find.save()
      }
    }
    res.send("added")
  } catch (e) {
    res.status(500).json(e)
  }
}
exports.postPeopleSearch = async (req, res) => {
  const peopleDet = req.body;
  console.log(peopleDet)

  for (let i = 0; i < peopleDet.length; i++) {
    const find = await People.findOne({ where: { url: peopleDet[i].url } });
    // console.log(!find)

    let search_company;
    if (peopleDet[i].company_id) {
      search_company = await company.findOne({
        where: { id: peopleDet[i].company_id },
      })
      await search_company.update({searchStatus:"searched"})
    }
    
    let run_id = req.headers['run_id']
    if (run_id) {
      let user_stats_obj = await userStats.findOne({ where:{id:run_id}})
      await user_stats_obj.update({runCount :user_stats_obj.runCount + 1})
    }
    if (!find) {
      const addPep = await new People({
        url: peopleDet[i].url,
        name: peopleDet[i].name,
        status: "not_scraped",
        source: "Linkedin",
        origin: "google",
      });
      const peopleAdded = await addPep.save()

      const userData = await People.findOne({ where: { url: peopleDet[i].url } });
      const addPepDet = await new peopleDetails({
        people_id: userData.id,
        position: peopleDet[i].position
      });
      const pepDetAdded = await addPepDet.save()

      if (search_company) {
        const works = await worksIn.create({
          people_id: userData.id,
          company_id: search_company.id,
          Designation: peopleDet[i].position,
        })
      }
    }

    else {
      const pepDet = await peopleDetails.findOne({ where: { people_id: find.id } })
      if (pepDet) {
        pepDet.position = peopleDet[i].position;
        await pepDet.save();
      }
      else {
        const addPepDet = await new peopleDetails({
          people_id: find.id,
          position: peopleDet[i].position
        });
        const pepDetAdded = await addPepDet.save()
      }

      if (search_company) {
        const works = await worksIn.create({
          people_id: find.id,
          company_id: search_company.id,
          Designation: peopleDet[i].position,
        })
      }
    }


  }
  res.send("added")
}

// peoples apis ->
// 1. config api
exports.configPeople = async (req, res) => {
  try {
    const getPeople = await People.findAll({
      order: [["priority", "DESC"]],

      limit: 10,
      where: {
        [Op.and]: [
          { status: "not_scraped", source: "Linkedin", origin: null },
          sequelize.where(sequelize.fn('char_length', sequelize.col('url')), {
            [Op.ne]: 0
          })
        ]
      },

      limit: 20,
      where: { status: "not_scraped", source: "Linkedin", origin: null },

    });
    if (getPeople.length === 0) {
      const getCompany = await company.findAll({
        order: [["priority", "DESC"]],
        limit: 5,
        where: { people_status: 0, source: "Linkedin" },
      });
      console.log(getCompany);
      res.status(200).json(getCompany);
      // changing people_status to 1 means visited once in company table
      for (let i = 0; i < getCompany.length; i++) {
        getCompany[i]["people_status"] = 1;
        await getCompany[i].save();
      }
    } else {
      res.status(201).json(getPeople);
      for (let i = 0; i < getPeople.length; i++) {
        getPeople[i]["status"] = "processing";
        await getPeople[i].save();
      }
    }
  } catch (error) {
    console.log(error);
    res.status(500).json(error);
  }
};
// 2. saving people api
exports.savePeople = async (req, res) => {
  try {
    const peoples = req.body;
    console.log(peoples);
    console.log(peoples.length);
    for (let i = 0; i < peoples.length; i++) {
      try {
        // validating url
        if (peoples[i] != null) {
          if (isValidURL(peoples[i]["url"])) {
            const addPeople = await new People({
              url: peoples[i]["url"],
              name: peoples[i]["name"],
              company_id: peoples[i]["company_id"],
              source: peoples[i]["source"],
            });
            const savePeople = await addPeople.save();

            // adding details to our worksIn table
            const workPeople = await new worksIn({
              company_id: peoples[i]["company_id"],
              people_id: savePeople.id,
            });
            const saveWork = await workPeople.save();
          }
        }
      } catch (error) {
        // console.log(`Error occured during saving people ${error}`);
        res.status(200).json(`Error occured during saving people ${error}`);
      }
    }
    res.status(201).json(true);
  } catch (error) {
    res.status(500).json(error);
  }
};
// 3rd api for saving people attributes
exports.peopleDetails = async (req, res) => {
  try {
    //console.log("backend", req.body);
    // peoples id is already sended to client they have to sent that id too
    let detailsPeople = req.body;
    // declaring a variable for differentiate crunchbase and linkedin.
    let peopleSource = "Linkedin";
    let pepCount = 0;
    //to count cruncbase people
    let peopleCount = 0;
    // const pepArr = [];
    let edu = null;
    let experi = null;
    let certi = null;
    let peopleId = null;
    for (let i = 0; i < detailsPeople.length; i++) {
      if (detailsPeople[i] != undefined) {
        try {
          // increasing count first
          pepCount += 1;
          const getPeople = await People.findAll({
            where: { id: detailsPeople[i].people_id },
          });
          getPeople[0]["status"] = "scraped";
          getPeople[0]["linkedin_id"] = detailsPeople[i].linkedin_id;
          peopleSource = getPeople[0]["source"];

          await getPeople[0].save();
          // pepArr.push(detailsPeople[i].people_id);

          if (peopleSource == "crunchbase") peopleCount += 1;

          /**** People other attributes added*/
          if (detailsPeople[i].education.length != 0) {
            edu = detailsPeople[i].education;
          }
          if (detailsPeople[i].experience.length != 0) {
            experi = detailsPeople[i].experience;
          }
          if (detailsPeople[i].certification.length != 0) {
            certi = detailsPeople[i].certification;
          }
          peopleId = detailsPeople[i].people_id;
          // checking people details may be already present

          const findDetails = await peopleDetails.findOne({
            where: { people_id: peopleId },
          });
          let personLocation = detailsPeople[i].location;
          if (personLocation == null || personLocation == "") {
            var work = await worksIn.findAll({
              people_id: peopleId
            });
            if (work.length !== 0) {
              work = work[0]
              const company = await companyDetails.findOne({
                company_id: work.company_id
              });
              if (company !== null) {
                try {
                  if (company.location !== null && company.location !== "")
                    personLocation = company.location;
                  else
                    personLocation = company.headquarter;
                } catch (err) {
                  personLocation = null
                }
              }
            }

          }
          if (findDetails === null) {
            const addDetails = await new peopleDetails({
              email: detailsPeople[i].email,
              number: detailsPeople[i].number,
              position: detailsPeople[i].position,
              location: personLocation,
              posts: detailsPeople[i].posts,
              website_link: detailsPeople[i].website,
              people_id: peopleId,
              about: detailsPeople[i].about,
              connects: detailsPeople[i].connects,
              followers: detailsPeople[i].followers,
              education: edu,
              skills: detailsPeople[i].skills,
              experience: experi,
              certification: certi,
              cb_rank: detailsPeople[i].cb_rank,
              twitter: detailsPeople[i].twitter,
              linkedin: detailsPeople[i].linkedin,
              facebook: detailsPeople[i].facebook,
              gender: detailsPeople[i].gender,
            });

            const detailsAdded = await addDetails.save();
            console.log("added details :", addDetails);
          } else {
            findDetails.email = detailsPeople[i].email;
            findDetails.number = detailsPeople[i].number;
            findDetails.position = detailsPeople[i].position;
            findDetails.location = personLocation;
            findDetails.posts = detailsPeople[i].posts;
            findDetails.website_link = detailsPeople[i].website;
            findDetails.people_id = peopleId;
            findDetails.about = detailsPeople[i].about;
            findDetails.connects = detailsPeople[i].connects;
            findDetails.followers = detailsPeople[i].followers;
            findDetails.education = edu;
            findDetails.experience = experi;
            findDetails.certification = certi;
            findDetails.cb_rank = detailsPeople[i].cb_rank
              ? detailsPeople[i].cb_rank
              : null;
            findDetails.twitter = detailsPeople[i].twitter
              ? detailsPeople[i].twitter
              : null;
            findDetails.linkedin = detailsPeople[i].linkedin
              ? detailsPeople[i].linkedin
              : null;
            findDetails.facebook = detailsPeople[i].facebook
              ? detailsPeople[i].facebook
              : null;
            findDetails.gender = detailsPeople[i].gender
              ? detailsPeople[i].gender
              : null;

            if (findDetails.skills == null || findDetails.skills == "") {
              findDetails.skills = detailsPeople[i].skills;
              console.log(findDetails.changed());
              if (findDetails.changed()) {
                await findDetails.save();
              }
            } else {
              var presentSkill = findDetails.skills.split(",");
              var newSkills = detailsPeople[i].skills.split(",");
              newSkills.forEach((item) => {
                if (!presentSkill.includes(item)) {
                  presentSkill.push(item);
                } else {
                  console.log("not pushed element");
                }
              });
              findDetails.skills = presentSkill.toString();
              console.log(findDetails.changed());
              if (findDetails.changed()) {
                await findDetails.save();
              }
            }
          }
        } catch (error) {
          return res
            .status(500)
            .json(`Error occured in saving people details: ${error}`);
        }
      }
    }
    console.log("adding details in users table.");
    console.log(`PepCount : ${pepCount}`);
    // adding companys in user table
    const reqtoken = req.headers["auth"];
    const userData = await userModel.findOne({ where: { token: reqtoken } });
    const oldDate = new Date(userData["last_scraped"]);
    const newDate = new Date();
    console.log(`old Date: ${oldDate}`);
    console.log(`new Date: ${newDate}`);
    // console.log(userData);
    if (newDate.getFullYear() === oldDate.getFullYear()) {
      if (newDate.getMonth() === oldDate.getMonth()) {
        if (newDate.getDate() === oldDate.getDate()) {
          userData["peopleScrapeCount"] += pepCount;
          userData["crunchbasePeopleCount"] += peopleCount;
        } else if (newDate.getDate() > oldDate.getDate()) {
          console.log("inside date checking");
          userData["peopleScrapeCount"] = pepCount;
          userData["crunchbasePeopleCount"] = peopleCount;
        }
      } else if (newDate.getMonth() > oldDate.getMonth()) {
        console.log("inside month checking");
        userData["peopleScrapeCount"] = pepCount;
        userData["crunchbasePeopleCount"] = peopleCount;
      }
    } else if (newDate.getFullYear() > oldDate.getFullYear()) {
      console.log("inside year checking");
      userData["peopleScrapeCount"] = pepCount;
      userData["crunchbasePeopleCount"] = peopleCount;
    }
    await userData.save();
    res.status(201).json(true);
    peopleFunc(detailsPeople);
  } catch (error) {
    res.status(500).json(`some error Occured ${error}`);
  }
};

exports.studentDetails = async (req, res) => {
  try {
    console.log(req.body);
    // peoples id is already sended to client they have to sent that id too
    detailsPeople = req.body;
    // declaring a variable for differentiate crunchbase and linkedin.
    let peopleSource = "Linkedin";
    // console.log(detailsPeople);
    let edu = null;
    let experi = null;
    let certi = null;
    let peopleId = null;
    for (let i = 0; i < detailsPeople.length; i++) {
      if (detailsPeople[i] != undefined) {
        try {
          console.log("inside for loop");
          console.log(detailsPeople[i]);
          let getPeople = await People.findOne({
            where: { url: detailsPeople[i].url },
          });
          if (getPeople === null) {
            console.log("inside if condition");
            const addPeople = await new People({
              url: detailsPeople[i]["url"],
              name: detailsPeople[i]["name"],
              source: detailsPeople[i]["source"],
              priority: 10,
            });
            const savePeople = await addPeople.save();
            console.log(savePeople);
          }
          getPeople = await People.findOne({
            where: { url: detailsPeople[i].url },
          });
          console.log(getPeople);
          // // console.log('setting status');
          // getPeople['linkedin_id'] = detailsPeople[i].linkedin_id;
          // peopleSource = getPeople['source']
          // await getPeople.save();

          detailsPeople[i]["people_id"] = getPeople.id;

          /**** People other attributes added*/
          if (detailsPeople[i].education.length != 0) {
            edu = detailsPeople[i].education;
          }
          if (detailsPeople[i].experience.length != 0) {
            experi = detailsPeople[i].experience;
          }
          if (detailsPeople[i].certification.length != 0) {
            certi = detailsPeople[i].certification;
          }
          peopleId = detailsPeople[i].people_id;
          // checking people details may be already present
          const findDetails = await peopleDetails.findOne({
            where: { people_id: peopleId },
          });
          if (findDetails === null) {
            const addDetails = await new peopleDetails({
              email: detailsPeople[i].email,
              number: detailsPeople[i].number,
              position: detailsPeople[i].position,
              website_link: detailsPeople[i].website,
              location: detailsPeople[i].location,
              people_id: peopleId,
              about: detailsPeople[i].about,
              connects: detailsPeople[i].connects,
              followers: detailsPeople[i].followers,
              education: edu,
              skills: detailsPeople[i].skills,
              experience: experi,
              certification: certi,
              cb_rank: detailsPeople[i].cb_rank,
              twitter: detailsPeople[i].twitter,
              linkedin: detailsPeople[i].linkedin,
              facebook: detailsPeople[i].facebook,
              gender: detailsPeople[i].gender,
            });
            const detailsAdded = await addDetails.save();
          }
          console.log("-----------------------------------------");
          console.log("details saved." + i);
          console.log("-----------------------------------------");
        } catch (error) {
          res
            .status(500)
            .json(`Error occured in saving people details: ${error}`);
          console.log(error);
        }
      }
    }
    res.status(201).json(true);
    peopleFunc(detailsPeople);
  } catch (error) {
    res.status(500).json(`some error Occured ${error}`);
  }
};

// async func for peopleDetails api
const peopleFunc = async (detailsPeople) => {
  console.log("inside people Function");
  for (let i = 0; i < detailsPeople.length; i++) {
    if (detailsPeople[i] != undefined) {
      try {
        let experi = null;
        let peopleId = null;
        let peopleSource = "Linkedin";
        if (detailsPeople[i].experience.length != 0) {
          experi = detailsPeople[i].experience;
        }
        // gettting source of people
        const getPeople = await People.findAll({
          where: { id: detailsPeople[i].people_id },
        });
        peopleSource = getPeople[0]["source"];
        peopleId = detailsPeople[i].people_id;
        if (
          detailsPeople[i].email.length != 0 &&
          emailvalidator.validate(detailsPeople[i].email)
        ) {
          try {
            const findEmails = await emailsTable.findOne({
              where: { email_id: detailsPeople[i].email },
            });
            let emailsTable_id = null;
            // checking for already existence
            if (findEmails === null) {
              const addingEmail = await new emailsTable({
                email_id: detailsPeople[i].email,
              });
              const emailSaved = await addingEmail.save();
              emailsTable_id = emailSaved.id;
            } else {
              emailsTable_id = findEmails.id;
            }
            // checking for already existence
            const findPeopleEmail = await peopleEmails.findOne({
              where: { people_id: peopleId, email_id: emailsTable_id },
            });
            if (findPeopleEmail === null) {
              const addingPeopleEmail = await new peopleEmails({
                people_id: peopleId,
                email_id: emailsTable_id,
              });
              const savingPeopleEmail = await addingPeopleEmail.save();
            }
          } catch (error) {
            console.log("getting error in saving email");
          }
        }

        // adding website into webistes table.
        if (
          detailsPeople[i].website.length != 0 &&
          isValidURL(detailsPeople[i].website)
        ) {
          try {
            const findWebsite = await websiteTable.findOne({
              where: { website: detailsPeople[i].website },
            });
            let websiteTable_id = null;
            // checking for already existence
            if (findWebsite === null) {
              const addingWebsite = await new websiteTable({
                website: detailsPeople[i].website,
              });
              const websiteSaved = await addingWebsite.save();
              websiteTable_id = websiteSaved.id;
            } else {
              websiteTable_id = findWebsite.id;
            }
            // checking for already existence
            const findPeopleWebsite = await peopleWebsite.findOne({
              where: { people_id: peopleId, website: websiteTable_id },
            });
            if (findPeopleWebsite === null) {
              const addingCompanyWebsite = await new peopleWebsite({
                people_id: peopleId,
                website: websiteTable_id,
              });
              const savingCompanyWebsite = await addingCompanyWebsite.save();
            }
          } catch (error) {
            console.log("getting error in saving website");
          }
        }
        console.log("-----------------------------------------");
        console.log("emails website and details saved.");
        // adding details into worksIn table
        if (peopleSource === "Linkedin") {
          if (experi != null) {
            for (let i = 0; i < experi.length; i++) {
              try {
                const testUrl = RegExp(
                  "https://www.linkedin.com/search/results/all/"
                );
                if (!testUrl.test(experi[i].companyUrl)) {
                  // const link_id = experi[i].companyUrl.slice(33,40);
                  var link =
                    experi[i].companyUrl.match(
                      "https://www.linkedin.com/company/(.*)/"
                    ) ||
                    experi[i].companyUrl.match(
                      "https://www.linkedin.com/sales/company/(.*)"
                    );
                  console.log(`link we got ${link}`);
                  var link_id = link[1];

                  console.log(`linkedin_id we got ${link_id}`);
                  const findCompany = await company.findOne({
                    where: { linkedin_id: link_id },
                  });
                  let comp_id = null;
                  let search_comp_id = null;
                  // console.log(findCompany);
                  if (findCompany === null) {
                    const findSearchCompany = await searchComp.findOne({
                      where: { linkedin_id: link_id },
                    });
                    // checking for already existence
                    if (findSearchCompany === null) {
                      console.log("saving in search_companies");
                      const searchCompany = await new searchComp({
                        url: experi[i].companyUrl,
                        name: experi[i].companyName,
                        linkedin_id: link_id,
                      });
                      const saveSearchCompany = await searchCompany.save();
                      search_comp_id = saveSearchCompany.id;
                    } else {
                      search_comp_id = findSearchCompany.id;
                    }
                  } else {
                    console.log("we got company in our companies table");
                    comp_id = findCompany.id;
                  }
                  // adding details in worksIns table
                  console.log("finally adding details into worksins");
                  const findExperi = await worksIn.findOne({
                    where: {
                      company_id: comp_id,
                      people_id: peopleId,
                      search_company_id: search_comp_id,
                    },
                  });
                  // checking for already existence
                  if (findExperi === null) {
                    const peopleWork = await new worksIn({
                      company_id: comp_id,
                      people_id: peopleId,
                      search_company_id: search_comp_id,
                      Designation: experi[i].companyPosition,
                      from_date: experi[i].start,
                      to_date: experi[i].end,
                      presently: experi[i].status,
                    });
                    const savePeopleWork = await peopleWork.save();
                  } else {
                    findExperi.company_id = comp_id;
                    findExperi.people_id = peopleId;
                    findExperi.search_company_id = search_comp_id;
                    findExperi.Designation = experi[i].companyPosition;
                    findExperi.from_date = experi[i].start
                      ? experi[i].start
                      : findExperi.from_date;
                    findExperi.to_date = experi[i].end
                      ? experi[i].end
                      : findExperi.to_date;
                    findExperi.presently = experi[i].status
                      ? experi[i].status
                      : findExperi.presently;
                    console.log(findExperi.changed());
                    if (findExperi.changed()) {
                      await findExperi.save();
                    } else {
                      console.log("No need to run query nothing changed");
                    }
                  }
                }
              } catch (error) {
                console.log(error);
              }
            }
          }
        } else if (peopleSource === "crunchbase") {
          console.log("-----------------------------------------");
          console.log("people from crunchbase");
          if (experi != null) {
            for (let i = 0; i < experi.length; i++) {
              try {
                const findCompany = await company.findOne({
                  where: { url: experi[i].companyUrl, source: "crunchbase" },
                });
                let comp_id = null;
                let search_comp_id = null;
                // console.log(findCompany);
                if (findCompany === null) {
                  const findSearchCompany = await searchComp.findOne({
                    where: { url: experi[i].companyUrl },
                  });
                  // checking for already existence
                  if (findSearchCompany === null) {
                    const searchCompany = await new searchComp({
                      url: experi[i].companyUrl,
                      name: experi[i].companyName,
                      source: peopleSource,
                    });
                    const saveSearchCompany = await searchCompany.save();
                    search_comp_id = saveSearchCompany.id;
                  } else {
                    search_comp_id = findSearchCompany.id;
                  }
                } else {
                  comp_id = findCompany.id;
                }
                // adding details in worksIns table
                const findExperi = await worksIn.findOne({
                  where: {
                    company_id: comp_id,
                    people_id: peopleId,
                    search_company_id: search_comp_id,
                  },
                });
                // checking for already existence
                if (findExperi === null) {
                  const peopleWork = await new worksIn({
                    company_id: comp_id,
                    people_id: peopleId,
                    search_company_id: search_comp_id,
                    Designation: experi[i].position,
                    from_date: experi[i].start,
                    to_date: experi[i].end,
                    presently: experi[i].status,
                  });
                  const savePeopleWork = await peopleWork.save();
                  console.log("-----------------------------------------");
                  console.log("data added in worksin");
                } else {
                  findExperi.company_id = comp_id;
                  findExperi.people_id = peopleId;
                  findExperi.search_company_id = search_comp_id;
                  findExperi.Designation = experi[i].Position;
                  findExperi.from_date = experi[i].start;
                  findExperi.to_date = experi[i].end;
                  findExperi.presently = experi[i].status;
                  await findExperi.save();
                  console.log("-----------------------------------------");
                  console.log("data updated in worksin");
                }
              } catch (error) {
                console.log(error);
              }
            }
          }
        }
      } catch (error) {
        console.log(`Error in async function ${error}`);
      }
    }
  }
};

// crunchbase config api for company extension
exports.configCrunchCompany = async (req, res) => {
  try {
    const reqToken = req.headers["auth"];
    const User = await userModel.findOne({
      raw: true,
      where: { token: reqToken },
    });
    let companyCount = User.CompanyCount;
    const getCompany = await company.findAll({
      limit: 20,
      where: { status: "not_scraped", source: "crunchbase" },
    });
    console.log(getCompany);
    if (getCompany.length === 0) {
      res.status(200).json("No registered company left for scraping");
    } else {
      res.status(201).json(getCompany);
      for (let i = 0; i < getCompany.length; i++) {
        getCompany[i]["status"] = "processing";
        await getCompany[i].save();
      }
    }
  } catch (error) {
    res.status(500).json(error);
  }
};

// curnchbase config api for people api
exports.configCrunchPeople = async (req, res) => {
  try {
    console.log("inside apis");
    const getPeople = await People.findAll({
      limit: 20,
      where: { status: "not_scraped", source: "crunchbase" },
    });
    // console.log(getCompany);
    if (getPeople.length === 0) {
      res.status(200).json("No registered people left for scraping");
    } else {
      res.status(201).json(getPeople);
      for (let i = 0; i < getPeople.length; i++) {
        getPeople[i]["status"] = "processing";
        await getPeople[i].save();
      }
    }
  } catch (error) {
    res.status(500).json(error);
  }
};
// adding another route for saving search people page.
exports.saveSearchPeople = async (req, res) => {
  try {
    const peoples = req.body;
    console.log(peoples);
    console.log(peoples.length);
    for (let i = 0; i < peoples.length; i++) {
      try {
        // validating url
        if (peoples[i] != null) {
          if (isValidURL(peoples[i]["url"])) {
            const addPeople = await new searchPeople({
              url: peoples[i]["url"],
              name: peoples[i]["name"],
              source: peoples[i]["source"],
            });
            const savePeople = await addPeople.save();
          }
        }
      } catch (error) {
        res.status(200).json(`Error occured during saving people ${error}`);
      }
    }
    res.status(201).json(true);
  } catch (error) {
    res.status(500).json(error);
  }
};
// creating config for searchPeople-config
exports.configSearchPeople = async (req, res) => {
  try {
    const getPeople = await searchPeople.findAll({
      limit: 5,
      where: {
        [Op.and]: [
          { status: "not_scraped", source: "Linkedin" },
          sequelize.where(sequelize.fn('char_length', sequelize.col('url')), {
            [Op.ne]: 0
          })
        ]
      },
    });
    console.log(getPeople);
    if (getPeople.length === 0) {
      res.status(200).json("No registered search people left for scraping");
    } else {
      res.status(201).json(getPeople);
      for (let i = 0; i < getPeople.length; i++) {
        getPeople[i]["status"] = "processing";
        await getPeople[i].save();
      }
    }
  } catch (error) {
    res.status(500).json(error);
  }
};

// api for saving jobs
exports.saveJobs = async (req, res) => {
  try {
    jobDetails = req.body.jobDetailsArr;
    console.log(jobDetails);
    for (let i = 0; i < jobDetails.length; i++) {
      if (jobDetails[i] != undefined) {
        const getjobs = await jobs.findOne({
          where: { jobUrl: jobDetails[i].jobUrl },
        });
        console.log("searching in jobs");
        // console.log(getjobs.jobUrl)
        if (getjobs === null) {
          console.log("adding in jobs");
          const createJob = await new jobs({
            jobUrl: jobDetails[i].jobUrl,
            jobTitle: jobDetails[i].jobPosition,
            companyName: jobDetails[i].companyName,
            location: jobDetails[i].jobLocation,
            datePosted: jobDetails[i].datePosted,
            activelyHiring: jobDetails[i].activelyHiring,
          });
          const saveJobs = await createJob.save();
        } else {
          getjobs.jobUrl = jobDetails[i].jobUrl;
          getjobs.jobTitle = jobDetails[i].jobPosition;
          getjobs.companyName = jobDetails[i].companyName;
          getjobs.location = jobDetails[i].jobLocation;
          getjobs.datePosted = jobDetails[i].datePosted;
          getjobs.activelyHiring = jobDetails[i].activelyHiring;
          await getjobs.save();
        }
      }
    }
    res.status(200).json(true);
    jobPro(jobDetails);
  } catch (error) {
    console.log(error);
    res.status(500).json(error);
  }
};

// api for reverting status of scraped
// exports.peopleInProcess = async (req, res) => {
//     try {
//         const getData = await People.findAll({ where: { status: "processing" } });
//         if (getData.length === 0) {
//             res.status(200).json(null);
//         } else {
//             for (let i = 0; i < getData.length; i++) {
//                 try {
//                     const date = new Date();
//                     // console.log(date);
//                     const pDate = getData[0]['updatedAt'];
//                     // console.log(pDate);
//                     // console.log(date>pDate);
//                     if (date > pDate) {
//                         getData[0]['status'] = "not_scraped";
//                         const statusReverted = await getDate.save();
//                     }
//                 } catch (error) {
//                     res.status(500).json(`Error raise during Reverting status ${error}`)
//                 }
//             }
//             res.status(200).json(true);
//         }
//     } catch (error) {
//         res.status(500).json(error);
//     }
// }

exports.setPriority = async (req, res) => {
  res.json("Jobs priorty queue started");
  console.log("inside priority thing");
  // traversing in jobs table
  const dataJob = await jobs.findAll({
    limit: 1000,
    where: { status: "not_traversed" },
  });
  // setting their status to traversed
  for (let i = 0; i < dataJob.length; i++) {
    dataJob[i].status = "traversed";
    await dataJob[i].save();
  }
  console.log(dataJob);
  jobPro(dataJob);
};

const jobPro = async (job) => {
  // console.log(job.data);
  // jobDetails = job.data;
  let jobDetails = job;
  console.log("jobPro inside priority thing");
  for (let i = 0; i < jobDetails.length; i++) {
    // company_newName thing..
    let companyName_Orginal = jobDetails[i].companyName;
    let companyNewName = jobDetails[i].companyName;
    if (companyName_Orginal.includes("(")) {
      companyNewName = companyName_Orginal.split("(")[0].trim();
    } else if (companyName_Orginal.includes("Pvt")) {
      companyNewName = companyName_Orginal.split("Pvt")[0].trim();
    } else if (companyName_Orginal.includes("pvt")) {
      companyNewName = companyName_Orginal.split("pvt")[0].trim();
    } else if (companyName_Orginal.includes("Ltd")) {
      companyNewName = companyName_Orginal.split("Ltd")[0].trim();
    } else if (companyName_Orginal.includes("India")) {
      companyNewName = companyName_Orginal.split("India")[0].trim();
    } else if (companyName_Orginal.includes("Inc")) {
      companyNewName = companyName_Orginal.split("Inc")[0].trim();
    }
    // console.log("-------------------------")
    // console.log(companyNewName)
    // console.log("-------------------------")
    const findComp = await company.findAll({
      where: { name: { [Op.like]: `${companyNewName} %` }, source: "Linkedin" },
    });
    // console.log(findComp)
    console.log(findComp.length);
    if (findComp.length != 0) {
      for (let j = 0; j < findComp.length; j++) {
        findComp[j].priority += 1;
        await findComp[j].save();
      }
    }
    // searching for original name exact match
    const findSameComp = await company.findAll({
      where: { name: companyName_Orginal, source: "Linkedin" },
    });
    if (findSameComp.length != 0) {
      console.log("adding location in locations table of original name comp");
      // checking already existence
      for (let k = 0; k < findSameComp.length; k++) {
        const checkLoc = await locationDetails.findOne({
          where: { company_id: findSameComp[k].id },
        });
        if (checkLoc == null) {
          // adding jobs
          const addloc = await new locationDetails({
            location: jobDetails[i].location,
            company_id: findSameComp[k].id,
          });
          await addloc.save();
        }
      }
    }
    // searching for newname exact match
    const findNewComp = await company.findAll({
      where: { name: companyNewName, source: "Linkedin" },
    });
    if (findNewComp.length != 0) {
      console.log(
        "adding location of like company exact match locations table"
      );
      // checking already existence of company
      for (let k = 0; k < findNewComp.length; k++) {
        const checkLoc = await locationDetails.findOne({
          where: { company_id: findNewComp[k].id },
        });
        if (checkLoc == null) {
          // adding location
          const addloc = await new locationDetails({
            location: jobDetails[i].location,
            company_id: findNewComp[k].id,
          });
          await addloc.save();
        }
      }
    }
  }
  console.log("done priority thing");
};

exports.peopleSearch = async (req, res) => {
  try {
    //defining folder path
    let folderPath = path.join(__dirname + "../../../xlsxfiles");
    // getting User
    const reqUser = await user1.findOne({ where: { token: req.query.token } });
    let UserTime = reqUser.last_fetch_time;
    if (UserTime) {
      const now = new Date();
      const msBetweenDates = Math.abs(UserTime.getTime() - now.getTime());
      const hoursBetweenDates = msBetweenDates / (60 * 60 * 1000);
      if (hoursBetweenDates < 24) {
        const filePath = path.join(
          __dirname + `../../../xlsxfiles/${reqUser.name}/Users.xlsx`
        );
        if (fs.existsSync(filePath)) {
          return res.download(filePath);
        } else {
          return res.json(
            "No Peoples Left with this Designation. Try after 24 hours with different Designation or contact Developers"
          );
        }
      } else {
        fs_extra.remove(folderPath + `/${reqUser.name}`, (error) => {
          if (error) {
            console.log(error);
          }
        });
        reqUser.last_fetch_time = new Date();
        reqUser.last_fetched_id = "";
      }
    } else {
      reqUser.last_fetch_time = new Date();
    }
    // creating array for fetched id
    let fetchedIds = [];
    const newLimit = Math.ceil(parseInt(req.query.limit) / 2);
    const getPeople = await people.findAll({
      limit: newLimit,
      attributes: ["id", "url", "name", "source", "fetch_status"],
      where: { source: "linkedin", fetch_status: false },
      include: [
        {
          model: worksIn,
          attributes: ["people_id", "Designation"],
          where: {
            [Op.or]: [
              {
                Designation: {
                  [Op.substring]: req.query.Designation,
                },
              },
            ],
          },
        },
        {
          model: peopleDetails,
          attributes: [
            "email",
            "connects",
            "number",
            "website_link",
            "twitter",
            "linkedin",
            "facebook",
            "skills",
          ],
          required: false,
        },
      ],
    });
    console.log(getPeople);
    // for crunchbase data
    const getCrunchPeople = await people.findAll({
      limit: parseInt(req.query.limit) - newLimit,
      attributes: ["id", "url", "name", "source", "fetch_status"],
      where: { source: "crunchbase", fetch_status: false },
      include: [
        {
          model: worksIn,
          attributes: ["people_id", "Designation"],
          where: {
            [Op.or]: [
              {
                Designation: {
                  [Op.substring]: req.query.Designation,
                },
              },
            ],
          },
        },
        {
          model: peopleDetails,
          attributes: [
            "email",
            "connects",
            "number",
            "website_link",
            "twitter",
            "linkedin",
            "facebook",
            "skills",
          ],
          required: false,
        },
      ],
    });
    console.log(getCrunchPeople);

    // creating array of objects
    let arrData = [];
    if (getPeople.length != 0) {
      for (let i = 0; i < getPeople.length; i++) {
        let obj = {
          url: getPeople[i]["url"],
          name: getPeople[i]["name"],
          source: getPeople[i]["source"],
          Designation: getPeople[i]["worksIns"][0]["Designation"],
          email: getPeople[i].people_details[0]["email"],
          connects: getPeople[i].people_details[0]["connects"],
          number: getPeople[i].people_details[0]["number"],
          website_link: getPeople[i].people_details[0]["website_link"],
          twitter: getPeople[i].people_details[0]["twitter"],
          linkedin: getPeople[i].people_details[0]["linkedin"],
          facebook: getPeople[i].people_details[0]["facebook"],
          skills: getPeople[i].people_details[0]["skills"],
        };
        // changing fetch status of each people
        // console.log(getPeople[i])
        getPeople[i]["fetch_status"] = true;
        await getPeople[i].save();
        fetchedIds.push(getPeople[i]["worksIns"][0]["people_id"]);
        arrData.push(obj);
      }
    }
    // for crunchbase data mapping
    if (getCrunchPeople.length != 0) {
      for (let i = 0; i < getCrunchPeople.length; i++) {
        let obj = {
          url: getCrunchPeople[i]["url"],
          name: getCrunchPeople[i]["name"],
          source: getCrunchPeople[i]["source"],
          Designation: getCrunchPeople[i]["worksIns"][0]["Designation"],
          email: getCrunchPeople[i].people_details[0]
            ? getCrunchPeople[i].people_details[0]["email"]
            : null,
          connects: getCrunchPeople[i].people_details[0]
            ? getCrunchPeople[i].people_details[0]["connects"]
            : null,
          number: getCrunchPeople[i].people_details[0]
            ? getCrunchPeople[i].people_details[0]["number"]
            : null,
          website_link: getCrunchPeople[i].people_details[0]
            ? getCrunchPeople[i].people_details[0]["website_link"]
            : null,
          twitter: getCrunchPeople[i].people_details[0]
            ? getCrunchPeople[i].people_details[0]["twitter"]
            : null,
          linkedin: getCrunchPeople[i].people_details[0]
            ? getCrunchPeople[i].people_details[0]["linkedin"]
            : null,
          facebook: getCrunchPeople[i].people_details[0]
            ? getCrunchPeople[i].people_details[0]["facebook"]
            : null,
          skills: getCrunchPeople[i].people_details[0]
            ? getCrunchPeople[i].people_details[0]["skills"]
            : null,
        };
        // changing fetch status of each people
        // console.log(getPeople[i])
        getCrunchPeople[i]["fetch_status"] = true;
        await getCrunchPeople[i].save();
        fetchedIds.push(getCrunchPeople[i]["worksIns"][0]["people_id"]);
        arrData.push(obj);
      }
    }

    // adding changes to User1s table
    reqUser.last_fetched_id = fetchedIds.toString();
    await reqUser.save();

    // creating folder for User
    if (!fs.existsSync(folderPath + `/${reqUser.name}`)) {
      fs.mkdirSync(
        folderPath + `/${reqUser.name}`,
        { recursive: true },
        (error) => {
          if (error) {
            console.log(error);
          }
        }
      );
    }

    if (arrData.length != 0) {
      // creating xlsx
      const workbook = new excel.Workbook();
      const worksheet = workbook.addWorksheet("Users");
      worksheet.columns = [
        { header: "Url", key: "url", width: 30 },
        { header: "Name", key: "name", width: 10 },
        { header: "Source", key: "source", width: 10 },
        { header: "Designation", key: "Designation", width: 20 },
        { header: "Email", key: "email", width: 20 },
        { header: "Connects", key: "connects", width: 10 },
        { header: "Number", key: "number", width: 20 },
        { header: "Website_link", key: "website_link", width: 30 },
        { header: "Twitter", key: "twitter", width: 10 },
        { header: "Linkedin", key: "linkedin", width: 10 },
        { header: "Facebook", key: "facebook", width: 10 },
        { header: "Skills", key: "skills", width: 50 },
      ];
      arrData.forEach((data) => {
        worksheet.addRow(data);
      });
      worksheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: true };
      });
      const file = await workbook.xlsx.writeFile(
        `xlsxfiles/${reqUser.name}/Users.xlsx`
      );

      // sending response
      return res.download(
        path.join(__dirname + `../../../xlsxfiles/${reqUser.name}/Users.xlsx`),
        () => {
          // fs.unlinkSync(path.join(__dirname + `../../../xlsxfiles/${reqUser.name}/Users.xlsx`))
        }
      );
    } else {
      return res.json("No Peoples Left with this Designation");
    }
  } catch (error) {
    console.log(error);
    res.json(error);
  }
};

exports.googleSearchPeopleApi = async (req, res) => {
  try {
    console.log(req.body);
    if (!req.body) {
      res.status(500).json("empty data recieved");
    }
    const details = req.body.peoples;
    const item = req.body.item;
    // storing peoples
    for (let i = 0; i < details.length; i++) {
      var peopleId;
      const findPeople = await People.findOne({
        where: { url: details[i].url },
      });
      if (findPeople == null) {
        if (isValidURL(details[i]["url"])) {
          const addPeople = await new People({
            url: details[i]["url"],
            name: details[i]["name"],
            priority: 1,
          });
          const savePeople = await addPeople.save();
          peopleId = savePeople.id;
        } else {
          console.log("invalid url");
        }
      } else {
        // console.log("inside priority increasing");
        findPeople["priority"] = findPeople["priority"] + 1;
        await findPeople.save();
        peopleId = findPeople.id;
      }
      // adding item in googleSearchItems
      var findItemId;
      var itemSkill;
      const findItem = await googleSearchItems.findOne({
        where: { items: req.body.item },
      });
      if (findItem == null) {
        const addItem = await new googleSearchItems({
          items: req.body.item,
        });
        const saveItem = await addItem.save();
        itemSkill = saveItem.skill;
        findItemId = saveItem.id;
      } else {
        findItemId = findItem.id;
        itemSkill = findItem.skill;
      }
      console.log(findItem);
      // adding items googlePeoples
      const findGooglePeople = await googlePeople.findOne({
        where: { google_search_id: findItemId, people_id: peopleId },
      });
      if (findGooglePeople == null) {
        const addgooglePeople = await new googlePeople({
          google_search_id: findItemId,
          people_id: peopleId,
        });
        const saveGooglePeople = await addgooglePeople.save();
      }

      // adding in people_details
      const findPeopleDetails = await peopleDetails.findOne({
        where: { people_id: peopleId },
      });
      if (findPeopleDetails == null) {
        const addDetails = await new peopleDetails({
          people_id: peopleId,
          skills: itemSkill,
        });
        const detailsAdded = await addDetails.save();
      } else {
        if (findPeopleDetails.skills == null) {
          findPeopleDetails.skills = itemSkill;
          console.log(findPeopleDetails);
          await findPeopleDetails.save();
        } else if (itemSkill != null) {
          let skill = findPeopleDetails.skills.split(",");
          if (!skill.includes(itemSkill)) {
            skill.push(itemSkill);
            findPeopleDetails.skills = skill.toString();
          }
          await findPeopleDetails.save();
        }
      }
    }
    res.status(200).json("Added Successfully");
  } catch (error) {
    console.log(error);
    res.status(500).json(error);
  }
};

exports.googlePeopleApi = async (req, res) => {
  try {
    //defining folder path
    let folderPath = path.join(__dirname + "../../../xlsxFilesGooglePeople");
    // getting User
    const reqUser = await user1.findOne({ where: { token: req.query.token } });
    let UserTime = reqUser.last_fetch_time;

    if (UserTime) {
      const now = new Date();
      const msBetweenDates = Math.abs(UserTime.getTime() - now.getTime());
      const hoursBetweenDates = msBetweenDates / (60 * 60 * 1000);
      if (hoursBetweenDates < 24) {
        var filePath = path.join(
          __dirname +
          `../../../xlsxFilesGooglePeople/${reqUser.name}/Users.xlsx`
        );
        if (fs.existsSync(filePath)) {
          return res.download(filePath);
        } else {
          return res.json(
            "No Peoples Left with this Designation. Try after 24 hours with different Designation or contact Developers"
          );
        }
      } else {
        fs_extra.remove(folderPath + `/${reqUser.name}`, (error) => {
          if (error) {
            console.log(error);
          }
        });
        reqUser.last_fetch_time = new Date();
        reqUser.last_fetched_id = "";
      }
    } else {
      reqUser.last_fetch_time = new Date();
    }
    // creating array for fetched id
    let fetchedIds = [];

    const getPeoples = await googlePeople.findAll({
      attributes: ["people_id", "google_search_id"],
      limit: parseInt(req.query.limit),
      include: [
        {
          model: googleSearchItems,
          attributes: ["items"],
          where: {
            items: {
              [Op.substring]: req.query.skill,
            },
          },
        },
      ],
    });

    let arrPeople = [];
    for (let i = 0; i < getPeoples.length; i++) {
      const getPeople = await people.findOne({
        where: { id: getPeoples[i].people_id, fetch_status: false },
      });
      let obj = {
        id: getPeople["id"],
        url: getPeople["url"],
        name: getPeople["name"],
        source: getPeople["source"],
        status: getPeople["status"],
        items: getPeoples[i]["google_search_item"].items,
      };
      arrPeople.push(obj);
      fetchedIds.push(getPeople.id);
      getPeople.fetch_status = true;
      await getPeople.save();
    }
    console.log(fetchedIds);

    // adding changes to User1s table
    reqUser.last_fetched_id = fetchedIds.toString();
    await reqUser.save();

    // creating folder for User
    if (!fs.existsSync(folderPath + `/${reqUser.name}`)) {
      fs.mkdirSync(
        folderPath + `/${reqUser.name}`,
        { recursive: true },
        (error) => {
          if (error) {
            console.log(error);
          }
        }
      );
    }

    if (arrPeople.length != 0) {
      // creating xlsx
      const workbook = new excel.Workbook();
      const worksheet = workbook.addWorksheet("Users");
      worksheet.columns = [
        { header: "Id", key: "id", width: 10 },
        { header: "Url", key: "url", width: 30 },
        { header: "Name", key: "name", width: 20 },
        { header: "Source", key: "source", width: 10 },
        { header: "Status", key: "status", width: 20 },
        { header: "Skill", key: "items", width: 60 },
      ];
      arrPeople.forEach((data) => {
        worksheet.addRow(data);
      });
      worksheet.getRow(1).eachCell((cell) => {
        cell.font = { bold: true };
      });
      const file = await workbook.xlsx.writeFile(
        `xlsxFilesGooglePeople/${reqUser.name}/Users.xlsx`
      );
      // sending response
      return res.download(
        path.join(
          __dirname +
          `../../../xlsxFilesGooglePeople/${reqUser.name}/Users.xlsx`
        ),
        () => { }
      );
    } else {
      return res.json("No Peoples Left with this Designation");
    }
  } catch (error) {
    console.log(error);
    res.json(error);
  }
};

exports.saveContact = async (req, res) => {
  try {
    let group = req.query.group1;
    let location = req.query.location1;
    var emails;
    var phones;
    try {
      emails = req.query.email1.split(",");
    } catch (err) {
      emails = [];
    }
    try {
      phones = req.query.phone1.split(",");
    } catch (err) {
      phones = [];
    }
    let url = req.query.url1;
    for (let i = 0; i < emails.length; i++) {
      var email = emails[i];
      if (email != "") {
        var contact_ins = await gsContact.create({
          group: group,
          location: location,
          url: url,
          email: email,
        });
      }
    }
    for (let i = 0; i < phones.length; i++) {
      var phone = phones[i];
      if (phone != "") {
        var contact_ins = await new gsContact({
          group: group,
          location: location,
          url: url,
          phone: phone,
        });
        await contact_ins.save();
      }
    }
    console.log([group, location, emails, phones, url]);
    res.json("success");
  } catch (err) {
    res.status(500).json(error);
  }
};

exports.saveWebsite = async (req, res) => {
  try {
    let group = req.query.group;
    let location = req.query.location;
    var websites;
    try {
      websites = req.query.website.split(",");
    } catch (err) {
      console.log(err);
      console.log("------------------------------------------------");
      console.log(req.query);
      websites = [];
    }
    console.log(group, location, websites);
    for (let i = 0; i < websites.length; i++) {
      var website = websites[i];
      if (website != "") {
        var sites = await gsWebsite.findAll({
          where: {
            website: {
              [Op.like]: "%" + getDomain(website) + "%",
            },
          },
        });

        if (sites.length == 0) {
          var contact_ins = await gsWebsite.create({
            group: group,
            location: location,
            website: website,
          });
        }
      }
    }
    res.json("success");
  } catch (err) {
    console.log(err);
    res.status(500).json(err);
  }
};

exports.mlWebsite = async (req, res) => {
  try {
    var count = req.query.count;
    if (count == null || count == "") {
      count = 20;
    }

    var sites = await gsWebsite.findAll({
      where: {
        crawl_status: 0,
      },
      limit: parseInt(count),
    });
    for (let i = 0; i < sites.length; i++) {
      var onesite = await gsWebsite.findOne({
        where: {
          id: sites[i]['id']
        },
      });
      onesite['crawl_status'] = 10
      await onesite.save()
    }
    res.json(sites);
  } catch (err) {
    res.json(err);
  }
};

exports.CompanyWebsite = async (req, res) => {
  try {
    var count = req.query.count;
    if (count == null || count == "") {
      count = 20;
    }

    var sites = await companyDetails.findAll({
      where: {
        crawl_status: 0,
        website: {
          [Op.and]: [
            { [Op.not]: null },
            { [Op.ne]: "" },
          ]
        },
        // location : {
        //   [Op.like] : "%india%"
        // }
      },
      limit: parseInt(count),
    });
    for (let i = 0; i < sites.length; i++) {
      var onesite = await companyDetails.findOne({
        where: {
          id: sites[i]['id']
        },
      });
      onesite['crawl_status'] = 10
      await onesite.save()
    }
    res.json(sites);
  } catch (err) {
    res.json(err);
  }
};

exports.mlWebsiteUpdate = async (req, res) => {
  try {
    const site = await gsWebsite.findByPk(req.params.id);
    let group = req.query.group;
    let crawl_status = req.query.crawl_status;
    let education_found = req.query.education_found;
    let email_search = req.query.email_search;
    let contact_found = req.query.contact_found;
    let contact_us_page = req.query.contact_us_page;
    let title = req.query.title;
    if (contact_found != null) {
      site["email_search"] = contact_found;
    }
    if (group != null) {
      site["group"] = group;
    }
    if (crawl_status != null) {
      site["crawl_status"] = crawl_status;
    }
    if (education_found != null) {
      site["education_found"] = education_found;
    }
    if (contact_us_page != null) {
      site["contact_us_link"] = contact_us_page;
    }
    if (title != null) {
      site["title"] = title;
    }
    await site.save();
    res.json("success");
  } catch (err) {
    res.json(err).status(500);
  }
};

exports.getContactPage = async (req, res) => {
  try {
    var count = req.query.count;
    if (count == null || count == "") {
      count = 20;
    }

    var sites = await gsWebsite.findAll({
      where: {
        contact_us_link: {
          [Op.not]: null,
        },
        contact_us_status: {
          [Op.is]: null,
        },
      },
      limit: parseInt(count),
    });
    res.json(sites);
  } catch (err) {
    res.json(err);
  }
};

exports.saveContactUsStatus = async (req, res) => {
  try {
    let date_obj = new Date();
    let website_id = req.query.website_id;
    let msg = req.query.message;
    let generated_contact_message = req.query.genmsg;
    const site = await gsWebsite.findByPk(website_id);
    site["contact_us_status"] = msg;
    if (generated_contact_message) {
      site["generated_contact_message"] = generated_contact_message;
    }
    site["contact_submitted_on"] = date_obj;

    await site.save();
    res.json("success");
  } catch (err) {
    res.json(err);
  }
};

exports.saveMlPeople = async (req, res) => {
  try {
    console.log("save-ml-people started");
    let people_ins = null;
    let data = req.body;
    let website_id = data.website_id;
    let peoples = data.peoples;

    let website_ins = await gsWebsite.findByPk(website_id);
    console.log("0");
    // console.log(website_ins)
    let website_domain = getDomain(website_ins.website);

    for (let i = 0; i < peoples.length; i++) {
      var speople = peoples[i];
      var name = speople.name;
      var position = speople.position;
      var email = speople.email;
      var linkedin = speople.linkedin;
      var linkedin_id = null;

      var existingEmailCount = 0;

      if (email != null) {
        var existingEmail = await mlPeople.findAll({
          where: {
            email: email,
            gs_website_id: website_id,
          },
        });

        existingEmailCount = existingEmail.length;
      }

      var contacts = await mlPeople.findAll({
        where: {
          name: name,
          gs_website_id: website_id,
        },
      });
      console.log("1");
      if (contacts.length == 0 && existingEmailCount == 0) {
        var contact_ins = await mlPeople.create({
          name: name,
          position: position,
          email: email,
          gs_website_id: website_id,
          linkedin: linkedin_id,
        });
      } else if (contacts[0].email != email) {
        var contact_ins = contacts[0];
        contact_ins.email = email;
        await contact_ins.save();
      } else {
        var contact_ins = contacts[0];
      }

      if (name != null && email != null) {
        var exitingWebs = await websiteTable.findAll({
          where: {
            website: {
              [Op.like]: website_domain,
            },
          },
        });
        console.log("3");
        if (exitingWebs.length > 0) {
          var main_website = exitingWebs[0];
        } else {
          var main_website = await websiteTable.create({
            website: website_domain,
          });
        }

        var existing_people_count = 0;

        var existing_people_website = await peopleWebsite.findAll({
          where: {
            website: main_website.id,
          },
        });
        console.log("4");
        if (existing_people_website.length != 0) {
          for (let i = 0; i < existing_people_website.length; i++) {
            var p_details = await peopleDetails.findAll({
              where: {
                people_id: existing_people_website[i].people_id,
              },
            });
            var p_ins = await people.findByPk(
              existing_people_website[i].people_id
            );
            if (p_ins.name == name) {
              existing_people_count = existing_people_count + 1;
            }
            if (p_details.length > 0) {
              var p_detail = p_details[0];
              p_detail["email"] = email;
              await p_detail.save();
            }
          }
        } else if (existing_people_count == 0) {
          var p_details = await peopleDetails.findAll({
            where: {
              email: email,
            },
          });

          if (p_details.length > 0) {
            var p_detail = p_details[0];
            if (p_detail.position == null) {
              p_detail["position"] = position;
            }
          } else {
            var main_people = await people.create({
              name: name,
              source: "website",
              url: linkedin,
            });
            console.log("5");
            console.log(main_people.id);
            console.log(contact_ins);
            contact_ins["linkedin"] = main_people.id;
            console.log("5.5");
            contact_ins.save();
            console.log("6");
            console.log(main_people.id, main_website.id);

            var main_people_detail = await peopleDetails.create({
              email: email,
              position: position,
              people_id: main_people.id,
            });

            var people_website = await peopleWebsite.create({
              people_id: main_people.id,
              website: main_website.id,
            });
          }
        }
      }
      console.log(7);
      if (linkedin != null) {
        var peoples_ins = await people.findAll({ where: { url: linkedin } });
        if (peoples_ins.length == 0) {
          people_ins = await people.create({ url: linkedin });
        } else {
          people_ins = peoples_ins[0];
        }
        linkedin_id = people_ins.id;
        contact_ins["linkedin"] = linkedin_id;
        contact_ins.save();
      }
    }

    console.log("Peole saved");
    res.json("success");
  } catch (err) {
    res.status(500).json({ error: err });
  }
};

function sqlObjToArr(ins, experiences) {
  var arr = [];
  var common_fields = [
    "id",
    "name",
    "url",
    "linkedin",
    "source",
    "number",
    "email",
    "gender",
    "skills",
    "position",
    "website_link",
    "connects",
    "followers",
    "about",
  ];
  for (let i = 0; i < common_fields.length; i++) {
    try {
      arr.push(ins[common_fields[i]]);
    } catch (err) {
      console.log(err);
    }
  }

  if (experiences) {
    for (let i = 0; i < experiences.length; i++) {
      var exp = experiences[i];
      var pos_str = "";
      pos_str = pos_str + "Company Name: " + exp["companyName"];
      pos_str = pos_str + "|| Company Position: " + exp["companyPosition"];
      pos_str = pos_str + "|| Company Profile: " + exp["companyUrl"];
      pos_str = pos_str + "|| start: " + exp["start"];
      pos_str = pos_str + "|| end: " + exp["end"];
      arr.push(pos_str);
    }
  }
  return arr;
}

exports.getDataWithEmail = async (req, res) => {
  try {
    var token = req.query.token;
    var count = req.query.count;
    var location = req.query.location;
    console.log("location: ", location)
    try {
      const date = new Date();
      const startOfDay = new Date(date.getFullYear(), date.getMonth(), date.getDate());
      const endOfDay = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59);
      console.log(date)
      const user = await userModel.findOne({
        where: { token: token }
      })
      const userstats = await userStats.findOne({
        where: {
          user_id: user.id, createdAt: {
            [Op.gte]: startOfDay,
            [Op.lt]: endOfDay
          },
        }
      })
      console.log(userstats)
      userstats.location = location;
      await userstats.save();
    } catch (e) {
      console.log("Error in saving the location to userStats", e)
    }
    var location_list = [];
    var positions = req.query.positions;
    var source = req.query.source;
    var pos = [];
    if (positions) {
      pos = positions.split(",");
    } else {
      pos = [
        "ceo",
        "founder",
        "director",
        "executive",
        "chief",
        "officer",
        "partner",
        "owner",
        "business",
        "bdm",
        "finance",
        "president",
        "vp",
        "head",
        "cmo"
      ];
    }

    if (location) {
      location_list = location.split(",")
    }

    if (source) {
      if (source != "Linkedin" && source != "crunchbase") {
        source = "Linkedin"
      }
    } else {
      source = "Linkedin"
    }
    source = "crunchbase"
    console.log(source)

    if (!token) {
      res.json("No token provided");
      return 0;
    }
    if (!count) {
      res.json("No count provided");
      return 0;
    }
    // if (count < 3) {
    //   count = count;
    // } else {
    //   count = count - 2;
    // }

    let users = await user.findOne({ where: { token: token } });
    console.log(token);
    if (users == null) {
      res.json("Token not registeres");
      return 0;
    }

    let date_ob = new Date();
    let date = date_ob.getDate();
    let month = date_ob.getMonth() + 1;
    let year = date_ob.getFullYear();
    let date_str = date + "-" + month + "-" + year;
    let filename = "csv_data/" + token + "_" + date_str + ".csv";
    if (source == "crunchbase") {
      filename = "csv_data/" + token + "_" + date_str + "_crunchbase.csv";
    }
    console.log(__dirname);
    console.log(__filename);
    console.log(appRoot.path);
    var options = {
      root: path.join(appRoot.path),
    };
    if (fs.existsSync(filename)) {
      console.log("Exists");

      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err);
          return 0;
        } else {
          console.log("Sent:", filename);
        }
      });
      return 0;
    } else {
      const columns = [
        "id",
        "name",
        "url",
        "linkedin",
        "source",
        "number",
        "email",
        "gender",
        "skills",
        "position",

        "website_link",
        "connects",
        "followers",
        "about",
        "experience",
      ];

      const csvWriter = createCsvWriter({
        header: columns,
        path: filename,
      });
      var records = [];
      console.log();
      var pos_query = "";
      for (let i = 0; i < pos.length; i++) {
        if (i == 0) {
          pos_query =
            pos_query +
            'LOWER(people_details.position) LIKE "%' +
            pos[i] +
            '%"';
          pos_query =
            pos_query +
            ' OR LOWER(people_details.experience) LIKE "%' +
            pos[i] +
            '%"';
        } else {
          pos_query =
            pos_query +
            ' OR LOWER(people_details.position) LIKE "%' +
            pos[i] +
            '%"';
          pos_query =
            pos_query +
            ' OR LOWER(people_details.experience) LIKE "%' +
            pos[i] +
            '%"';
        }
      }

            var query_str = "SELECT * FROM people INNER JOIN people_details ON (people_details.people_id = people.id) WHERE people.fetch_status < 4 AND people.source=\"" + source +"\" "


      if (source == "crunchbase") {
        query_str = query_str + 'AND people.url LIKE "%crunchbase%" AND people_details.linkedin IS NOT NULL AND people_details.linkedin != "" '
      } else {
        query_str = query_str + 'AND ( people.url LIKE "%linkedin%" OR ( people_details.linkedin IS NOT NULL AND people_details.linkedin != "" ))'
      }

      var loc_query = ""

      for (let i = 0; i < location_list.length; i++) {
        if (i == 0) {
          loc_query = loc_query + 'LOWER(people_details.location) LIKE "%' + location_list[i].toLowerCase() + '%"';

        } else {
          loc_query = loc_query + ' OR LOWER(people_details.location) LIKE "%' + location[i].toLowerCase() + '%"';

        }
      }

      if (loc_query != "") {
        query_str = query_str + 'AND ( ' + loc_query + ') '
      }

      if (pos_query != "" && source != "crunchbase") {
        query_str = query_str + "AND (" + pos_query + ")"
      }
      console.log(query_str)
      var [results, metadata] = await seq.query(query_str + " ORDER BY people.fetch_status ASC LIMIT " + count);
      console.log(results.length)
      if (results.length == 0) {
        if (source == "Linkedin") {

          query_str = query_str.replace("Linkedin", "crunchbase")
          query_str = query_str.replace("linkedin", "crunchbase")
          query_str = query_str.replace("AND (" + pos_query + ")", "")
          console.log(query_str)
          console.log("----------------------")

          query_str = query_str + ' AND people_details.linkedin IS NOT NULL AND people_details.linkedin != ""';

          [results, metadata] = await seq.query(query_str + " ORDER BY people.fetch_status ASC LIMIT " + count);
        }
      }
      for (let i = 0; i < results.length; i++) {
        let people_idd = results[i].people_id
        let people_ins = await people.findByPk(people_idd)
        people_ins.fetch_status = people_ins.fetch_status + 1
        console.log(people_idd)
        // console.log(people_ins)
        await people_ins.save()
        console.log(i)
        var experience = results[i]['experience']
        var arr = sqlObjToArr(results[i], experience)
        records.push(arr)
      }
      await csvWriter.writeRecords(records)
      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err)
          return 0
        } else {
          console.log('Sent:', filename);
        }
      });
      return 0
    }

  } catch (err) {
    res.status(500).json(err)
  }
}
exports.getCompaniesToSearch = async (req, res) => {
  try {
    let version = req.query.version;
    var count = 10;
    var names = []
    if (version == "v2"){
      var getCompany = await company.findAll({
        limit:count ,
        where: {
          searchStatus: "not_searched", status: "not_scraped"
        },
        attributes : ['name', 'id']
      }) 
      for(let i=0;i<getCompany.length;i++){
        names.push({name:getCompany[i].name,id:getCompany[i].id})
        // names.push(
        getCompany[i].searchStatus = "searched";
        await getCompany[i].save();

      }
      res.send(names)
      return 0;
    } else if (version == "v3"){
      let run_id = req.headers['run_id']
      if (!run_id) {
        let user = await userModel.findOne({where:{token:req.headers['auth'], status:"Active" }});
        let user_stats_obj = await userStats.create({
          user_id: user.id,
          extensionName:'ceo_search_exe',
          runCount:0
        })
        run_id = user_stats_obj.id
      }
      let getCompany = await company.findAll({
        limit:count ,
        where: {
          searchStatus: "not_searched",
          name :{
            [Op.ne] : null
          }
        },
        attributes : ['name', 'id']
      }) 
      for(let i=0;i<getCompany.length;i++){
        names.push({name:getCompany[i].name,id:getCompany[i].id})
        // names.push(
        getCompany[i].searchStatus = "processing";
        await getCompany[i].save();
      }
      res.send({data:names, run_id:run_id})
      return 0
    }
    count = 10;
    names = []
    var getCompany = await company.findAll({limit:count ,where: {searchStatus: "not_searched", status:"not_scraped" }}) 
    for(let i=0;i<getCompany.length;i++){

      names.push(getCompany[i].name)
      getCompany[i].searchStatus = "searched";
      await getCompany[i].save();

    }
    res.send(names)
  }catch(err){
    console.log(err)
    res.sendStatus(500).json(err)
  }
}

exports.getUserStats = async (req, res) => {
  try {
    const query_str = "SELECT user_stats.user_id, users.name, users.token, user_stats.createdAt,user_stats.runCount, user_stats.connectionGrowth, user_stats.extensionName, user_stats.extensionVersion, user_stats.connectionCount, user_stats.invitesCount, user_stats.messageCount, user_stats.messageDetails FROM users INNER JOIN user_stats ON users.id = user_stats.user_id ORDER BY user_id ASC;"
    var [results] = await seq.query(query_str)
    // console.log(results[0].invitesCount)
    let records = [];
    let columns = [
      "user_id",
      "name",
      "token",
      "createdAt",
      "runCount",
      "connectionGrowth",
      "extensionName",
      "extensionVersion",
      "connectionName",
      "invitesCount",
      "messageCount",
      "messageDetails"
    ]
    const d = `${new Date()}`
    const today = d.slice(4, 15)
    for (let i = 0; i < results.length; i++) {
      let arr = [];
      let date = `${results[i].createdAt}`;
      let createdDate = date.substring(4, 15)
      if (createdDate === today) {
        arr.push(results[i].user_id);
        arr.push(results[i].name)
        arr.push(results[i].token)
        arr.push(results[i].createdAt)
        arr.push(results[i].runCount)
        arr.push(results[i].connectionGrowth)
        arr.push(results[i].extensionName)
        arr.push(results[i].extensionVersion)
        arr.push(results[i].connectionCount)
        arr.push(results[i].invitesCount)
        arr.push(results[i].messageCount)
        for (let j = 0; j < results[i].messageDetails.length; j++) {
          let tmp = [];
          tmp.push(results[i].messageDetails[j].name)
          tmp.push(results[i].messageDetails[j].time)
          arr.push(tmp)
        }
        // arr.push(results[i].messageDetails)
        records.push(arr);
      }
    }

    const csvWriter = createCsvWriter({
      path: 'output.csv',
      header: columns
    });
    var options = {
      root: path.join(appRoot.path),
    };
    csvWriter.writeRecords(records)
      .then(() => {
        res.sendFile('output.csv', options, function (err) {
          if (err) {
            console.log(err);
            res.json(err)
            return 0
          }
          else {
            console.log('Sent:', 'output.csv');
          }
        })
        console.log('The CSV file was written successfully');
      });


    // res.send(results)
  } catch (err) {
    res.send(500).json(err)
  }
}

exports.createToken = async (req, res) => {
  try {
    let token = req.query.token;
    let name = req.query.name;
    console.log(token, name);
    if (!token || !name) {
      res.json("Name or token is empty");
      return 0;
    }
    let existed_user = await user.findOne({ where: { token: token } });
    if (existed_user) {
      res.json("This token is already exits on server");
      return 0;
    }

    let date_ob = new Date();
    let user_ins = await user.create({
      name: name,
      token: token,
      status: "Active",
      createdAt: date_ob,
      last_scraped: date_ob,
    });
    res.json("success");
  } catch (err) {
    res.status(500).json(err);
  }
};

function structEmailsPhone(contacts) {
  var emails = [];
  var phones = [];

  for (let i = 0; i < contacts.length; i++) {
    if (contacts[i]["email"] != null) {
      emails.push(contacts[i]["email"]);
    }
    if (contacts[i]["phone"] != null) {
      phones.push(contacts[i]["phone"]);
    }
  }
  // console.log(emails)
  // console.log(phones)
  return [emails, phones];
}

exports.getWebsiteData = async (req, res) => {
  try {
    var token = req.query.token;
    var count = req.query.count;
    var location = req.query.location;
    var industry = req.query.industry;

    if (location == "" || location == " ") {
      location = null;
    }

    if (industry == "" || industry == " ") {
      industry = null;
    }

    if (!token) {
      res.json("No token provided");
      return 0;
    }
    if (!count) {
      res.json("No count provided");
      return 0;
    }

    let users = await user.findOne({ where: { token: token } });
    console.log(token);
    if (users == null) {
      res.json("Token not registeres");
      return 0;
    }

    let date_ob = new Date();
    let date = date_ob.getDate();
    let month = date_ob.getMonth() + 1;
    let year = date_ob.getFullYear();
    let date_str = date + "-" + month + "-" + year;
    let filename = "csv_data/website_" + token + "_" + date_str + ".csv";
    console.log(__dirname);
    console.log(__filename);
    console.log(appRoot.path);
    var options = {
      root: path.join(appRoot.path),
    };


    if (fs.existsSync(filename)) {
      console.log("Exists");

      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err);
          return 0;
        } else {
          console.log("Sent:", filename);
        }
      });
      return 0;
    } else {
      const columns = [
        "id",
        "name",
        "url",
        "source",
        "linkedin_id",
        "number",
        "email",
        "gender",
        "skills",
        "position",

        "website_link",
        "connects",
        "followers",
        "about",
        "experience",
      ];

      var query_str = "SELECT * FROM gs_websites WHERE crawl_status = 1"
      if (location) {
        var location_list = []
        if (location == "uk") {
          location_list.push('united kingdom', 'uk')
        } else if (location == "usa") {
          location_list.push('united states', 'usa')
        } else {
          location_list.push(...location.split(','))
        }
        var location_query_str = "";
        for (let i = 0; i < location_list.length; i++) {
          if (location_list[i] != "" && i > 0) {
            location_query_str = location_query_str + ' OR LOWER(web_location) LIKE "%' + location_list[i].toLowerCase() + '%"'
          } else if (location_list[i] != "") {
            location_query_str = location_query_str + ' LOWER(web_location) LIKE "%' + location_list[i].toLowerCase() + '%"'
          }
        }

        if (location_query_str != "") {
          query_str = query_str + " AND (" + location_query_str + ")"
        }
      }

      if (industry) {
        var industry_list = []
        industry_list.push(...industry.split(','))
        var industry_query_str = "";
        for (let i = 0; i < industry_list.length; i++) {
          if (industry_list[i] != "" && i > 0) {
            industry_query_str = industry_query_str + ' OR LOWER(industry) LIKE "%' + industry_list[i].toLowerCase() + '%"'
          } else if (industry_list[i] != "") {
            industry_query_str = industry_query_str + ' LOWER(industry) LIKE "%' + industry_list[i].toLowerCase() + '%"'
          }
        }

        if (industry_query_str != "") {
          query_str = query_str + " AND (" + industry_query_str + ")"
        }
      }


      var [websites, meta] = await seq.query(query_str + '  ORDER BY fetch_status ASC LIMIT ' + count)
      const csvWriter = createCsvWriter({
        path: filename,
      });
      var records = [];
      for (let i = 0; i < websites.length; i++) {
        var site = websites[i];
        var domain = getDomain(site["website"]);
        var [contacts, metadata] = await seq.query(
          'SELECT `email`,`phone` FROM `gs_contacts` WHERE `url` LIKE "%' +
          domain +
          '%";'
        );
        var email_phones = structEmailsPhone(contacts);
        var emails = email_phones[0];
        var phones = email_phones[1];
        var [website_peoples, meta_w] = await seq.query(
          'SELECT DISTINCT(people_websites.people_id) FROM websites INNER JOIN people_websites ON (people_websites.website = websites.id) WHERE websites.website LIKE "%' +
          domain +
          '%"'
        );
        var [url_peoples, meta_p] = await seq.query(
          'SELECT DISTINCT(people.id) FROM people INNER JOIN people_details ON (people_details.people_id = people.id) WHERE people_details.website_link LIKE "' +
          domain +
          '%" OR people_details.email LIKE "%' +
          domain +
          '%"'
        );
        var people_ids = [];
        for (let i = 0; i < website_peoples.length; i++) {
          people_ids.push(website_peoples[i]["people_id"]);
        }
        for (let i = 0; i < url_peoples.length; i++) {
          people_ids.push(url_peoples[i]["id"]);
        }
        records.push([site["id"], "website", domain]);
        records.push(["", "contact us page", site["contact_us_link"]]);
        records.push(["", "contact us page status", site["contact_us_status"]]);
        records.push(["", "group", site["group"]]);
        records.push(["", "location", site["location"]]);
        records.push(["", "Emails", ...emails]);
        records.push(["", "Phone Numbers", ...phones]);
        var people_ids_unique = [...new Set(people_ids)];
        if (people_ids_unique.length > 0) {
          console.log(people_ids_unique);
          var [final_peoples, final_meta] = await seq.query(
            "SELECT * FROM people INNER JOIN people_details ON (people_details.people_id = people.id) WHERE people.id IN (" +
            people_ids_unique.join(",") +
            ")"
          );
          records.push(["", "People Details", ...columns]);
          for (let j = 0; j < final_peoples.length; j++) {
            var experience = final_peoples[j]["experience"];
            var arr = sqlObjToArr(final_peoples[j], experience);
            records.push(["", "", ...arr]);
          }
        }
        records.push(["", ""]);
        records.push(["", ""]);
        var main_site = await gsWebsite.findByPk(site["id"]);
        main_site["fetch_status"] = 1;
        await main_site.save();
      }
      await csvWriter.writeRecords(records);
      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err);
          return 0;
        } else {
          console.log("Sent:", filename);
        }
      });
    }
  } catch (err) {
    res.status(500).json(err);
  }
};

exports.getCompanyData = async (req, res) => {
  try {
    var token = req.query.token;
    var count = req.query.count;
    var location = req.query.location;
    var only_website = req.query.only_website;

    if (!token) {
      res.json("No token provided");
      return 0;
    }
    if (!count) {
      res.json("No count provided");
      return 0;
    }

    if (location == "" || location == " ") {
      location = null;
    }

    let users = await user.findOne({ where: { token: token } });
    console.log(token);
    if (users == null) {
      res.json("Token not registered");
      return 0;
    }

    let date_ob = new Date();
    let date = date_ob.getDate();
    let month = date_ob.getMonth() + 1;
    let year = date_ob.getFullYear();
    let date_str = date + "-" + month + "-" + year;
    let filename = "csv_data/company_" + token + "_" + date_str + ".csv";
    console.log(__dirname);
    console.log(__filename);
    console.log(appRoot.path);
    var options = {
      root: path.join(appRoot.path),
    };
    if (fs.existsSync(filename)) {
      console.log("Exists");

      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err);
          return 0;
        } else {
          console.log("Sent:", filename);
        }
      });
      return 0;
    } else {
      const columns = [
        "id",
        "name",
        "url",
        "source",
        "linkedin_id",
        "number",
        "email",
        "gender",
        "skills",
        "position",

        "website_link",
        "connects",
        "followers",
        "about",
        "experience",
      ];

      var query_str = 'SELECT companies.url, companies.name, companies.fetch_status, company_details.company_id, company_details.website, company_details.location, company_details.number, company_details.linkedin FROM company_details INNER JOIN companies ON (company_details.company_id = companies.id) WHERE company_details.number is not null AND company_details.number != "" AND company_details.number != " "';
      if (location) {
        var location_list = []
        if (location == "uk") {
          location_list.push('united kingdom', 'uk')
        } else if (location == "usa") {
          location_list.push('united states', 'usa')
        } else {
          location_list.push(...location.split(','))
        }
        var location_query_str = "";
        for (let i = 0; i < location_list.length; i++) {
          if (location_list[i] != "" && i > 0) {
            location_query_str = location_query_str + ' OR LOWER(company_details.headquarter) LIKE "%' + location_list[i].toLowerCase() + '%"  OR LOWER(company_details.location) LIKE "%' + location_list[i].toLowerCase() + '%"'
          } else if (location_list[i] != "") {
            location_query_str = location_query_str + ' LOWER(company_details.headquarter) LIKE "%' + location_list[i].toLowerCase() + '%"  OR LOWER(company_details.location) LIKE "%' + location_list[i].toLowerCase() + '%"'
          }
        }

        if (location_query_str != "") {
          query_str = query_str + " AND (" + location_query_str + ")"
        }
      }

      if (only_website == "true") {
        query_str = query_str + ' AND company_details.website is not null AND company_details.website != "" AND company_details.website != " "'
      }


      var [websites, websites_meta] = await seq.query(query_str + '  ORDER BY companies.fetch_status ASC LIMIT ' + count)
      console.log(websites)
      const csvWriter = createCsvWriter({
        path: filename,
      });
      var records = [];
      for (let i = 0; i < websites.length; i++) {
        console.log(i)
        var site = websites[i];
        var people_ids = [];
        var emails = []
        var phones = []
        var domain = ""
        phones.push(site['number'])
        if (site["website"] != " " && site["website"] != "" && site["website"] != null) {
          domain = getDomain(site["website"]);
          var [contacts, metadata] = await seq.query(
            'SELECT `email`,`phone` FROM `gs_contacts` WHERE `url` LIKE "%' +
            domain +
            '%";'
          );
          var email_phones = structEmailsPhone(contacts);
          emails = [...emails, ...email_phones[0]];
          phones = [...phones, ...email_phones[1]];
        }

        console.log("----*")
        records.push([site["id"], "name", site['name']]);
        records.push(["", "website", domain]);
        records.push(["", "url", site['url']]);
        records.push(["", "linkedin", site['linkedin']]);
        records.push(["", "Emails", ...emails]);
        records.push(["", "Phone Numbers", ...phones]);

        records.push(["", ""]);
        records.push(["", ""]);
        var company_ins = await company.findByPk(site["company_id"]);
        company_ins["fetch_status"] = 1 + company_ins["fetch_status"];
        await company_ins.save();
      }
      await csvWriter.writeRecords(records);
      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err);
          return 0;
        } else {
          console.log("Sent:", filename);
        }
      });
    }
  } catch (err) {
    res.status(500).json(err);
  }
};

function structEmails(contacts) {
  var emails = [];
  var phones = [];

  for (let i = 0; i < contacts.length; i++) {
    if (contacts[i]["email"] != null) {
      emails.push({
        email: contacts[i]["email"],
        source: "gs",
        id: contacts[i]["id"],
        url: contacts[i]["url"]
      });
    }
    if (contacts[i]["phone"] != null) {
      phones.push(contacts[i]["phone"]);
    }
  }
  // console.log(emails)
  // console.log(phones)
  return [emails, phones];
}

exports.getWebsiteEmail = async (req, res) => {
  try {
    var token = req.query.token;
    var count = req.query.count;
    if (!token) {
      res.json("No token provided");
      return 0;
    }
    if (!count) {
      res.json("No count provided");
      return 0;
    }
    count = parseInt(count);

    let users = await user.findOne({ where: { token: token } });
    console.log(token);
    if (users == null) {
      res.json("Token not registeres");
      return 0;
    }

    let date_ob = new Date();
    let date = date_ob.getDate();
    let month = date_ob.getMonth() + 1;
    let year = date_ob.getFullYear();
    let date_str = date + "-" + month + "-" + year
    let filename = "csv_data/website_email_" + token + "_" + date_str + ".csv"
    console.log(__dirname)
    console.log(__filename)
    console.log(appRoot.path)
    var options = {
      root: path.join(appRoot.path)
    };
    if (fs.existsSync(filename)) {
      // If file exists return the same file
      console.log("Exists")

      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err)
          return 0
        } else {
          console.log('Sent:', filename);
        }
      });
      return 0
    } else {
      // Select websites in a while loop and start adding emails
      var email_count = 0
      const csvWriter = createCsvWriter({
        path: filename
      });
      var records = [["id", "website", "name", "proffession", "business name", "emails"],
      ["0", "atg.world", "Saurabh Bassi", "CEO", "ATG World", "saurabh@banao.tech"],
      ["0", "atg.world", "Aditya Mathankar", "CMO", "ATG World", "aditya@atg.world"],

      ]

      console.log("/n/nemail count----->", email_count)

      // get contacts from gs_contact
      var [contacts, metadata] = await seq.query("SELECT `id`, `url`, `email`,`phone` FROM `gs_contacts` where email is not null ORDER BY `gs_contacts`.`createdAt` DESC, fetch_status ASC LIMIT " + count + ";");
      var email_phones = structEmails(contacts) // structure and filter email
      var emails = email_phones[0]
      // save emails in a for loop
      var email_l = [];
      for (let i = 0; i < emails.length; i++) {
        // email count is less than required count add email else break the loop
        records.push(["", emails[i]['url'], "", "", "", emails[i]['email']])
        email_l.push(emails[i]['email'])
        console.log(emails[i])
        gs_email = await gsContact.findByPk(emails[i]['id'])
        gs_email['fetch_status'] = 1 + gs_email['fetch_status']
        await gs_email.save()
        email_count++

      }

      await csvWriter.writeRecords(records);
      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err);
          return 0;
        } else {
          console.log("Sent:", filename);
        }
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).json(err);
  }
};


exports.saveYourStoryLink = async (req, res) => {
  try {
    let data = req.body
    console.log(data)
    for (let i = 0; i < data.length; i++) {
      var existing_link = await company.findAll(
        {
          where: {
            url: data[i].url
          }
        }
      )
      if (existing_link.length == 0) {
        var ys = await company.create({ url: data[i].url, name: data[i].name, source: "yourstory" })
      }
    }
    res.json("success")
  } catch (err) {
    people_details.linkedin
    console.log(err)
    res.status(500).json(err)
  }

}

exports.getYourStoryLink = async (req, res) => {
  try {
    const getCompany = await company.findAll({
      order: [["priority", "DESC"]],
      limit: 10,
      // where: { source: "yourstory" },
      where: { status: "not_scraped", source: "yourstory" },
    });
    // console.log(getCompany)
    res.status(201).json(getCompany);
    for (let i = 0; i < getCompany.length; i++) {
      getCompany[i]["status"] = "processing";
      await getCompany[i].save();
    }

  } catch (err) {
    console.log(err)
    res.status(500).json(err)
  }
}
exports.saveYsCompanyDetails = async (req, res) => {
  try {
    let data = req.body
    console.log("start")
    console.log(data)
    let company_id = data.id
    console.log(1)
    let team = data.details.team
    console.log(2)
    let headquarter = data.details.headquarters
    console.log(3)
    let website = data.website
    console.log(4)
    let business_model = data.details.business_model
    let description = data.description
    let founded = data.details.founding_date
    let company_linkedin = null
    try {
      company_linkedin = data.linkedin
    } catch (err) {
      console.log("no linkedin")
    }
    console.log(team)

    let company_ins = await company.findByPk(company_id)
    company_ins['name'] = data.name
    company_ins['status'] = "scraped"
    await company_ins.save()

    var company_details = await companyDetails.findAll({
      where: {
        company_id: company_id
      }
    })
    if (company_details.length > 0) {
      var company_detail = company_details[0]
    } else {
      var company_detail = await companyDetails.create({ company_id: company_id })
    }

    company_detail.description = description
    try {
      company_detail.website = website
    } catch (err) {
      pass
    }
    company_detail.companyType = business_model
    company_detail.headquarter = headquarter
    company_detail.location = headquarter
    company_detail.founded = founded
    await company_detail.save()

    if (team.length > 0) {
      for (let i = 0; i < team.length; i++) {
        const existing_people = await People.findAll({
          where: {
            url: team[i]["linkedin"]
          }
        })

        if (existing_people.length < 1) {
          const addPeople = await new People({
            url: team[i]["linkedin"],
            name: team[i]["name"],
            source: "Linkedin",
          });
          const savePeople = await addPeople.save();
          var pos = ""
          if (team[i].position) {
            pos = team[i].position
          } else {
            pos = "core"
          }

          const addDetails = await new peopleDetails({
            position: pos,
            location: headquarter,
            people_id: savePeople.id,
            linkedin: team[i]["linkedin"],
          });

          const detailsAdded = await addDetails.save();

          const workPeople = await new worksIn({
            company_id: company_ins.id,
            people_id: savePeople.id,
          });
          const saveWork = await workPeople.save();


        }

      }
    }

    if (data.other_url.length > 0) {
      for (let i = 0; i < data.other_url.length; i++) {
        var existing_link = []
        try {
          existing_link = await company.findAll(
            {
              where: {
                url: data.other_url[i]
              }
            }
          )
        } catch (err) {

        }
        if (existing_link.length == 0) {
          var ys = await company.create({ url: data.other_url[i], source: "yourstory" })
        }
      }
    }
    res.json("success")


  } catch (err) {
    console.log(err)
    res.status(500).json(err)
  }
}

function structContacts(contacts) {
  var main_l = []
  for (let i = 0; contacts.length > i; i++) {
    var contact = contacts[i]
    main_l.push([contact['id'], contact['location'], contact['email'], contact['phone'], contact['url']])
  }
  return main_l
}

exports.getContacts = async (req, res) => {
  try {
    var token = req.query.token;
    var count = req.query.count;
    var location = req.query.location;
    if (!token) {
      res.json("No token provided");
      return 0;
    }
    if (!count) {
      res.json("No count provided");
      return 0;
    }
    count = parseInt(count);

    let users = await user.findOne({ where: { token: token } });
    console.log(token);
    if (users == null) {
      res.json("Token not registered");
      return 0;
    }

    let date_ob = new Date();
    let date = date_ob.getDate();
    let month = date_ob.getMonth() + 1;
    let year = date_ob.getFullYear();
    let date_str = date + "-" + month + "-" + year
    let filename = "csv_data/website_contact_" + token + "_" + date_str + ".csv"
    console.log(__dirname)
    console.log(__filename)
    console.log(appRoot.path)
    var options = {
      root: path.join(appRoot.path)
    };
    if (fs.existsSync(filename)) {
      // If file exists return the same file
      console.log("Exists")

      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err)
          return 0
        } else {
          console.log('Sent:', filename);
        }
      });
      return 0
    } else {
      // Select websites in a while loop and start adding emails
      var email_count = 0
      const csvWriter = createCsvWriter({
        path: filename
      });
      var records = [["id", "location", "email", "phone", "url"]]

      while (email_count < count) {
        var [websites, web_meta] = await seq.query("SELECT website FROM gs_websites WHERE fetch_status=0 AND LOWER(web_location) LIKE '%" + location + "%' AND website like '%.in%' LIMIT 1")

        if (websites.length == 0) {
          break
        }

        for (let i = 0; i < websites.length; i++) {
          domain = getDomain(websites[i]['website'])
          var [contacts, metadata] = await seq.query("SELECT `id`,`location`, `email`, `phone`, `url` FROM `gs_contacts` WHERE phone IS NOT NULL AND url LIKE '%" + domain + "%';");
          // var email_phones = structEmails(contacts) // structure and filter email
          // var emails = email_phones[0]
          // save emails in a for loop
          // var email_l = [];
          console.log(contacts)
          for (let j = 0; j < contacts.length; j++) {
            gs_email = await gsContact.findByPk(contacts[j]['id'])
            gs_email['fetch_status'] = 1
            await gs_email.save()
          }

          var contacts_structed = structContacts(contacts)
          records = [...records, ...contacts_structed]
        }
        email_count++
      }


      await csvWriter.writeRecords(records);
      res.sendFile(filename, options, function (err) {
        if (err) {
          console.log(err);
          res.json(err);
          return 0;
        } else {
          console.log("Sent:", filename);
        }
      });
    }
  } catch (err) {
    console.log(err);
    res.status(500).json(err);
  }
};
exports.getUnknownPeople = async (req, res) => {
  try {
    let count = req.query.count;
    let count2 = parseInt(count);
    let unknown = await unknownPeople.findAll({
      where: {
        is_scraped: '0'
      },
      limit: (typeof count === 'undefined') ? 5 : count2
    })
    let unknown_people = [];
    class person {
      constructor(id, name, location, position) {
        this.id = id;
        this.company_name = name;
        this.location = location;
        this.position = position;
      }
    }
    for (let i = 0; i < unknown.length; i++) {
      let comp_name = await company.findOne({
        where: {
          id: unknown[i].company_id
        },
      })
      let temp = new person(unknown[i].id, comp_name.name, unknown[i].location, unknown[i].position)
      unknown_people.push(temp);
      unknownPeople.update({
        is_scraped: '1'
      },
        {
          where: { id: unknown[i].id }
        });
    }
    res.json(unknown_people);
  }
  catch (err) {
    console.log(err)
    res.json(err)
  }
};
exports.saveUnknownPeople = async (req, res) => {
  try {
    let details = req.body;
    let people = details.people;
    let status = details.status;
    if (status == 'success') {
      for (let i = 0; i < people.length; i++) {
        await People.create({
          name: people[i].name,
          url: people[i].url,
          status: "scraped",
        });
        let getId = await People.findOne({
          where: {
            name: people[i].name,
          }
        })
        await peopleDetails.create({
          people_id: getId.id,
          position: people[i].position,
        });
      }
      await unknownPeople.update({
        is_scraped: '2'
      },
        {
          where: { id: details.id }
        });

      res.json("success")
    }
    else {
      res.json("Error in sending data");
    }
  }
  catch (err) {
    res.json(err)
  }
};
exports.startTime = async (req, res) => {
  try {
    Global_id = 0;
    Global_user_id = 0;
    let cur_time = req.body.time;
    const reqtoken = req.headers["auth"];
    const userData = await userModel.findOne({ where: { token: reqtoken } });
    Global_user_id = userData.id;
    Global_date = cur_time;
    let id_from_db = await userStats.create({
      start_time: cur_time,
      user_id: userData.id,
    });
    Global_id = id_from_db.id;

    res.json("success");

  }
  catch (err) {
    res.json(err)
  }
}
exports.userStats = async (req, res) => {
  try {
    console.log("here----", req.body)
    const reqtoken = req.headers["auth"];
    const userData = await userModel.findOne({ where: { token: reqtoken } });
    const date = new Date();
    const startOfDay = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    const endOfDay = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59);
    let newMessages = []
    for (let i = 0; i < req.body.messageDetails.length; i++) {
      const connectionDet = await userConnectionDetails.findOne({
        where: { connection_name: req.body.messageDetails[i].name }
      })
      console.log(connectionDet)
      try {
        if (companyDetails != null) {
          connectionDet.isMessaged = 1;
          await connectionDet.save()
        }
        else {
          console.log(req.body.messageDetails[i])
          newMessages.push(req.body.messageDetails[i])
        }
      } catch (e) {
        console.log(e)
      }

    }
    console.log(newMessages)
    try {

      for (let i = 0; i < req.body.accepted.length; i++) {
        let status = 0;
        for (let j = 0; j < newMessages.length; j++) {
          if (req.body.accepted[i].name === newMessages[j].name) {
            status = 1;
            break;
          }
        }
        const connectionDet = await new userConnectionDetails({
          user_id: userData.id,
          connection_name: req.body.accepted[i].name,
          accept_date: req.body.accepted[i].time,
          isMessaged: status
        })
        await connectionDet.save()
      }
    } catch (e) {
      console.log(e)
    }

    if (userData.id == Global_user_id) {
      const dateArray = Global_date.split(" ")[0].split("-");

      const user = await userStats.findAll({
        where: {
          user_id: Global_user_id,
          start_time: {
            [Op.startsWith]: `%${dateArray[0] + '-' + dateArray[1] + '-' + dateArray[2]}%`
          }
        },
        attributes: [[sequelize.fn('max', sequelize.col('runCount')), 'max']]
      });
      const prev_stat = await userStats.findAll({
        where: {
          user_id: Global_user_id,
          start_time: {
            [sequelize.Op.not]: Global_date
          }
        },
        attributes: [[sequelize.fn('max', sequelize.col('connectionCount')), 'max']]
      });
      let peopleName = await userStats.findAll({
        where: {
          user_id: Global_user_id,
        },
        attributes: ['people']
      });
      console.log(peopleName)
      let people_from_db = []
      for (let i = 0; i < peopleName.length; i++) {
        if (peopleName[i].dataValues.people != null) {
          for (let j = 0; j < peopleName[i].dataValues.people.length; j++) {
            people_from_db.push(peopleName[i].dataValues.people[j])
          }
        }
      }
      console.log(people_from_db)

      peopleName_fn = await filter(req.body.invites, people_from_db)


      console.log("Global_id =" + Global_id + "Global_user_id =" + Global_user_id + "Global_date =" + Global_date);

      console.log(peopleName_fn);


      await userStats.update({
        createdAt: {
          [Op.gte]: startOfDay,
          [Op.lt]: endOfDay
        },
        runCount: user[0].dataValues.max + 1,
        connectionGrowth: req.body.connectionCount - prev_stat[0].dataValues.max,
        connectionCount: req.body.connectionCount,
        invitesCount: req.body.invites.length,
        extensionName: req.body.extension,
        extensionVersion: req.body.version,
        messageCount: req.body.messageDetails.length,
        messageDetails: req.body.messageDetails,
        people: peopleName_fn,
        createdAt: date,
      }, {
        where: {
          id: Global_id,
          user_id: Global_user_id
        }
      });
    }
    else {
      console.log("something went wrong")
    }

    res.json("success")
  } catch (error) {
    res.status(500).json(`some error occured in getting the request ${error}`)
  }
}
exports.userStats2 = async (req,res)=>{
  try{
    console.log("here----",req.body)
    const date = new Date(); 
    // const reqtoken = "test";

    const reqtoken = req.headers["auth"];
    const userData = await userModel.findOne({ where: { token: reqtoken } });

    for (let i = 0; i < req.body.invites.length; i++) {
      const findInvitesDet = await userInvitationDetails.findOne({
        where: {
          user_id: userData.id,
          connection_name: req.body.invites[i].name,
          send_date: req.body.invites[i].time
        }
      })
      if (findInvitesDet === null) {
        const invitesDet = await new userInvitationDetails({
          user_id: userData.id,
          connection_name: req.body.invites[i].name,
          send_date: req.body.invites[i].time
        })
        await invitesDet.save()
      }
    }
    let newMessages = []
    for (let i = 0; i < req.body.messageDetails.length; i++) {
      const connectionDet = await userConnectionDetails.findOne({
        where: { user_id: userData.id, connection_name: req.body.messageDetails[i].name }
      })
      console.log(connectionDet)
      try {
        if (connectionDet !== null) {
          connectionDet.isMessaged = 1;
          await connectionDet.save()
        }
        else {
          console.log(req.body.messageDetails[i])
          newMessages.push(req.body.messageDetails[i])
        }
      } catch (e) {
        console.log(e)
      }

    }
    console.log(newMessages)
    for (let i = 0; i < req.body.accepted.length; i++) {
      let status = 0;
      for (let j = 0; j < newMessages.length; j++) {
        if (req.body.accepted[i].name === newMessages[j].name) {
          status = 1;
          break;
        }
      }
      //there are two table 
      //userInvitationDetails ---- stores the invitations send and the sent date 
      // userConnectionDetails --- stores the connections and the accept date
      // the connection table also stores the status isMessaged and reqSendThatday
      // the isMessaged stores if the connection has been messaged or not
      // reqSendThatday stores if the connection request was send on the same day it was accepted

      //reqSendThatday logic:
      // with the connection accepted name and the userId we check in the invitation table if the name is presend or not 
      // if not data not found the invitation was sent on the same day itself


      const findInInvitations = await userInvitationDetails.findOne({
        where: { user_id: userData.id, connection_name: req.body.accepted[i].name }
      })
      if (findInInvitations === null) {
        var reqSendThatDay = 1
      }
      else {
        var reqSendThatDay = 0
      }
      const findConnectionDet = await userConnectionDetails.findOne({
        where: { user_id: userData.id, connection_name: req.body.accepted[i].name }
      })
      // console.log("findconn", findConnectionDet)
      if (findConnectionDet === null) {
        const connectionDet = await new userConnectionDetails({
          user_id: userData.id,
          connection_name: req.body.accepted[i].name,
          accept_date: req.body.accepted[i].time,
          isMessaged: status,
          reqSendThatDay: reqSendThatDay
        })
        await connectionDet.save()
        console.log("added")
      }


    }
    const conversations = req.body.messageDetails
    for (let i = 0; i < conversations.length; i++) {
      const getConnection = await userConnectionDetails.findOne({
        where: { user_id: userData.id, connection_name: conversations[i].name }
      })
      if (getConnection) {
        let msgDays = conversations[i].messages
        if (msgDays)
          for (let j = 0; j < msgDays.length; j++) {
            const convo = msgDays[j].messages
            for (let k = 0; k < convo.length; k++) {
              // console.log(convo)
              let msgs = convo[k].messageDetails
              for (let m = 0; m < msgs.length; m++) {
                try {
                  const findMsg = await messagesModel.findOne({
                    where: {
                      user_id: userData.id,
                      connection_id: getConnection.id,
                      sendDate: msgDays[j].date,
                      message: msgs[m],
                      time: convo[k].time,
                    }
                  })
                  //console.log(findMsg)
                  if (findMsg === null) {
                    const saveMessages = await new messagesModel({
                      user_id: userData.id,
                      connection_id: getConnection.id,
                      sendDate: msgDays[j].date,
                      message: msgs[m],
                      time: convo[k].time,
                      sender: convo[k].name,
                    })
                    await saveMessages.save();
                  }
                } catch (error) {
                  console.log(error, msgs[m])
                }
              }

            }

          }
      }
    }


    const userstats = await new userStats({
      user_id: userData.id,
      extensionName: req.body.extension,
      connectionCount: req.body.connectionCount,
      invitesCount: req.body.invites.length,
      connections: req.body.accepted,
      people: req.body.invites,
      messageCount: req.body.messageDetails.length,
      messageDetails: req.body.messageDetails,
      extensionVersion: req.body.version,
      createdAt: date,
    })
    await userstats.save()
    res.status(200).json("success")
  } catch (e) {
    console.log(e)
    res.status(500).json(`some error occured in getting the request ${e}`)
  }
}
exports.getMessages = async (req, res) => {
  try {
    const date = req.body.date;
    const token = req.body.token;
    console.log(date, token)
    let msgs = []
    const userData = await userModel.findOne({
      where: { token: token }
    })
    const msgedThatDay = await userConnectionDetails.findAll({
      where: { user_id: userData.id, accept_date: date, isMessaged: 1 }
    })
    if (msgedThatDay) {
      for (let i = 0; i < msgedThatDay.length; i++) {

        const getMessages = await messagesModel.findAll({
          where: {
            user_id: userData.id,
            connection_id: msgedThatDay[i].id,
          }
        })
        let details = {
          "name": msgedThatDay[i].connection_name,
          "msgDetails": getMessages
        }
        msgs.push(details)

      }
    }

    res.status(200).json(msgs)
  } catch (e) {
    res.status(500).json(`some error ${e}`)
  }
}
async function filter(array1, array2) {
  const set2 = new Set(array2);
  const notPresent = [];

  for (let i = 0; i < array1.length; i++) {
    if (!set2.has(array1[i])) {
      notPresent.push(array1[i]);
    }
  }

  console.log(notPresent); // ["apple", "banana"]
  return notPresent;
}
exports.saveCompanyName = async (req, res) => {
  try {
    let data = req.body;
    Object.keys(data["name"]).forEach(async function (key) {
      await tempCompanies.findOrCreate({
        where: { name: data["name"][key] },
        defaults: { is_searched: 0 }
      })
        .then(([result, created]) => {
          // result is an instance of your model representing the row found or created
          // created is a boolean indicating whether a new row was created (true) or an existing row was found (false)
          if (created) {
            console.log("created");
          }
          else {
            console.log("not created");
          }
        })
        .catch(error => {
          console.error(error);
        });
    });

    res.json("success");
  }
  catch (err) {
    res.json(err)
  }
}
exports.editCompanyDetails = async (req, res) => {
  try {
    let data = req.body;
    console.log(data)
    // const findUser = await userModel.findOne({
    //   where:{token: data.token}
    // })
    let company = await tempCompanies.findOne({ where: { id: data.company_id } })
    console.log(company)
    if (company) {

      company.linkedin_profile = data.linkedin_profile ? data.linkedin_profile : company.linkedin_profile
      company.origin = data.origin ? data.origin : company.origin
      company.status = 1
      const success = await company.save();
      res.status(200).json({ "success": true, message: "Company details updated" })
    }
    else
      res.stats(500).json({ "success": false, "message": "no company with this id found" })
  } catch (error) {
    console.log(error)
    res.status(500).json({ "success": false, message: error.message })
  }
}
exports.getCompanyName = async (req, res) => {
  try {
    let count = req.query.count;
    let count2 = parseInt(count);
    // let data = await tempCompanies.findAll({
    //   where: {
    //     is_searched: 0
    //   },
    //   limit: (typeof count === 'undefined')? 3 :count2
    // });

    // for(let i=0; i<data.length; i++){
    //   await tempCompanies.update({
    //     is_searched: 1
    //   },
    //   {
    //     where: {id:data[i].id}
    //   });
    // }
    const dataToBeUpdated = await tempCompanies.findAll({
      attributes: ['id'],
      where: {
        is_searched: 0
      },
      limit: (typeof count === 'undefined') ? 3 : count2
    });

    const idsToBeUpdated = dataToBeUpdated.map((row) => row.id);

    await tempCompanies.update(
      { is_searched: 1 },
      {
        where: {
          id: {
            [Op.in]: idsToBeUpdated
          }
        }
      }
    );

    const updatedData = await tempCompanies.findAll({
      where: {
        id: {
          [Op.in]: idsToBeUpdated
        }
      }
    });

    console.log(updatedData);


    res.json(updatedData);
  }
  catch (err) {
    res.json(err)
  }
}

exports.getCompanyNameForBing = async (req, res) => {
  try {
    reqToken = req.headers["auth"];
    const User = await user.findOne({
      raw: true,
      where: { token: reqToken },
    });
    if (User === null) {
      res.json("user blocked");
    }
    else {
      const names = [];

      const companies = await company.findAll({
        where: {
          '$company_detail.location$': null,
          id: {
            [Op.notIn]: Array.from({ length: 83 }, (_, i) => i + 1)
          },
          bing_search: 0,
          name: {
            [Op.not]: ''
          }
        },
        include: {
          model: companyDetails,
          required: false,
        },
        limit: User.CompanyCount,
        attributes: ['name', 'id'],
      });

      for (const company of companies) {
        await company.update(
          { bing_search: 1 },
          {
            where: {
              id: company.dataValues.id
            }
          }
        );
        names.push({ name: company.name, id: company.id });
      }
      res.json(names);
    }
  }
  catch (err) {
    res.json(err)
  }
}

exports.saveLocations = async (req, res) => {
  const data = data_preprocess(req.body.paragraph);
  const links = links_preprocess(req.body.links);
  const bing_id_to_save = req.body.bing_id_to_save;
  console.log(bing_id_to_save);
  let location_array = "";
  console.log("data length : " + data.length)
  console.log("company length : " + links.companyLinks.length)
  console.log("linkdin length : " + links.linkedinLinks.length)

  console.log(data);
  console.log(links.companyLinks);
  console.log(links.linkedinLinks);


  if (data.length !== 0 || links.companyLinks.length !== 0 || links.linkedinLinks.length !== 0) {
    if (data.length !== 0) {
      for (let i = 0; i < data.length; i++) {
        location_array += data[i];
        location_array += ",";
      }
    }
    else {
      location_array = "Not Found";
    }

    if (links.companyLinks.length === 0) {
      links.companyLinks = "Not Found";
    }
    if (links.linkedinLinks.length === 0) {
      links.linkedinLinks = "Not Found";
    }

    try {
      const result = await companyDetails.findAndCountAll({
        where: {
          company_id: bing_id_to_save
        }
      });
      const rowsCount = result.count;
      const rows = result.rows;

      if (rowsCount > 0 && rows) {
        const existingRecord = rows[0];

        const shouldUpdateLocation = !existingRecord.location;
        const shouldUpdateWebsite = !existingRecord.website;
        const shouldUpdateLinkedin = !existingRecord.linkedin;

        if (shouldUpdateLocation || shouldUpdateWebsite || shouldUpdateLinkedin) {
          const updates = {};

          if (shouldUpdateLocation) {
            updates.location = location_array;
          }

          if (shouldUpdateWebsite) {
            updates.website = JSON.stringify(links.companyLinks);
          }

          if (shouldUpdateLinkedin) {
            updates.linkedin = JSON.stringify(links.linkedinLinks);
          }

          await companyDetails.update(updates, {
            where: { company_id: bing_id_to_save }
          });

          console.log(`Location, website, and LinkedIn updated for company ${bing_id_to_save}.`);
        } else {
          console.log(`Record already exists for company ${bing_id_to_save}.`);
        }
      } else {
        await companyDetails.create({
          location: location_array,
          website: JSON.stringify(links.companyLinks),
          linkedin: JSON.stringify(links.linkedinLinks),
          company_id: bing_id_to_save
        });

        console.log(`New record created for company ${bing_id_to_save}.`);
      }

    } catch (error) {
      console.log(error);
    }
    await company.update({ bing_search: 2 }, { where: { id: bing_id_to_save } });
  }
  else {
    console.log("no location found");
  }
  res.send({ 'message': 'success' })
}
const data_preprocess = (para) => {
  const text_commas = para;
  const text = _.replace(text_commas, /,/g, '');

  const words = text.split(' ');
  const preprocessedWords = words.map((word) => word.replace(/\d+/g, ''));

  const commaSeparatedWords = _.join(preprocessedWords, ', ');

  const doc = nlp(commaSeparatedWords);
  const locations = doc.places().data().map((place) => place.text);
  return locations;
}
const links_preprocess = (links) => {
  const linkedinRegex = /^https?:\/\/(www\.)?linkedin\.com\/company\/[a-zA-Z0-9-._~:/?#[\]@!$&'()*+,;=]+$/;
  const companyRegex = /^https?:\/\/[a-zA-Z0-9-._~:/?#[\]@!$&'()*+,;=]+$/;

  const linkedinLinks = new Set();
  const companyLinks = new Set();


  for (let i = 0; i < links.length; i++) {
    if (linkedinRegex.test(links[i])) {
      linkedinLinks.add(links[i]);
    } else if (companyRegex.test(links[i])) {
      companyLinks.add(links[i]);
    }
  }
  return {
    linkedinLinks: Array.from(linkedinLinks),
    companyLinks: Array.from(companyLinks)
  };
}
exports.addUser = async (req, res) => {
  try {
    const foundRecords = [];
    const shortUrls = [];
    let latest_id_from_short_url_table = parseInt(await latestIdFromShortenUrlTable());

    for (const record of req.body) {
      const foundRecord = await user.findOne({
        where: {
          token: record.token,
        },
      });

      if (foundRecord) {
        foundRecords.push(foundRecord);
      } else {
        await user.create(record);
        console.log(record.token, record.location, record.captain)
        latest_id_from_short_url_table = latest_id_from_short_url_table + 1;
        console.log('i m at add user' + latest_id_from_short_url_table, typeof (latest_id_from_short_url_table));
        const shortUrl = await short_the_url(record.token, record.location, record.captain, latest_id_from_short_url_table);
        shortUrls.push(shortUrl);
      }
    }

    if (foundRecords.length === 0) {
      res.send("No existing users found");
    } else {
      const filteredUsers = foundRecords.map(user => {
        return {
          name: user.name,
          token: user.token
        };
      });

      const csvStream = csv.format({ headers: true }).transform(row => [row.name, row.token]);
      res.setHeader('Content-disposition', 'attachment; filename=users.csv');
      res.set('Content-Type', 'text/csv');
      csvStream.pipe(res);
      filteredUsers.forEach(item => csvStream.write(item));
      csvStream.end();

      // wait for all promises to resolve before sending the short URLs
      await Promise.all(shortUrls);
      console.log(shortUrls);
      console.log("All short URLs generated successfully");
    }
  } catch (e) {
    res.status(500).send(`Error: ${e}`);
  }
};

const short_the_url = async (token, location, captain, latest_id) => {
  try {
    const user_details = await user.findOne({ where: { token: token } });
    const url = `http://intranet.atg.party:8989/api/get-people-email?token=${token}&count=${user_details.dataValues.CompanyCount}&location=${location}`;
    console.log(url);
    const existingUrl = await shortenUrl.findOne({ where: { url: url } });
    if (existingUrl) {
      return "https://bbd.atg.party/short/" + existingUrl.dataValues.short_url;
    } else {
      const shortUrl_string = base62Encode(latest_id);
      const shortUrl = await shortenUrl.create({
        url: url,
        short_url: shortUrl_string,
        created_by: captain
      });
      return "https://bbd.atg.party/short/" + shortUrl.dataValues.short_url;
    }
  } catch (e) {
    console.log(e);
  }
};
const latestIdFromShortenUrlTable = async () => {
  const latestRow = await shortenUrl.findOne({
    order: [['created_at', 'DESC']],
    attributes: ['id'],
  });
  const latest_id = latestRow ? latestRow.id : 0;
  console.log("i am at latestidfrom function" + latest_id, typeof (latest_id));
  return latest_id;
}

exports.shortenUrl = async (req, res) => {
  try {
    let url = req.query.url;
    let token = req.query.token;
    let redirectUrl = "";
    const user_details = await user.findOne({ where: { token: token } });
    if (user_details && user_details.dataValues.type === "Admin") {
      const existingUrl = await shortenUrl.findOne({ where: { url: url } });
      if (existingUrl) {
        redirectUrl = "url already exist : https://bbd.atg.party/short/" + existingUrl.dataValues.short_url;
      } else {
        const latestRow = await shortenUrl.findOne({
          order: [['created_at', 'DESC']],
          attributes: ['id'],
        });
        const latestId = latestRow ? latestRow.id : 0;
        const shortUrl_string = base62Encode(latestId + 1);
        const newUrl = await shortenUrl.create({
          url: url,
          short_url: shortUrl_string,
          created_by: user_details.dataValues.name,
        });
        console.log('New URL created:', newUrl.dataValues.shortUrl);
        redirectUrl = "shorturl : https://bbd.atg.party/short/" + shortUrl_string;
      }
      res.json({ "message": redirectUrl });
    }
    else if (user_details) {
      res.json({ "message": "You don't have permission to shorten url" });
    }
    else {
      res.json({ "message": "wrong or invalid token" });
    }
  }
  catch (err) {
    console.log(err);
    res.json(err);
  }
}
const base62chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
function base62Encode(num) {
  num = num + 10;
  let encoded = "";
  while (num) {
    let remainder = num % 62;
    num = Math.floor(num / 62);
    encoded = base62chars[remainder].toString() + encoded;
  }
  console.log('encoded');
  return encoded;
}

exports.redirectUrl = async (req, res) => {
  try {
    let shortUrl = req.params.shortUrl;
    let url_string = await shortenUrl.findOne({
      where: {
        short_url: shortUrl,
      },
      attributes: ['url'],
    });

    if (!url_string) {
      res.send("url not found")
    }
    else {
      res.redirect(url_string.dataValues.url);
    }
  }
  catch (err) {
    res.send(err);
  }
}
exports.checkUrl = async (req, res) => {
  try {
    const url_token = req.query.short_url.split("/").pop();
    const user_name = await user.findOne({ where: { token: req.query.token } });
    console.log(url_token);
    if (user_name && user_name.dataValues.type === "Admin") {
      const url_string = await shortenUrl.findOne({
        where: {
          short_url: url_token,
          created_by: user_name.dataValues.name,
        },
        attributes: ['url'],
      });
      if (!url_string) {
        res.send({ "message": false })
      }
      else {
        res.json({ "message": true });
      }
    }
    else if (user_name) {
      res.json({ "message": "You don't have permission to check url" });
    }
    else {
      res.json({ "message": "wrong or invalid token" });
    }
  }
  catch (err) {
    console.log(err);
    res.json(err);
  }
}
exports.editUrl = async (req, res) => {
  try {
    const long_url = req.query.long_url;
    const short_url = req.query.short_url.split("/").pop();
    const user_name = await user.findOne({ where: { token: req.query.token } });

    const is_update = await shortenUrl.update(
      { url: long_url },
      { where: { short_url: short_url, created_by: user_name.dataValues.name } }
    );
    if (is_update[0] === 0) {
      res.json({ "message": "same url exist" });
    }
    else {
      res.json({ "message": "url updated successfully" });
    }
  }
  catch (err) {
    console.log(err);
    res.json(err);
  }
}
exports.removeUserFromBbddashboard = async (req,res) =>{
  try{
    let ids_to_block = req.body.users;
    console.log(ids_to_block);
    let token = req.body.token;
    user_role = await user.findOne({ where: { token: token } });
    console.log(user_role);
    if(user_role && user_role.dataValues.type === "Admin" || user_role.dataValues.type === "Captain"){
      for (let i = 0; i < ids_to_block.length; i++) {
        const userToUpdate = await user.findOne({ where: { id: ids_to_block[i] } });
        console.log(userToUpdate);
        if (userToUpdate.dataValues.status !== "Blocked") {
          await user.update({ status: "Blocked" },
          { where: { id: ids_to_block[i] }}

          );
        }
        else {
          console.log("user already blocked");
        }
      }
    }
    else {
      res.json({ "message": "You don't have permission to remove user" });
    }
    res.json({ "message": "user blocked successfully" });
  }
  catch (err) {
    console.log(err);
    res.json(500).send(`error: ${err}`);
  }
}

exports.companyWithoutLocationHeadquarter = async (req, res) => {
  let token = req.params.token;
  let ver = req.params.ver;
  let comps = await company.findAll({
    where: {
      source: 'Linkedin',
      status: 'not_scraped',
      linkedin_api_location_searched: 0,
      searchStatus:'searched',
      url : {
        [Op.notLike] : "https://www.linkedin.com/showcase%"
      }
    },
    attributes: ['id', 'url'],
    limit: 10,
  });

  let run_id = req.headers['run_id']
  if (!run_id) {
    let user = await userModel.findOne({where:{token:req.headers['auth'], status:"Active" }});
    let user_stats_obj = await userStats.create({
      user_id: user.id,
      extensionName:'linkedin_api_exe',
      runCount:0
    })
    run_id = user_stats_obj.id
  }
  for (let i = 0; i < comps.length ; i++) {
    await comps[i].update({linkedin_api_location_searched:2})

  }
  console.log('data')
  console.log(comps)

  if (ver==2){
    res.send(comps)
  } else {
    res.send({data:comps,run_id:run_id})
  }

}


exports.saveHeadQuarterByCompanyDetailsId = async (req, res) => {
  try {
    let id = req.body.id;
    let headquarter = req.body.headquarter;
    let priority_increase = 0;
    if (headquarter.startsWith('IN ')) {
      priority_increase = 5 // increase priority for indian company
    }
    let company_details = await companyDetails.findOne({
      where: {
        company_id: id
      }
    })
    if (company_details) {
      await company_details.update({
        headquarter: headquarter,
        linkedin_api_searched: 1
      })
    } else {
      await companyDetails.create({
        company_id: id,
        headquarter: headquarter,
      });
    }
    let comp = await company.findOne({where : {id : id}})
    await comp.update({linkedin_api_location_searched: 1, priority: comp.priority + priority_increase})
    res.json({"message":"headquarter updated successfully"});
  }
  catch (err) {
    console.log(err);
    res.json(500).send(`error: ${err}`);
  }

}

exports.getUnscrapedTwitterLinksCompanies = async (req, res) => {
  try {
    const limit = 10;
    const companies =  await companyDetails.findAll({
      where: {
        isScraped_twitter: 0,
        twitter: {
          [Op.and]: [
            {[Op.not]: null},
            {[Op.not]: ''}
          ]
        },
        company_id: {
          [Op.not]: null,
        }
      }, 
      limit: limit,
      attributes: ["company_id","twitter"],
      raw: true
    });
    const companyIds = companies.map((company) => company.company_id);
    await companyDetails.update(
      { isScraped_twitter: 1 },
      {
        where: {
          company_id: {
            [Op.in]: companyIds
          }
        }
      }
    );
    res.status(200).json(companies);
    console.log("Unscraped twitter companies: ", companies);
  } catch (err) {
    console.log(err);
    res.status(500).json({error: "Internal server error"});
  }
};

exports.addDataToCompanyDetails = async(req, res) => {
  const {name, bio, location, category, website_link, following, followers, tweets, company_id} = req.body;
  try {
    const company = await companyDetails.findOne({
      where:{ company_id: company_id },
      attributes: ["company_id"]
    });
    if (company) {
      const data = {
        name: name,
        description: bio,
        location: location,
        category: category,
        website: website_link,
        following: following,
        followers: followers,
        tweets: tweets
      };
      await companyDetails.update(data, {where:{ company_id: company_id }} );
      await companyDetails.update({ isScraped_twitter: 2 }, { where: { company_id: company_id } });
      return res.status(200).send('Data saved successfully');
    } else {
      return res.status(400).send("Company not found");
    }
  } catch(err) {
    console.log(err);
    return res.status(500).send('Internal server error');
  }
};
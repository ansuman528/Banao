const Company = require("../models/company");
const CompanyDetails = require("../models/company_details");
const People = require("../models/people");
const PeopleDetails = require("../models/people_details");
const CompanyEmail=require("../models/company_email");
const CompanyPhone=require("../models/company_phone");
const Emails = require("../models/emails");
const Phones = require("../models/phones");
const WorksIn = require("../models/worksIn");
const GsWebsite = require("../models/gs_website");
const GsContact = require("../models/gs_contact");
const MlPeople = require("../models/ml_people");
const { restart } = require("nodemon");
const { where } = require("sequelize");

exports.saveExternalCompanyDetails=async(req,res)=>{
  try{
    let 
    companyDetails=req.body,
    name="",
    origin="",
    website="",
    category="",
    description="",
    founded="",
    likedin="",
    facebook="",
    twitter="",
    play_store="",
    app_store="",
    location="",
    rank="",
    headquarter="",
    companyMessage="",
    totalPeopleCount=0,
    addedPeopleCount=0;
    console.log(companyDetails)
    if(companyDetails.name)
     name=companyDetails.name;
  
    if(companyDetails.origin)
     origin=companyDetails.origin;
  
    if(companyDetails.website)
     website=companyDetails.website;
  
    if(companyDetails.category)
     category=companyDetails.category;
  
    if(companyDetails.description)
     description=companyDetails.description;
  
    if(companyDetails.founded)
     founded=companyDetails.founded;
  
    if(companyDetails.likedin)
     likedin=companyDetails.likedin;
  
    if(companyDetails.facebook)
     facebook=companyDetails.facebook;
  
    if(companyDetails.twitter)
     twitter=companyDetails.twitter;
  
    if(companyDetails.play_store)
     play_store=companyDetails.play_store;
  
    if(companyDetails.app_store)
     app_store=companyDetails.app_store;
  
    if(companyDetails.location)
     location=companyDetails.location;
  
    if(companyDetails.rank)
     rank=companyDetails.rank;
  
    if(companyDetails.headquarter)
     headquarter=companyDetails.headquarter;
  
    if(name.length===0)
     name=website;
    
    if(origin.length==0)
     return res.status(400).json({"message":"company must have an origin"});

    if(name.length==0)
      return res.status(500).json({"message":"company must have a name or website"});

    let company = null,company_details=null;
    company=await Company.findOne({
      where: { name:name },
    });
    if(company==null)
    {
      company=await new Company({
              name,
              origin
      });
      await company.save();
      company_details=new CompanyDetails({
          company_id:company.id,
          name,
          origin,
          website,
          category,
          description,
          founded,
          likedin,
          facebook,
          twitter,
          play_store,
          app_store,
          location,
          rank,
          headquarter,
          priority:5
      });
      await company_details.save();
      companyMessage="new company created";
    }
    else{
      companyMessage="company already exists";
    }
      const employees=companyDetails.people;
      totalPeopleCount=employees.length;
      if(employees && employees.length!=0)
      {
          for(let i=0;i<employees.length;i++)
          {
              let person=null,personDetails=null;
              let personName="",personLocation="",personLinkedin="",personFacebook="",personTwitter="",personPosition="",personLink="",personWebsite="";
              
              if(employees[i].linkedin&&employees[i].linkedin.length!=0)
               personLinkedin=employees[i].linkedin;
              
              if(employees[i].location&&employees[i].location.length!=0)
               personLocation=employees[i].location;

              if(personLocation.length===0)
               personLocation=location;

              if(employees[i].name && employees[i].name.length!=0)
               personName=employees[i].name;
              
              if(employees[i].facebook && employees[i].facebook.length!=0)
               personFacebook=employees[i].facebook;
              
              if(employees[i].twitter && employees[i].twitter.length!=0)
                personTwitter=employees[i].twitter;
              
              if(employees[i].position && employees[i].position.length!=0)
                personPosition=employees[i].position;
              
              if(employees[i].link && employees[i].link.length!=0)
                personLink=employees[i].link;
              
              if(employees[i].website && employees[i].website.length!=0)
                personWebsite=employees[i].website;
              
              if(personLinkedin==null)
               continue;
              
              person=await People.findOne({
                  where:{url:personLinkedin }
              })
              personDetails=await PeopleDetails.findOne({
                where:{linkedin:personLinkedin}
              })
              if(person==null)
               {
                  person=await new People({
                      name:personName,
                      url:personLinkedin,
                      linkedin_id:personLinkedin,
                      origin
                  });
                  await person.save();
                  console.log("new person")
               }
               if(personDetails==null)
               {
                
                    personDetails=await new PeopleDetails({
                      people_id:person.id,
                      company_id:company.id,
                      name:personName,
                      location:personLocation,
                      linkedin:personLinkedin,
                      facebook:personFacebook,
                      twitter:personTwitter,
                      position:personPosition,
                      website_link:personWebsite,
                      link:personLink,
                      priority:5
                  });
                  await personDetails.save();
                  console.log("new people details")
               }  
                  
              console.log(personDetails.dataValues);
              

              addedPeopleCount++;

              let worksin=await WorksIn.findOne({where:{company_id:company.id,people_id:person.id}});
              if(worksin==null)
              {
                const newWorksIn=await new WorksIn({
                  company_id:company.id,
                  people_id:person.id,
                  designation:person.position
                });
                await newWorksIn.save();
                //console.log(newWorksIn);
              }
          }
      } 
      
    
    return res.status(200).json({company_status:companyMessage,peopleStatus:`${addedPeopleCount} out of ${totalPeopleCount} people details added`});
  }catch(error)
  {
    console.log(error);
    return res.status(500).json({message:error.message});
  }
 
}
exports.saveExternalWebsiteDetails=async(req,res)=>{
  try{
    let websiteDetails=req.body,
    company_details_id=websiteDetails.id,
    contact_us="",
    industry="",
    linkedin="",
    facebook="",
    twitter="",
    instagram="",
    rank="",
    web_location="",
    domain="",
    phones=[],
    emails=[],
    websitePeople=[],
    crawl_status = websiteDetails.crawl_status;

    if(company_details_id===null)
      res.status(500).json({message : "Company details id missing"});

    if(crawl_status===null)
      res.status(500).json({message : "crawl status missing"});

    if(websiteDetails.contact_us)
       contact_us=websiteDetails.contact_us;
    
    if(websiteDetails.industry)
       industry=websiteDetails.industry;
    
    if(websiteDetails.linkedin)
       linkedin=websiteDetails.linkedin;
     
    if(websiteDetails.twitter)
       twitter=websiteDetails.twitter;
    
    if(websiteDetails.facebook)
       facebook=websiteDetails.facebook;
    
    if(websiteDetails.instagram)
       instagram=websiteDetails.instagram;
    
    if(websiteDetails.location)
       web_location=websiteDetails.location;
    
    if(websiteDetails.rank)
       rank=websiteDetails.rank;
    
    if(websiteDetails.phones)
       phones=websiteDetails.phones;
       
    if(websiteDetails.emails)
       emails=websiteDetails.emails;
    
    if(websiteDetails.people)
       websitePeople=websiteDetails.people;   

    if(websiteDetails.top_words)
       domain = websiteDetails.top_words

    for(let i=0;i<phones.length;i++)
    {
      // const companyPhone=await CompanyPhone({
      //   where:{company_id:company_details_id}
      // });
      console.log("___________>>>>>>>>>>>>>>>>>>")
      if(1===1) //companyPhone==null) // commented because it is getting unique from the python side
      {
        console.log(11)
        const newPhone=await Phones.create({
        phone_no:phones[i]

        })
        const newCompanyPhone=await CompanyPhone.create({
          company_id:company_details_id,
          phone_id:newPhone.id
        });
      }
    }
    for(let i=0;i<emails.length;i++)
    {
      // const companyEmail=await CompanyEmail({
      //   where:{company_id:company_details_id}
      // });
      if(1===1) // this situation is because of above line
      {
        const newEmail=await Emails.create({
        email_id:emails[i]
        })
        const newCompanyEmail=await CompanyEmail.create({
          company_id:company_details_id,
          email_id:newEmail.id
        });
      }
    }
    const companyDetails=await CompanyDetails.findOne({
      where:{id:company_details_id}
    });
    if(companyDetails!==null){
      if(contact_us &&contact_us.length!==0)
         companyDetails.contact_us=contact_us;
      if(industry && industry.length!==0)
         companyDetails.industry=industry;
      if(domain && domain.length !==0 && (companyDetails.domain == null || companyDetails.domain.length === 0))
         companyDetails.domain=domain;
      if(linkedin && linkedin.length!==0) 
         companyDetails.likedin=linkedin;
      
      if(twitter && twitter.length!==0)
         companyDetails.twitter=twitter;
      
      if(facebook && facebook.length!==0)
         companyDetails.facebook=facebook;
      
      if(instagram && instagram.length!==0)
         companyDetails.instagram=instagram;
      
      if(web_location && web_location.length!==0)
         companyDetails.web_location=web_location;
      
      if(rank && rank.length!==0)
         companyDetails.rank=rank;
      
      companyDetails.crawl_status = 1;
      
      await companyDetails.save();
    };
    for(let i=0;i<websitePeople.length;i++)
    {
      let personName="",
      personEmail="",
      personPosition="",
      person_cb_rank="",
      personLocation="",
      personLink="",
      personWebsite_link="",
      personNumber="",
      personAbout="",
      personConnects="",
      personEducation=[],
      personSkills=[],
      personExperience=[],
      personCertification=[],
      personTwitter="",
      personLinkedin="",
      personFacebook="",
      personGender="";

      if(websitePeople[i].name)
        personName=websitePeople[i].name;
       
      if(websitePeople[i].email)
        personEmail=websitePeople[i].email;
      
      if(websitePeople[i].position)
        personPosition=websitePeople[i].position;

      if(websitePeople[i].cb_rank)
        person_cb_rank=websitePeople[i].cb_rank;

      if(websitePeople[i].location)
        personLocation=websitePeople[i].location;
      
      if(websitePeople[i].website_link)
        personWebsite_link=websitePeople[i].website_link;
      
      if(websitePeople[i].link)
        personLink=websitePeople[i].link;
      
      if(websitePeople[i].number)
        personNumber=websitePeople[i].number;
      
      if(websitePeople[i].connects)
        personConnects=websitePeople[i].connects;
      
      if(websitePeople[i].about)
        personAbout=websitePeople[i].about;
      
      if(websitePeople[i].linkedin)
        personLinkedin=websitePeople[i].linkedin;
      
      if(websitePeople[i].facebook)
        personFacebook=websitePeople[i].facebook;

      if(websitePeople[i].twitter)
        personTwitter=websitePeople[i].twitter;

      if(websitePeople[i].skills)
        personSkills=websitePeople[i].skills;
      
      if(websitePeople[i].certification)
        personCertification=websitePeople[i].certification;
      
      if(websitePeople[i].experience)
        personExperience=websitePeople[i].experience;
      
      if(websitePeople[i].education)
       personEducation=websitePeople[i].education;
      
      if(websitePeople[i].gender)
        personGender=websitePeople[i].gender;
      
      let people=await People.findOne({
        where:{
          [Op.or]:[
            {url:personWebsite_link},
            {linkedin:personLinkedin}
          ]
        }
      });
      let people_details=await PeopleDetails.findOne({
        where:{
          [Op.or]:[
            {email:personEmail},
            {linkedin:personLinkedin},
            {twitter:personTwitter}
          ]
        }
      });
      if(people==null)
         {
          people=await new People({
            name:personName,
            linkedin_id:personLinkedin,
            url:personWebsite_link,
            priority:5
          });
          await people.save();
         }
      if(people_details==null)
      {
         people_details=await new PeopleDetails({
          name:personName,
          person_id:people.id,
          email:personEmail,
          cb_rank:person_cb_rank,
          position:personPosition,
          location:personLocation,
          link:personLink,
          website_link:personWebsite_link,
          number:personNumber,
          connects:personConnects,
          about:personAbout,
          skills:personSkills,
          certification:personCertification,
          education:personEducation,
          twitter:personTwitter,
          linkedin:personLinkedin,
          facebook:personFacebook,
          gender:personGender,
          priority:5
         });
         await people_details.save();
      }
      let worksin=await WorksIn.findOne({where:{company_id:company_details_id,people_id:people.id}});
              if(worksin==null)
              {
                const newWorksIn=await new WorksIn({
                  company_id:company_details_id,
                  people_id:people.id,
                  designation:people_details.position
                });
                await newWorksIn.save();
              }
      
    }
    return res.status(200).json({message:'website details added'});
  }catch(error)
  {
    console.log(error);
    return res.status(500).json({message:error.message});
  }
}

exports.saveExternalGSWebsites=async(req,res)=>{
  try{
    const websiteDetails=req.body;
    let gsWebsite="",
    gsGroup=null,
    gsLocation=null,
    gsTitle=null,
    crawl_status = 0,
    contact_us_link=null,
    industry=null,
    linkedin=null,
    facebook=null,
    twitter=null,
    instagram=null,
    rank=null,
    websitePeople=[],
    emails = [],
    phones = [];

    if(websiteDetails.website)
       gsWebsite=websiteDetails.website;

    if(websiteDetails.group)
       gsGroup=websiteDetails.group;
    
    if(websiteDetails.location)
       gsLocation=websiteDetails.location;

    if(websiteDetails.title)
       gsTitle=websiteDetails.title;

    if(websiteDetails.industry)
       industry=websiteDetails.industry;

    if(websiteDetails.linkedin)
       linkedin=websiteDetails.linkedin;

    if(websiteDetails.facebook)
       facebook=websiteDetails.facebook;

    if(websiteDetails.twitter)
       twitter=websiteDetails.twitter;

    if(websiteDetails.instagram)
       instagram=websiteDetails.instagram;

    if(websiteDetails.rank)
       rank=websiteDetails.rank;
    
    if(websiteDetails.people)
       websitePeople=websiteDetails.people;
    
    if(websiteDetails.emails)
       emails=websiteDetails.emails;
    
    if(websiteDetails.phones)
       phones=websiteDetails.phones;
    
    let gs_website=null;

    if(websiteDetails.crawl_status) {
      crawl_status = websiteDetails.crawl_status
    } else {
      return res.status(500).json({message:'website id is missing'});
    }

    if(websiteDetails.contact_us_link) {
      contact_us_link = websiteDetails.contact_us_link
    }
    
    gs_website=await GsWebsite.findOne({
      where:{id:websiteDetails.id}
    });
    if(gs_website==null)
     return res.status(500).json({message:'website id is missing'});
    
    let site_url = gs_website.website

    // gs_website.website=gsWebsite;
    gs_website.group=gsGroup;
    gs_website.web_location=gsLocation;
    gs_website.title=gsTitle;
    gs_website.crawl_status=crawl_status;
    gs_website.contact_us_link=contact_us_link;
    gs_website.industry = industry;
    gs_website.linkedin = linkedin;
    gs_website.facebook = facebook;
    gs_website.twitter = twitter;
    gs_website.instagram = instagram;
    gs_website.rank = rank;

    await gs_website.save();

    for (let j=0; j<emails.length; j++) {
      var gs_email=await GsContact.findAll({
        where:{email:emails[j]}
      });
      if (gs_email.length == 0) {
        var gs_contact_ins = await GsContact.create({
          url: site_url,
          email: emails[j]
        })
      }
    }

    for (let k=0; k<phones.length; k++) {
      var gs_phone=await GsContact.findAll({
        where:{phone:phones[k]}
      });
      if (gs_phone.length == 0) {
        var gs_contact_ins = await GsContact.create({
          url: site_url,
          phone: phones[k]
        })
      }
    }
    
    for(let i=0;i<websitePeople.length;i++)
    {
      let personName=null,
      personEmail=null,
      personPosition=null,
      person_cb_rank=null,
      personLocation=null,
      personLink=null,
      personWebsite_link=null,
      personNumber=null,
      personAbout=null,
      personConnects=null,
      personEducation=[],
      personSkills=[],
      personExperience=[],
      personCertification=[],
      personTwitter=null,
      personInstagram=null,
      personLinkedin=null,
      personFacebook=null,
      personGender=null,
      personPhone=null;

      if(websitePeople[i].name)
        personName=websitePeople[i].name;
       
      if(websitePeople[i].email)
        personEmail=websitePeople[i].email;
      
      if(websitePeople[i].position)
        personPosition=websitePeople[i].position;

      if(websitePeople[i].cb_rank)
        person_cb_rank=websitePeople[i].cb_rank;

      if(websitePeople[i].location)
        personLocation=websitePeople[i].location;
      
      if(websitePeople[i].website_link)
        personWebsite_link=websitePeople[i].website_link;
      
      if(websitePeople[i].link)
        personLink=websitePeople[i].link;
      
      if(websitePeople[i].number)
        personNumber=websitePeople[i].number;
      
      if(websitePeople[i].connects)
        personConnects=websitePeople[i].connects;
      
      if(websitePeople[i].about)
        personAbout=websitePeople[i].about;
      
      if(websitePeople[i].linkedin)
        personLinkedin=websitePeople[i].linkedin;
      
      if(websitePeople[i].facebook)
        personFacebook=websitePeople[i].facebook;

      if(websitePeople[i].twitter)
        personTwitter=websitePeople[i].twitter;

      if(websitePeople[i].instagram)
        personInstagram=websitePeople[i].instagram;

      if(websitePeople[i].skills)
        personSkills=websitePeople[i].skills;
      
      if(websitePeople[i].certification)
        personCertification=websitePeople[i].certification;
      
      if(websitePeople[i].experience)
        personExperience=websitePeople[i].experience;
      
      if(websitePeople[i].education)
       personEducation=websitePeople[i].education;
      
      if(websitePeople[i].gender)
        personGender=websitePeople[i].gender;
      
      if(websitePeople[i].phone)
        personPhone=websitePeople[i].phone;

      if (!personEmail && !personLinkedin && !personInstagram) { continue; }

      let people=await People.findOne({
        where:{
          [Op.or]:[
            {url:personWebsite_link},
            {linkedin:personLinkedin}
          ]
        }
      });
      let people_details=await PeopleDetails.findOne({
        where:{
          [Op.or]:[
            {email:personEmail},
            {linkedin:personLinkedin},
            {twitter:personTwitter}
          ]
        }
      });
      if(people==null)
         {
          people=await new People({
            name:personName,
            linkedin_id:personLinkedin,
            url:personWebsite_link,
            priority:5
          });
          await people.save();
         }
      if(people_details==null)
      {
         people_details=await new PeopleDetails({
          name:personName,
          person_id:people.id,
          email:personEmail,
          cb_rank:person_cb_rank,
          position:personPosition,
          location:personLocation,
          link:personLink,
          website_link:personWebsite_link,
          number:personNumber,
          connects:personConnects,
          about:personAbout,
          skills:personSkills,
          certification:personCertification,
          education:personEducation,
          twitter:personTwitter,
          linkedin:personLinkedin,
          facebook:personFacebook,
          gender:personGender,
          priority:5
         });
         await people_details.save();
      }
     let ml_website=await MlPeople.findOne({
      where:{
        linkedin_id:people.id
      }
     });
     if(ml_website==null)
     {
      ml_website=await new MlPeople({
        name:personName,
        email:personEmail,
        position:personPosition,
        phone:personPhone,
        linkedin:people.id
      })
     }
    }
    return res.status(200).json({message:"details added"})
  }catch(error)
  {
    console.log(error);
    return res.status(500).json({message:error.message});
  }
}


exports.saveExternalPeopleDetails=async(req,res)=>{
  try{
    let 
    employees=req.body,
    totalPeopleCount=employees.length;

    var addedPeopleCount=0;

    for(let i=0;i<employees.length;i++)
    {
        let person=null,personDetails=null;
        let personName="",personLocation="",personLinkedin="",personFacebook="",personTwitter="",personPosition="",personLink="",personWebsite="", origin=null;
        
        if(employees[i].linkedin&&employees[i].linkedin.length!=0)
          personLinkedin=employees[i].linkedin;
        
        if(employees[i].origin&&employees[i].origin.length!=0)
          origin=employees[i].origin;

        if (!origin) {
          return res.json("must have origin")
        }
        
        if(employees[i].location&&employees[i].location.length!=0)
          personLocation=employees[i].location;

        // if(personLocation.length===0)
        //  personLocation=location;

        if(employees[i].name && employees[i].name.length!=0)
          personName=employees[i].name;
        
        if(employees[i].facebook && employees[i].facebook.length!=0)
          personFacebook=employees[i].facebook;
        
        if(employees[i].twitter && employees[i].twitter.length!=0)
          personTwitter=employees[i].twitter;
        
        if(employees[i].position && employees[i].position.length!=0)
          personPosition=employees[i].position;
        
        if(employees[i].link && employees[i].link.length!=0)
          personLink=employees[i].link;
        
        if(employees[i].website && employees[i].website.length!=0)
          personWebsite=employees[i].website;
        
        // if(personLinkedin==null)
        //  continue;
        
        person=await People.findOne({
            where:{url:personLink }
        })
        personDetails=await PeopleDetails.findOne({
          where:{linkedin:personLinkedin}
        })
        if (personWebsite !== "" && personWebsite !== null) {
          personDetailsWebsite=await PeopleDetails.findAll({
            where:{website_link:personWebsite}
          })
          if (personDetailsWebsite.length > 0) continue;
        }

        if (personLink !== "" && personLink !== null) {
           var personDetailsLink=await PeopleDetails.findAll({
            where:{link:personLink}
          })
          if (personDetailsLink.length > 0) continue;
        }


        console.log(1)
        if(person==null)
          {
            person=await new People({
                name:personName,
                url:personLink,
                linkedin_id:personLinkedin,
                origin
            });
            await person.save();
            console.log("new person")
            addedPeopleCount++;
            personDetails=await new PeopleDetails({
              people_id:person.id,
              name:personName,
              location:personLocation,
              linkedin:personLinkedin,
              facebook:personFacebook,
              twitter:personTwitter,
              position:personPosition,
              website_link:personWebsite,
              link:personLink,
              priority:5
            });
            await personDetails.save();
            console.log("new people details")
          } 
        console.log(personDetails.dataValues);
    }
      
    
    return res.status(200).json({peopleStatus:`${addedPeopleCount} out of ${totalPeopleCount} people details added`});
  }catch(error)
  {
    console.log(error);
    return res.status(500).json({message:error.message});
  }
}

exports.save_google_maps_companies = async (req, res) => {
  let companies_data = req.body;
  for (let i=0; i<companies_data.length; i++) {
    let com_ins = await Company.findOne({where:{name:companies_data[i]['name']}})
    let is_new = false
    if (!com_ins) {
      com_ins = await Company.create({
        name:companies_data[i]['name'],
        origin:"google_maps"
      })
      is_new = true
    }
    console.log(is_new)
    let comp_details = null
    if (!is_new) {
      comp_details = await CompanyDetails.findOne({where:{company_id:com_ins.id}})
    }
    if (!comp_details) {
      comp_details = await CompanyDetails.create({company_id:com_ins.id})
    }

    console.log(comp_details)
    comp_details.gmap_address = companies_data[i]['gmap_address']
    comp_details.gmap_status = companies_data[i]['gmap_status']
    comp_details.gmap_rating = companies_data[i]['gmap_rating']
    comp_details.gmap_num_rating = companies_data[i]['gmap_num_ratings']

    await comp_details.save()
    
  }
  res.json({status:"success"})

}
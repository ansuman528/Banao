const userModel = require("../models/user");
const scraping_website = require("../models/scraping_website");
const crawlingLinks = require("../models/crawling_links");
const scrape_web_log = require("../models/scrape_web_log");
const countryCodes = require("../models/country_codes");
const { sequelize, Op, literal, where } = require("sequelize");
const moment = require("moment");
crawlingLinks.belongsTo(scraping_website, {
  foreignKey: "website",
  targetKey: "url",
});
scrape_web_log.belongsTo(scraping_website, {
  foreignKey: "website",
  targetKey: "url",
});

exports.displayPeopleStat = async (req, res) => {
  let fetch_status = req.body.fetch_status;
  console.log("from back", fetch_status);
  const countryList = await countryCodes.findAll();
  //await setCountryCodes();
  let data = [];
  for (let i = 0; i < countryList.length; i++) {
    data.push({
      country: countryList[i].country,
      country_code: countryList[i].country_code,
      uim_count: countryList[i][`uim_count_${fetch_status}`],
      updatedAt: `${countryList[i].updatedAt.toDateString()} ${countryList[
        i
      ].updatedAt.toLocaleTimeString()}`,
    });
  }
  console.log(data)
  res.status(200).json({
    data,
  });
};
function getUserLogin(reqToken) {
  if (reqToken != null) {
    const User = userModel.findOne({
      raw: true,
      where: { token: reqToken },
      attributes: ["name", "token", "status"],
    });
    console.log(User)
    return User;
  } else {
    return res.status(500).send({ message: "Please Enter Token" });
  }
}
exports.reactLogin = async (req, res) => {
  try {
    console.log(req.body.token);
    var user = await getUserLogin(req.body.token);
    if (user != null && user != false) {
      console.log(user)
      res.cookie("token", user.token, { maxAge: 900000 });
      res.status(200).json({ message: true });
    } else {
      res.status(200).json({ message: false });
    }
  } catch (err) {
    res.status(500).send(err);
  }
};
exports.scraping_website = async (req, res) => {
  try {
    console.log(req.body);
    const data = req.body;
    // Check if the scraping website already exists
    const existingScrapingWebsite = await scraping_website.findOne({
      where: { url: data.url },
    });

    if (existingScrapingWebsite) {
      // Update the fields with the new data
      let flag = false;
      console.log(existingScrapingWebsite.dataValues.name);
      console.log(data.name);
      if (existingScrapingWebsite.dataValues.name != data.name) {
        existingScrapingWebsite.name = data.name;
        flag = true;
      }
      if (existingScrapingWebsite.dataValues.priority != data.priority) {
        existingScrapingWebsite.priority = data.priority;
        flag = true;
      }
      if (
        existingScrapingWebsite.dataValues.scrapping_frquency !=
        data.scrapping_frquency
      ) {
        existingScrapingWebsite.scrapping_frquency = data.scrapping_frquency;
        flag = true;
      }
      if (
        existingScrapingWebsite.dataValues.starting_url != data.starting_url
      ) {
        existingScrapingWebsite.starting_url = data.starting_url;
        flag = true;
      }
      if (existingScrapingWebsite.dataValues.url_element != data.url_element) {
        existingScrapingWebsite.url_element = data.url_element;
        flag = true;
      }
      if (existingScrapingWebsite.dataValues.py_script != data.py_script) {
        existingScrapingWebsite.py_script = data.py_script;
        flag = true;
      }
      if (
        existingScrapingWebsite.dataValues.pagination_element !=
        data.pagination_element
      ) {
        existingScrapingWebsite.pagination_element = data.pagination_element;
        flag = true;
      }
      existingScrapingWebsite.data = data.data;
      await existingScrapingWebsite.save(); // Save the changes
      console.log(flag);
      if (flag == true) {
        await scrape_web_log.create({
          website: data.url,
          log: "website updated",
        });
      }
      res.send(existingScrapingWebsite);
    } else {
      // Create a new scraping website
      const newScrapingWebsite = await scraping_website.create({
        url: data.url,
        name: data.name,
        priority: data.priority,
        scrapping_frquency: data.scrapping_frquency,
        starting_url: data.starting_url,
        url_element: data.url_element,
        py_script: data.py_script,
        pagination_element: data.pagination_element,
        data: data.data,
      });
      await scrape_web_log.create({
        website: data.url,
        log: "website added for scrapping",
      });
      res.send(newScrapingWebsite);
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
};
exports.editWebsiteDetails = async (req, res) => {
  try {
    console.log(req.body.url);
    let entry = await scraping_website.findOne({
      where: { url: req.body.url },
    });
    if (entry) {
      entry.name = req.body.name;
      entry.priority = req.body.priority;
      entry.scrapping_frquency = req.body.scrapping_frquency;
      entry.starting_url = req.body.starting_url;
      entry.url_element = req.body.url_element;
      entry.py_script = req.body.py_script;
      entry.pagination_element = req.body.pagination_element;

      await entry.save(); // Save the changes
      await scrape_web_log.create({
        website: data.url,
        log: "website updated",
      });
      res.status(200).send(entry);
    } else {
      res.status(200).send({ message: "Entry not exist" });
    }
  } catch (error) {
    console.log(error);
    res.status(500).send(error);
  }
};
exports.getCrawlingLinks = async (req, res) => {
  const { token } = req.body;
  try {
    console.log(token);
    const user = await userModel.findOne({
      where: { token },
      attributes: ["name"],
    });

    if (!user) {
      return res.status(404).json({ message: "User does not exist" });
    }

    const websiteUrls = await scraping_website.findAll({ attributes: ["url"] });
    const data = [];

    for (const { url } of websiteUrls) {
      const totals = await crawlingLinks.findOne({
        where: {
          website: url,
          [Op.or]: [
            {
              is_status: 0,
              created_At: {
                [Op.gte]: moment().startOf("day").toDate(),
                [Op.lte]: moment().endOf("day").toDate(),
              },
            },
            {
              is_status: [1, 2],
              updated_At: {
                [Op.gte]: moment().startOf("day").toDate(),
                [Op.lte]: moment().endOf("day").toDate(),
              },
            },
            { is_status: 2 },
            { is_status: 0 },
          ],
        },
        attributes: [
          [
            literal("COUNT(CASE WHEN is_status = 0 THEN url_links END)"),
            "totalScraped",
          ],
          [
            literal("COUNT(CASE WHEN is_status = 2 THEN url_links END)"),
            "totalCrawled",
          ],
          [
            literal(
              "COUNT(CASE WHEN is_status IN (1, 2) AND updated_At >= CURDATE() THEN url_links END)"
            ),
            "crawledToday",
          ],
          [
            literal(
              "COUNT(CASE WHEN is_status = 0 AND created_At >= CURDATE() THEN url_links END)"
            ),
            "scrapedToday",
          ],
        ],
      });

      const websiteData = {
        website: url,
        totalScraped: totals.dataValues.totalScraped,
        totalCrawled: totals.dataValues.totalCrawled,
        scrapedToday: totals.dataValues.scrapedToday,
        crawledToday: totals.dataValues.crawledToday,
      };

      data.push(websiteData);
    }

    console.log(data);
    res.json(data);
  } catch (error) {
    console.error("Error in getCrawlingLinks:", error);
    res.status(500).json({ message: "An error occurred" });
  }
};
exports.getLogData = async (req, res) => {
  let website = req.body.website;
  let token = req.body.token;
  try {
    console.log(token);
    console.log(website);
    let User = await userModel.findOne({
      where: { token },
      attributes: ["name"],
    });
    if (!User) {
      return res.status(404).json({ message: "User does not exist" });
    }
    let data = await scrape_web_log.findAll({ where: { website: website } });
    res.send(data);
  } catch (error) {
    console.log(error);
  }
};
exports.getWebsiteData = async (req, res) => {
  try {
    const { token } = req.body;
    
    const user = await userModel.findOne({
      where: {
        token
      },
      attributes: ['name']
    });

    if (!user) {
      return res.status(404).json({ message: "User does not exist" });
    }

    const data = await scraping_website.findOne({
      where: {
        status: 0
      }
    });

    if (!data) {
      return res.status(404).json({ message: "No data found with status = 0" });
    }
    console.log(data.dataValues.id)
    let id = data.dataValues.id;
    await scraping_website.update(
      { status: 1 },
      { where: { id: id } }
    );
    await scrape_web_log.create({
      website: data.dataValues.url,
      log: "website data fetched",
    });


    res.send(data);
  } catch (error) {
    console.log(error);
    res.send(error);
  }
}
exports.addCrawlingLinks = async (req, res) => {
  try {
    console.log(req.body);
    const links = req.body.links;
    const results = [];

    for (const link of links) {
      const is_exist = await crawlingLinks.findOne({
        where: { website: req.body.website, url_links: link.url },
      });

      if (is_exist) {
        results.push({ link: link.url, message: "Link already exists" });
      } else {
        const data = await crawlingLinks.create({
          website: req.body.website,
          url_links: link.url,
          is_status: link.status,
          data: link.data,
        });

        

        results.push({ link: link.url, data });
      }
    }
    await scrape_web_log.create({
          website: req.body.website,
          log: "links added for crawling",
    });
    res.send(results);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server Error" });
  }
};

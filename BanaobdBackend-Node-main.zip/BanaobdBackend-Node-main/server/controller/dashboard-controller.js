const config = require("../models/config");
const company = require("../models/company");
const companyDetails = require("../models/company_details");
const People = require("../models/people");
const peopleDetails = require("../models/people_details");
const userModel = require("../models/user");
const worksIn = require("../models/worksIn");
const searchPeople = require("../models/search_people");
const emailsTable = require("../models/emails");
const companyEmails = require("../models/company_email");
const peopleEmails = require("../models/people_email");
const websiteTable = require("../models/website");
const companyWebsite = require("../models/companyWebsite");
const peopleWebsite = require("../models/peopleWebsite");
const emailvalidator = require("email-validator");
const searchComp = require("../models/search_company");
const jobs = require("../models/jobs_details");
const sequelize = require("sequelize");
const locationDetails = require("../models/location_details");
const people = require("../models/people");
const excel = require('exceljs');
const path = require('path');
const fs = require('fs');
const fs_extra = require("fs-extra");
const user1 = require("../models/user1");
const Op = sequelize.Op
const googlePeople = require("../models/google_peoples");
const googleSearchItems = require("../models/google_search_items");
const gsWebsite = require("../models/gs_website");
const gsContact = require("../models/gs_contact");
const mlPeople = require("../models/ml_people")
const countryCodes=require("../models/country_codes");
const { query } = require("express");
const { stringify } = require("csv-stringify");
const seq = require("../database/connection");
var appRoot = require('app-root-path');
const user = require("../models/user");
const { once } = require('events');
const createCsvWriter = require('csv-writer').createArrayCsvWriter;
const countryCodesList=require("./../../output.json");
// setting Association
company.hasMany(worksIn, { foreignKey: 'company_id' });
worksIn.belongsTo(company, { foreignKey: "company_id" });
people.hasMany(worksIn, { foreignKey: 'people_id' });
worksIn.belongsTo(people, { foreignKey: "people_id" });
people.hasMany(peopleDetails, { foreignKey: 'people_id' });
peopleDetails.belongsTo(people, { foreignKey: "people_id" })


people.hasMany(googlePeople, { foreignKey: 'people_id' })
googlePeople.belongsTo(people, { foreignKey: "people_id" })
googleSearchItems.hasMany(googlePeople, { foreignKey: "google_search_id" });
googlePeople.belongsTo(googleSearchItems, { foreignKey: "google_search_id" })

gsWebsite.hasMany(mlPeople, { foreignKey : 'gs_website_id'})
mlPeople.belongsTo(gsWebsite, { foreignKey : 'gs_website_id'})

people.hasMany(peopleWebsite, {foreignKey : 'people_id'})
peopleWebsite.belongsTo(people, {foreignKey : 'people_id'})

//get website domain from url
function getDomain(url) {
    url = url.toLowerCase()
    var site_sp = url.split('://');
    var siteWithoutProto ;
    var siteWithoutW ;
    if (site_sp.length > 1) {
        siteWithoutProto = site_sp[1];
    } else {
        siteWithoutProto = site_sp[0];
    }

    var domain = siteWithoutProto.split("/")[0];
    var siteWithoutWList = domain.split("www.");

    if (siteWithoutWList.length > 1) {
        siteWithoutW = siteWithoutWList[1];
    } else {
        siteWithoutW = siteWithoutWList[0];
    }

    return siteWithoutW
}

function getUser(req) {
    const reqToken = req.cookies.token
    if (reqToken == null ) {
        const User = userModel.findOne({ raw: true, where: { token: reqToken } });
        return User
    } else {
        return false
    }

}

function getUserLogin(reqToken) {
    if (reqToken != null ) {
        const User = userModel.findOne({ raw: true, where: { token: reqToken } });
        return User
    } else {
        return false
    }

}

exports.postLogin = async (req, res) => {
    console.log(req.body.token)
    var user = await getUserLogin(req.body.token)
    if (user != null && user != false) {
        res.cookie('token',user.token, { maxAge: 900000 });
        res.render("home", {"token":user.token})
    } else {
        res.status(500).render("login", {layout:false})
    }
}
exports.logout=async (req,res)=>{
    res.clearCookie("token");
    res.redirect("/")
}

exports.getStat = async (req, res) => {
    var [results, metadata] = await seq.query("SELECT COUNT(company_details.id) FROM company_details INNER JOIN companies ON (company_details.company_id = companies.id) WHERE companies.source = \"Linkedin\" AND company_details.updatedAt >= DATE_SUB(CURRENT_DATE(), INTERVAL 0 DAY);");
    var today_company_count_linkedin = results[0]["COUNT(company_details.id)"]
    var [results1, metadata] = await seq.query("SELECT COUNT(people_details.id) FROM people INNER JOIN people_details ON (people_details.people_id = people.id) WHERE people.source = \"Linkedin\" AND people.status = \"scraped\" AND people.updatedAt >= DATE_SUB(CURRENT_DATE(), INTERVAL 0 DAY);");
    var today_people_count_linkedin = results1[0]["COUNT(people_details.id)"]
    var [results2, metadata] = await seq.query("SELECT COUNT(company_details.id) FROM company_details INNER JOIN companies ON (company_details.company_id = companies.id) WHERE companies.source = \"crunchbase\" AND company_details.updatedAt >= CURRENT_DATE() AND company_details.createdAt <= DATE_ADD(CURRENT_DATE, INTERVAL 1 DAY);");
    var today_company_count_crunchbase = results2[0]["COUNT(company_details.id)"]
    var data = {
        "today_company_count_linkedin":today_company_count_linkedin,
        "today_people_count_linkedin":today_people_count_linkedin,
        "today_company_count_crunchbase":today_company_count_crunchbase,
    }
    res.json(data)
}

exports.getWebsiteData = async (req, res) => {
    let website_name = req.body.website
    console.log(website_name)
    if (website_name) {
        let domain = getDomain(website_name)
        let [results, metadata] = await seq.query("SELECT * FROM gs_websites WHERE website LIKE \"%" + domain +"%\"")
        if (results.length > 0 ) {
            res.json(results)
            return 0
        } else {
            let website = await gsWebsite.create({website:website_name, priority:1000})
            res.status(201).json("website is queued for crawling on priority")
            return 0
        }
    }
    res.json("website not provided")
}

async function setCountryCodes(){
  
    for(let i=0;i<countryCodesList.country_codes.length;i++)
    {
        const country=await countryCodes.findOne({where:{country_code:countryCodesList.country_codes[i]}});
        if(!country)
        {
            await fetch(`https://restcountries.com/v3.1/alpha?codes=${countryCodesList.country_codes[i]}`)
        .then(res=>res.json())
        .then(async (data)=>
            {
                if(data[0]?.name)
                {
                    const newCountry=await countryCodes.create({
                        country:data[0].name.common,
                        country_code:countryCodesList.country_codes[i],
                        uim_count_0:0,
                        uim_count_1:0,
                        uim_count_2:0
                       });
                       console.log(data[0].name.common)
                       await newCountry.save();
                }else{
                    const newCountry=await countryCodes.create({
                        country:countryCodesList.country_codes[i],
                        country_code:countryCodesList.country_codes[i],
                        uim_count_0:0,
                        uim_count_1:0,
                        uim_count_2:0,
                       });
                       //console.log(data[0].name.common)
                       await newCountry.save();
                }
            })
        }
    }
}

exports.displayPeopleStat=async (req,res)=>{
    let fetch_status=req.query.fetch_status;
    if(!fetch_status)
     fetch_status="0";
    const countryList=await countryCodes.findAll();
   //await setCountryCodes();
  let data=[];
  for(let i=0;i<countryList.length;i++)
  {
    data.push({country:countryList[i].country,country_code:countryList[i].country_code,uim_count:countryList[i][`uim_count_${fetch_status}`],updatedAt:`${countryList[i].updatedAt.toDateString()} ${countryList[i].updatedAt.toLocaleTimeString()}`});
      
}
  res.render("people_table",{token:req.cookies.token,fetch_status,data});
}
const config = require("../models/config");
const countryCodes=require("../models/country_codes");
const { query } = require("express");
const { stringify } = require("csv-stringify");
const seq = require("../database/connection");
exports.runPeople=async ()=>{
    const countryList=await countryCodes.findAll();
  // await setCountryCodes();
  for(let i=0;i<countryList.length;i++)
  {
    let [results_0, metadata_0]=await seq.query(`SELECT COUNT(*) FROM people INNER JOIN people_details ON (people_details.people_id = people.id) WHERE people.source="crunchbase" AND origin IS NULL AND people_details.linkedin IS NOT NULL AND people_details.linkedin != "" AND people.fetch_status=0 AND LOWER(people_details.location) LIKE "%${countryList[i].country_code}%"`);
    let [results_1, metadata_1]=await seq.query(`SELECT COUNT(*) FROM people INNER JOIN people_details ON (people_details.people_id = people.id) WHERE people.source="crunchbase" AND origin IS NULL AND people_details.linkedin IS NOT NULL AND people_details.linkedin != "" AND people.fetch_status=1 AND LOWER(people_details.location) LIKE "%${countryList[i].country_code}%"`);
    let [results_2, metadata_2]=await seq.query(`SELECT COUNT(*) FROM people INNER JOIN people_details ON (people_details.people_id = people.id) WHERE people.source="crunchbase" AND origin IS NULL AND people_details.linkedin IS NOT NULL AND people_details.linkedin != "" AND people.fetch_status=2 AND LOWER(people_details.location) LIKE "%${countryList[i].country_code}%"`);
    //console.log(results_0)
    await countryList[i].changed('updatedAt', true);
    await countryList[i].update({uim_count_0:results_0[0]['COUNT(*)'],uim_count_1:results_1[0]['COUNT(*)'],uim_count_2:results_2[0]['COUNT(*)'],updatedAt: new Date()})
    
    await countryList[i].save();
    
}

}
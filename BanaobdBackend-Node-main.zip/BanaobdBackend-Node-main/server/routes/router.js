const express = require("express");
const route = express.Router();
const controller = require("../controller/controller");
const externalController=require("../controller/external-controller");
const reactDashboard = require("../controller/react-dashboard");
const dashController = require("../controller/dashboard-controller");
const auth = require("../middlewares/auth");
const dashAuth = require("../middlewares/dash-auth");
const { Router } = require("express");


route.post("/api/saveExternalCompanyDetails",externalController.saveExternalCompanyDetails);
route.post("/api/saveExternalPeopleDetails",externalController.saveExternalPeopleDetails);
route.post("/api/saveCompanyWebsiteDetails",externalController.saveExternalWebsiteDetails);
route.post("/api/saveExternalGSWebsiteDetails",externalController.saveExternalGSWebsites);
route.post("/api/save-gmap-companies",externalController.save_google_maps_companies);
route.get("/", (req, res) => {
  try {
    res.render("home", {"token":req.cookies.token});
  } catch (err) {
    res.render("home", {"token":false});
  }
});

route.get("/login", (req, res) => {
  res.render("login", {layout:false})
});
route.post("/api/postPeopleSearch", controller.postPeopleSearch)
route.get("/api/getCompaniesToSearch",controller.getCompaniesToSearch)
/**
 * @description getUserStats Route
 * @method GET/
*/
route.get("/api/getUserStats",controller.getUserStats);
route.get("/api/ask-unknown-people",controller.getUnknownPeople);
route.post("/api/save-unknown-people",controller.saveUnknownPeople);
route.post("/api/postDashboard",controller.postDashboard);

route.post("/api/getMessages",controller.getMessages);

route.get("/data", dashController.getStat)

route.post("/login", dashController.postLogin);
route.get("/logout",dashController.logout);
route.post("/get-website-detail", dashController.getWebsiteData)

route.get("/api/getCompanyInstagram",controller.getCompanyInstagram)

route.post("/api/postInstagramDetails",controller.postInstagramDetails)

route.get("/displayPeopleStat",dashController.displayPeopleStat)
route.post("/displayPeopleStat",dashController.displayPeopleStat)
// route.get("/getPeopleStat",dashController.getPeopleStat);

route.get("/api/set-priority", controller.setPriority);
route.post("/api/getUserScoreList", controller.getUserScoreList);
route.post("/api/getSpecificUserScore", controller.getSpecificUserData);
route.post("/api/getUserScore", controller.getUserScore);
route.post("/api/authenticate-user",controller.authenticateUser)
/**exports.peopleSearch = async (req, res) => {
 * @description company-config Route
 * @method GET/
*/

route.get("/api/ask-company-config", auth, controller.configCompany);

/**
 * @description save-userStats Route
 * @method POST/
 */
route.post("/api/save-userStats",auth, controller.userStats)
route.post("/api/save-userStats2",auth, controller.userStats2)
/**
 * @description company Route
 * @method POST/
 */
route.post("/api/save-company", auth, controller.saveCompany);
/**
 * @description company_details Route
 * @method POST/
 */
route.post("/api/save-CompanyDetails", auth, controller.companyDetails);

/**
 * @description people-config Route
 * @method GET/
 */
route.get("/api/ask-people-config", auth, controller.configPeople);
/**
 * @description people Route
 * @method POST/
 */
route.post("/api/save-people", auth, controller.savePeople);
/**
 * @description people_details Route
 * @method POST/
 */
route.post("/api/save-peopleDetails", auth, controller.peopleDetails);

route.post("/api/save-studentDetails", controller.studentDetails);
/**
 * @description crunch-config Route
 * @method GET/
 */
route.get("/api/ask-crunch-config", controller.configCrunchCompany);


/**
* @description crunch-config Route for people extension
* @method GET/
*/

route.get("/api/ask-crunch-people-config", controller.configCrunchPeople);

/**
* @description search-config Route
* @method GET/
*/
route.get("/api/config-searchPeople", auth, controller.configSearchPeople);

/**
 * @description jobs saving Route
 * @method POST/
 */
route.post("/api/save-jobs", controller.saveJobs);

/**
 * @description peopleSearch for specific designation CEO Route
 * @method POST/
 */
route.get("/api/search-people", controller.peopleSearch);

route.post("/api/googleSearchPeopleApi", controller.googleSearchPeopleApi);

route.get("/api/getGooglePeople", controller.googlePeopleApi);

route.post("/api/new-api", controller.saveContact);

route.post("/api/companyWebsite",controller.companyWebsites);

route.post("/api/website", controller.saveWebsite);

route.get("/api/website-data", controller.mlWebsite);

route.get("/api/comapany-website", controller.CompanyWebsite);

route.post("/api/website-data/:id", controller.mlWebsiteUpdate);

route.get("/api/contact-page-links", controller.getContactPage);

route.get("/api/update-contact-page-status", controller.saveContactUsStatus);

route.post("/api/save-ml-people", controller.saveMlPeople);

route.get("/api/get-people-email", controller.getDataWithEmail);

route.get("/api/get-website-data", controller.getWebsiteData);

route.get("/api/get-company-data", controller.getCompanyData);

route.get("/api/get-website-email", controller.getWebsiteEmail);

route.get("/api/get-contacts", controller.getContacts);

route.get("/api/create-token", controller.createToken);

route.post("/api/post-ystory-url", controller.saveYourStoryLink);

route.get("/api/get-ystory-url", controller.getYourStoryLink);

route.post("/api/post-ystory-data", controller.saveYsCompanyDetails);

route.post("/api/start-time", controller.startTime);

route.post("/api/save-company-name", controller.saveCompanyName);
route.get("/api/ask-company-name", controller.getCompanyName);
route.post("/api/update-company-details",controller.editCompanyDetails)

route.get("/api/get-company-name-for-bing", controller.getCompanyNameForBing);
route.post("/api/save-locations", controller.saveLocations);

route.post("/api/add-user",controller.addUser);

route.post("/api/shorten-url", controller.shortenUrl);
route.get("/short/:shortUrl", controller.redirectUrl);
route.get("/api/check-short-url", controller.checkUrl);
route.get("/api/edit-url", controller.editUrl);
route.post("/api/remove-user-from-bbd-dashboard", controller.removeUserFromBbddashboard);
route.get('/api/company-without-location-headquarter',controller.companyWithoutLocationHeadquarter);
route.post('/api/save-location-by-company-detail-id', controller.saveHeadQuarterByCompanyDetailsId);
route.get("/api/unscraped-twitter-links", controller.getUnscrapedTwitterLinksCompanies);
route.post("/api/add-data-to-company-details", controller.addDataToCompanyDetails);

module.exports = route;

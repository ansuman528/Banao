const express = require("express");
const route = express.Router();
const controller = require("../controller/react-dashboard.js");

route.post("/plug&play/save-company-details",controller.scraping_website);
route.post('/plug&play/login',controller.reactLogin);
route.post('/plug&play/edit_website_details',controller.editWebsiteDetails);
route.post('/plug&play/add_crawling_links',controller.addCrawlingLinks);
route.post('/plug&play/display_dashboard',controller.getCrawlingLinks);
route.get('/plug&play/get_log_data',controller.getLogData);
route.get('/plug&play/get_website_data',controller.getWebsiteData);

module.exports = route;
'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("google_people", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      google_search_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'google_search_items', key: 'id' },
        onUpdate:'CASCADE',
        onDelete:'SET NULL',
      },
      people_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'people', key: 'id' },
        onUpdate:'CASCADE',
        onDelete:'SET NULL',
      }
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable('google_people');
  }
};

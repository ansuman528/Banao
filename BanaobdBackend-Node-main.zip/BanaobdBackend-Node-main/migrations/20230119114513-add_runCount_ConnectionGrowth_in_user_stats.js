'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'user_stats', 'runCount',
        {
          type:Sequelize.INTEGER(11)
        }
      ),
      queryInterface.addColumn(
        'user_stats', 'connectionGrowth',
        {
          type:Sequelize.INTEGER(11)
        }
      )
    ]);
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};

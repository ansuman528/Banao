"use strict";

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("people_details", "cb_rank", {
        type: Sequelize.STRING(20),
      }),
      queryInterface.addColumn("people_details", "twitter", {
        type: Sequelize.STRING(50),
      }),
      queryInterface.addColumn("people_details", "linkedin", {
        type: Sequelize.STRING(50),
      }),
      queryInterface.addColumn("people_details", "facebook", {
        type: Sequelize.STRING(50),
      }),
      queryInterface.addColumn("people_details", "gender", {
        after: "email",
        type: Sequelize.STRING(50),
      }),
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("people_details", "cb_rank"),
      queryInterface.removeColumn("people_details", "twitter"),
      queryInterface.removeColumn("people_details", "linkedin"),
      queryInterface.removeColumn("people_details", "facebook"),
      queryInterface.removeColumn("people_details", "gender"),
    ]);
  },
};

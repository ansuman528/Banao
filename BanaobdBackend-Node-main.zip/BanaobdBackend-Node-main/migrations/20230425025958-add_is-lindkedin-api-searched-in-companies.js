'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'companies', 'linkedin_api_location_searched',
        {
          type: Sequelize.INTEGER(5),
          defaultValue: 0
        }
      )
    ]);
  },

  async down (queryInterface, Sequelize) {
    queryInterface.removeColumn('compananies', 'linkedin_api_location_searched');
  }
};

'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn('companies', 'fetch_status', {
      type: Sequelize.INTEGER(11),
      defaultValue: 0

    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.removeColumn("companies", "fetch_status")
  }
};

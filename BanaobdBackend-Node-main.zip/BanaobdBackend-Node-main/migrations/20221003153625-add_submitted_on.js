'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn('gs_websites', 'contact_submitted_on', {
      type: Sequelize.DATE,
      allowNull: true

    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.removeColumn("gs_websites", "contact_submitted_on")
  }
};

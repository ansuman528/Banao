'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'company_details', 'instagram',
        {
          type: Sequelize.STRING(200)
        }
      ),
      queryInterface.addColumn(
        'company_details', 'contact_us',
        {
          type: Sequelize.STRING(200)
        }
      ),
      queryInterface.addColumn(
        'company_details', 'industry',
        {
          type: Sequelize.STRING(200)
        }
      ),
      queryInterface.addColumn(
        'company_details', 'web_location',
        {
          type: Sequelize.STRING(600)
        }
      ),
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('company_details', 'instagram'),
      queryInterface.removeColumn('company_details', 'contact_us'),
      queryInterface.removeColumn('company_details', 'industry'),
      queryInterface.removeColumn('company_details', 'web_location'),
    ]);
  }
};

'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.createTable("gs_contacts", {
      id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
      },
      group: {
          type:Sequelize.STRING(100)
      },
      location: {
          type: Sequelize.STRING(100)
      },
      email: {
          type: Sequelize.STRING(100)
      },
      phone: {
          type: Sequelize.STRING(20)
      },
      url: {
          type: Sequelize.STRING(500)
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
  
  })
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.dropTable('gs_contacts');
  }
};

'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.changeColumn('people', 'source', {
      type: Sequelize.ENUM("Linkedin", "crunchbase", "website"),
      defaultValue: "Linkedin"
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.changeColumn('people', 'source', {
      type: Sequelize.ENUM("Linkedin", "crunchbase"),
      defaultValue: "Linkedin"
    });
  }
};

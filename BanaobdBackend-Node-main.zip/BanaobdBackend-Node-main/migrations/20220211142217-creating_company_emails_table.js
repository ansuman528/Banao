'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("company_emails", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      company_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'companies', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
      email_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'emails', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
    })
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.dropTable("company_emails");
  }
};

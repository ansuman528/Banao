'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("search_peoples", "pageCount", {
        after : 'source',
        type: Sequelize.INTEGER(11),
        defaultValue : 1
      }),
    ]);  
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("search_peoples", "pageCount"),
    ]);
  }
};

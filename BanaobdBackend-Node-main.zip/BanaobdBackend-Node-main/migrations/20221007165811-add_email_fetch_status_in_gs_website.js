'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.addColumn('gs_websites', 'email_fetch_status', {
      type: Sequelize.BOOLEAN,
      defaultValue: false

    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.removeColumn("gs_websites", "email_fetch_status")
  }
};

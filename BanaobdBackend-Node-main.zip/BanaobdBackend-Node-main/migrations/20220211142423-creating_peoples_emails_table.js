'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("people_emails", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      people_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'people', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
      email_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'emails', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable("people_emails");
  }
};

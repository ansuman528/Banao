'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("people_websites", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      people_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'people', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
      website: {
        type: Sequelize.INTEGER(11),
        references: { model: 'websites', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
    });
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable("people_website");
  }
};

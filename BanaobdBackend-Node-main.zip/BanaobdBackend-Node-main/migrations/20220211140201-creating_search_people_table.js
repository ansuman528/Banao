'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    return queryInterface.createTable("search_peoples", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      url: {
        type: Sequelize.STRING(100),
        unique: true
      },
      name: {
        type: Sequelize.STRING(50),
      },
      status: {
        type: Sequelize.ENUM("not_scraped", "scraped", "processing"),
        defaultValue: "not_scraped"
      },
      source: {
        type: Sequelize.ENUM("Linkedin", "crunchbase"),
        defaultValue: "Linkedin"
      }
    })
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.dropTable("search_peoples")
  }
};

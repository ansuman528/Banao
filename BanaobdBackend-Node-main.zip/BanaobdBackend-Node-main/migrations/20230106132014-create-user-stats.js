'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.createTable("user_stats", {
      id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    user_id:{
        allowNull: false,
        refrences:{model: 'users', key: 'id'},
        type: Sequelize.INTEGER(11)
    },
    createdAt:{
        allowNull: false,
        type: Sequelize.DATE,
        defaultValue: Sequelize.NOW
    },
    updatedAt:{
      allowNull: false,
      type: Sequelize.DATE,
      defaultValue: Sequelize.NOW
  },
    extensionName:{
      type: Sequelize.STRING(22)
    },
    connectionCount:{
        type: Sequelize.INTEGER(11)
    },
    invitesCount:{
        type: Sequelize.INTEGER(11)   
    },
    // invitesDetails:{
    //     type: Sequelize.ARRAY(Sequelize.STRING),
        
    // },
    messageCount:{
        type: Sequelize.INTEGER(11)
    },
    messageDetails:{
        type: Sequelize.JSON
    }
  
  })
},

  async down (queryInterface, Sequelize) {
    return queryInterface.dropTable('user_stats');
  }
};

'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('messages', 'user_id'),
      queryInterface.removeColumn('messages', 'connection_id'),
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn('messages', 'user_id', {
        type: Sequelize.INTEGER(11)
      }),
      queryInterface.changeColumn('messages', 'connection_id', {
        type: Sequelize.INTEGER(11)
      }),
    ]);
  }
};

"use strict";

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("people_details", "createdAt", {
        allowNull: false,
        type: Sequelize.DATE
      }),
      queryInterface.addColumn("people_details", "updatedAt", {
        allowNull: false,
        type: Sequelize.DATE
      }),
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("people_details", "createdAt"),
      queryInterface.removeColumn("people_details", "updatedAt"),
    ]);
  },
};

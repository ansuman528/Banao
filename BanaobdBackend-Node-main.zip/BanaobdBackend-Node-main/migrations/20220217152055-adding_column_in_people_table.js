'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("people", "linkedin_id", {
        after: 'source',
        type : Sequelize.STRING(20)
      }),
    ]);  
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("people", "linkedin_id")
    ]);
  }
};

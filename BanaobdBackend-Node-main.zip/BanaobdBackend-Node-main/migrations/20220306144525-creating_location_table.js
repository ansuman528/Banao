'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("location_details", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      location: {
        type: Sequelize.TEXT(),
        defaultValue : null
      },
      company_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'companies', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      }
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable('location_details');
  }
};

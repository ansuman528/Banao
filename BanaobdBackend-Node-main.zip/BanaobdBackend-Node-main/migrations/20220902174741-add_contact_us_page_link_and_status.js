'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'gs_websites', 'contact_us_link',
        {
          type: Sequelize.TEXT,
          allowNull: true
        }
      ),
      queryInterface.addColumn(
        'gs_websites', 'contact_us_status',
        {
          type: Sequelize.STRING(200),
          allowNull: true
        }
      ),
      queryInterface.addColumn(
        'gs_websites', 'people_count',
        {
          type: Sequelize.INTEGER(11),
          allowNull: true
        }
      )
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('gs_websites', 'contact_us_link'),
      queryInterface.removeColumn('gs_websites', 'contact_us_status'),
      queryInterface.removeColumn('gs_websites', 'people_count')
    ]);
  }
};

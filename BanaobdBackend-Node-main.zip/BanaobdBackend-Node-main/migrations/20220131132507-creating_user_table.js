'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("users", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      name: {
        type: Sequelize.STRING(50),
      },
      token: {
        type: Sequelize.STRING(50),
      },
      status: {
        type: Sequelize.ENUM("Active", "Blocked"),
        defaultValue: "Blocked"
      },
      last_company_scraped: {
        type: Sequelize.STRING(50),
        defaultValue: null
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      last_scraped: {
        allowNull: false,
        type:  Sequelize.DATE
      }
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable('users');
  }
};

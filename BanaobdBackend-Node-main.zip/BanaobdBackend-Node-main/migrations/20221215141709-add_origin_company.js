'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'companies', 'origin',
        {
          type: Sequelize.STRING(200),
        }
      ),
     
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('companies', 'origin'),
      
    ]);
  }
};

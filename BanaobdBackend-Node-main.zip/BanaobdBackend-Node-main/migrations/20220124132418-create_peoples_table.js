'use strict';

module.exports = {
  async up(queryInterface, Sequelize) {
    queryInterface.createTable("people", {
      id: {
        allowNull: false,
        autoIncrement: true,  
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      url: {
        type: Sequelize.STRING(100),
        unique: true
      },
      name: {
        type: Sequelize.STRING(50),
      },
      status: {
        type: Sequelize.ENUM("not_scraped", "scraped", "processing"),
        defaultValue: "not_scraped"
      },
      source:{
          type: Sequelize.ENUM("Linkedin", "crunchbase"),
          defaultValue: "Linkedin"
      },
      company_id: {
        type: Sequelize.INTEGER(11)
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type:  Sequelize.DATE
      }
    })
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.dropTable('people');
  }
};

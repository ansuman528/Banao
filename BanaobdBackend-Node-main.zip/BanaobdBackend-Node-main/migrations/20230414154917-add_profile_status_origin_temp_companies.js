'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'temp_companies', 'linkedin_profile',
        {
          type: Sequelize.STRING(200),
        }
      ),
      queryInterface.addColumn(
        'temp_companies', 'origin',
        {
          type: Sequelize.STRING(200),
        }
      ),
      queryInterface.addColumn(
        'temp_companies', 'status',
        {
          type: Sequelize.INTEGER,
          defaultValue: 0
        }
      ),
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('temp_companies', 'linkedin_profile'),
      queryInterface.removeColumn('temp_companies', 'origin'),
      queryInterface.removeColumn('temp_companies', 'status'),
    ]);
  }
};

'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn('messages', 'user_id', {
        allowNull: false,
        refrences:{model: 'users', key: 'id'},
        type: Sequelize.INTEGER(11),
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
      }),
      queryInterface.addColumn('messages', 'connection_id', {
        allowNull: false,
        refrences:{model: 'user_connection_details', key: 'id'},
        type: Sequelize.INTEGER(11),
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
      }),
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('messages', 'user_id'),
      queryInterface.removeColumn('messages', 'connection_id'),
    ]);
  }
};

'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.createTable("gs_websites", {
      id:{
          allowNull:false,
          autoIncrement:true,
          primaryKey:true,
          type: Sequelize.INTEGER(11),
      },
      website: {
          type: Sequelize.STRING(200),
          
      },
      group: {
          type:Sequelize.STRING(100)
      },
      location: {
          type: Sequelize.STRING(100)
      },
      crawl_status: {
          type: Sequelize.INTEGER(2),
          defaultValue: 0
      },
      email_search: {
          type: Sequelize.INTEGER(2),
          defaultValue: 0
      },
      events_found: {
          type: Sequelize.INTEGER(2),
          defaultValue: 0
      },
      jobs_found: {
          type: Sequelize.INTEGER(2),
          defaultValue: 0
      },
      education_found: {
          type: Sequelize.INTEGER(2),
          defaultValue: 0
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
  
  })
  },

  async down (queryInterface, Sequelize) {
    return queryInterface.dropTable('gs_websites');
  }
};

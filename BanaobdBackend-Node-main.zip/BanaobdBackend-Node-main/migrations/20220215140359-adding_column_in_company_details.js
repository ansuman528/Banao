'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn('company_details', 'number', {
        after : 'companyEmail' ,
        type: Sequelize.BIGINT(20),
      }),
    ]);
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('company_details', 'number'),
    ]);
  }
};

'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("users", "CompanyCount", {
        after : 'scrapeCount',
        type: Sequelize.INTEGER(11),
        defaultValue : 10
      }),
    ]);  
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("users", "CompanyCount"),
    ]);
  }
};

"use strict";

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("company_details", "gmap_address", {
        type: Sequelize.STRING(255)
      }),
      queryInterface.addColumn("company_details", "gmap_rating", {
        type: Sequelize.FLOAT(5)
      }),
      queryInterface.addColumn("company_details", "gmap_num_rating", {
        type: Sequelize.INTEGER(11)
      }),
      queryInterface.addColumn("company_details", "gmap_status", {
        type: Sequelize.STRING(100)
      }),
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("company_details", "gmap_address"),
      queryInterface.removeColumn("company_details", "gmap_rating"),
      queryInterface.removeColumn("company_details", "gmap_num_rating"),
      queryInterface.removeColumn("company_details", "gmap_status"),
    ]);
  },
};

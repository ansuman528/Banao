'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'gs_websites', 'industry',
        {
          type: Sequelize.STRING(70),
          allowNull: true
        }
      )
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('gs_websites', 'industry')
    ]);
  }
};

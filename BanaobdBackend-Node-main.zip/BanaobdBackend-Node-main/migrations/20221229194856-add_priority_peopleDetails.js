'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'people_details', 'priority',
        {
          type: Sequelize.INTEGER(11),
          defaultValue: 0
        }
      ),
      
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('people_details', 'priority'),
    ]);
  }
};

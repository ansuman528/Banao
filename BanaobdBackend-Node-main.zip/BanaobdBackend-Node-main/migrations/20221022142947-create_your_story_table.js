'use strict';
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('your_stories', {
      id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
      },
      url : {
          type: Sequelize.STRING(20),
          unique: true
      },
      status:{
          type: Sequelize.ENUM("not_scraped", "scraped", "processing"),
          defaultValue: "not_scraped"
      },
      priority :{
          type: Sequelize.INTEGER(11),
          defaultValue: 0
      },
      createdAt: {
        allowNull: false,
        type: Sequelize.DATE
      },
      updatedAt: {
        allowNull: false,
        type: Sequelize.DATE
      }
    });
  },
  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('your_story');
  }
};
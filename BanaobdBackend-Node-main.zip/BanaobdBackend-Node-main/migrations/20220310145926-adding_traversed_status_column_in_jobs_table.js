'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("job_details", "status", {
        type: Sequelize.ENUM("traversed", "not_traversed"),
        defaultValue: "not_traversed"
      }),
    ]);  
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("job_details", "status"),
    ]);
  }
};

'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("user1s", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      name: {
        type: Sequelize.STRING(50),
      },
      token: {
        type: Sequelize.STRING(50),
      },
      status: {
        type: Sequelize.ENUM("Active", "Blocked"),
        defaultValue: "Blocked"
      },
      last_fetched_id: {
        type : Sequelize.TEXT(),
        defaultValue: null,
      },
      last_fetch_time: {
        type: Sequelize.DATE,
        defaultValue: null
      },
      last_access_time: {
        allowNull: false,
        type:  Sequelize.DATE
      }
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable('user1s');
  }
};

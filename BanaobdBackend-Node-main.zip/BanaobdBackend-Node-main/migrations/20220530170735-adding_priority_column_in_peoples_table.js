'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("people", "priority", {
        type: Sequelize.INTEGER(11),
        after: "linkedin_id",
        defaultValue: 0
      }),
    ]);  
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("people", "priority")
    ]);
  }
};

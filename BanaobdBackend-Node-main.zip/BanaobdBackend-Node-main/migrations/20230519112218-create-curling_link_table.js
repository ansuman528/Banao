'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    await queryInterface.createTable('crawling_links', {
      id: {
        type: Sequelize.INTEGER,
        primaryKey: true,
        autoIncrement: true
      },
      website: {
        type: Sequelize.STRING(100),
        allowNull: false,
      },
      url_links: {
        type: Sequelize.STRING(255),
        allowNull: false
      },
      is_status: {
        type: Sequelize.INTEGER,
      },
      data: {
        type: Sequelize.TEXT,
      },
      created_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      },
      updated_at: {
        type: Sequelize.DATE,
        defaultValue: Sequelize.literal('CURRENT_TIMESTAMP')
      }
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.removeConstraint('crawling_links', 'crawling_links_website_foreign_key');
    await queryInterface.dropTable('crawling_links');
  }
};

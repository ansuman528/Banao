'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("company_phones", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      company_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'company_details', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
      phone_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'phones', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
    })
  },

  async down(queryInterface, Sequelize) {
    return queryInterface.dropTable("company_phones");
  }
};

'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("company_details", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      description: {
        type: Sequelize.STRING(5000),
      },
      domain: {
        type: Sequelize.STRING(1000),
      },
      website: {
        type: Sequelize.STRING(200),
      },
      companyType : {
          type: Sequelize.STRING(50),
      },
      fundingType : {
          type: Sequelize.STRING(50),
      },
      location : {
          type: Sequelize.STRING(100),
      },
      companyEmail : {
          type: Sequelize.STRING(100),
      },
      rank : {
          type: Sequelize.INTEGER(10),
      },
      employeeSize: {
        type: Sequelize.INTEGER(10),
      },
      followers: {
        type: Sequelize.INTEGER(10),
      },
      headquarter: {
        type: Sequelize.STRING(200),
      },
      company_id: {
        type: Sequelize.INTEGER(11),
      },
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable('company_details');
  }
};

'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("users", "last_company_scraped", {
        type : Sequelize.TEXT(),
        defaultValue: null,
      })
    ]);
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("users", "last_company_scraped", {
        type : Sequelize.STRING(500),
        defaultValue: null,
      })
    ]);
  }
};

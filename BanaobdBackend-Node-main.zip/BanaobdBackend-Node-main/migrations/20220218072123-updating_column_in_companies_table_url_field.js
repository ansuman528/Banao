'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("companies", "url", {
        type: Sequelize.STRING(1000),
        unique :true
      })
    ])
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("companies", "url", {
        type: Sequelize.STRING,
        unique: true
      })
    ]);
  }
};

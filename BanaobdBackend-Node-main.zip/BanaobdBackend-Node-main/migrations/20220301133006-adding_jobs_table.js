'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("job_details", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      jobUrl: {
        type: Sequelize.STRING(200),
        unique: true
      },
      jobTitle: {
        type: Sequelize.STRING(100),
      },
      companyName: {
        type: Sequelize.STRING(100),
      },
      location: {
        type: Sequelize.STRING(100),
      },
      datePosted: {
        type: Sequelize.STRING(100),
      },
      activelyHiring: {
        type: Sequelize.BOOLEAN,
        defaultValue: true
      }
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable('job_details');
  }
};

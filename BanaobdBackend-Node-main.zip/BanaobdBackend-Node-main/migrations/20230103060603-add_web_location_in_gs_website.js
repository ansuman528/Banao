'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'gs_websites', 'web_location',
        {
          type: Sequelize.TEXT,
          allowNull: true
        }
      ),
      queryInterface.addColumn(
        'gs_websites', 'rank',
        {
          type: Sequelize.STRING(20),
          allowNull: true
        }
      ),
      queryInterface.addColumn(
        'gs_websites', 'twitter',
        {
          type: Sequelize.STRING(300),
        }
      ),
      queryInterface.addColumn(
        'gs_websites', 'linkedin',
        {
          type: Sequelize.STRING(300),
        }
      ),
      queryInterface.addColumn(
        'gs_websites', 'facebook',
        {
          type: Sequelize.STRING(300),
        }
      ),
      queryInterface.addColumn(
        'gs_websites', 'instagram',
        {
          type: Sequelize.STRING(300),
        }
      ),
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('gs_websites', 'web_location'),
      queryInterface.removeColumn('gs_websites', 'rank'),
      queryInterface.removeColumn('gs_websites', 'twitter'),
      queryInterface.removeColumn('gs_websites', 'linkedin'),
      queryInterface.removeColumn('gs_websites', 'facebook'),
      queryInterface.removeColumn('gs_websites', 'instagram'),
    ]);
  }
};

'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("company_details", "createdAt", {
        allowNull: false,
        type: Sequelize.DATE
      }),
      queryInterface.addColumn("company_details", "updatedAt", {
        allowNull: false,
        type: Sequelize.DATE
      })
    ]);
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("company_details", "createdAt"),
      queryInterface.removeColumn("company_details", "updatedAt")
    ])
  }
};

'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.createTable('scraping_website', {
      id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
      },
      url:{
        type: Sequelize.STRING(100)
      },
      name:{
        type: Sequelize.STRING(50)
      },
      priority:{
        type: Sequelize.INTEGER(11)
      },
      scrapping_frquency:{
        type: Sequelize.INTEGER(11)
      },
      starting_url:{
        type: Sequelize.STRING(100)
      },
      url_element:{
        type: Sequelize.STRING(50)
      },
      py_script:{
        type: Sequelize.STRING(50)
      },
      pagination_element:{
        type: Sequelize.STRING(50)
      },
      data:{
        type: Sequelize.JSON
      },
    })
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};

'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('people', 'company_id'),
    ]);
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn('people', 'company_id', {
        type: Sequelize.INTEGER(11),
        allowNull: true,
      })
    ]);
  }
};

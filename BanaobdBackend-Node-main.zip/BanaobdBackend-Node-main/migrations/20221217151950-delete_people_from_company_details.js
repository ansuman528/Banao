'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('company_details', 'people'),
     
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.dropTable('company_details'),
    ]);
  }
};

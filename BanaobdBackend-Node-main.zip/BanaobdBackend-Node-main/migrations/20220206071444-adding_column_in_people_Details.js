'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn('people_details', 'about', {
        after : 'email' ,
        type: Sequelize.STRING(3000),
        allowNull: true,
      }),
      queryInterface.addColumn('people_details', 'connects', {
        after : 'about' ,
        type: Sequelize.INTEGER(11),
        allowNull: true,
      }),
      queryInterface.addColumn('people_details', 'followers', {
        after : 'connects' ,
        type: Sequelize.INTEGER(11),
        allowNull: true,
      }),
      queryInterface.addColumn('people_details', 'education', {
        after : 'followers',
        type: Sequelize.JSON,
        allowNull: true,
      }),
      queryInterface.addColumn('people_details', 'skills', {
        after : 'education' ,
        type: Sequelize.STRING(3000),
        allowNull: true,
      }),
      queryInterface.addColumn('people_details', 'certification', {
        after : 'skills',
        type: Sequelize.JSON,
        allowNull: true,
      }),
    ]);
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('people_details', 'about'),
      queryInterface.removeColumn('people_details', 'connects'),
      queryInterface.removeColumn('people_details', 'followers'),
      queryInterface.removeColumn('people_details', 'education'),
      queryInterface.removeColumn('people_details', 'skills'),
      queryInterface.removeColumn('people_details', 'certification'),
    ]);
  }
};

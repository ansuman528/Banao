'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("search_companies", "url" , {
        type: Sequelize.STRING(1000),
        unique :true
      }),
      queryInterface.changeColumn("search_companies", "name" , {
        type: Sequelize.STRING(500),
      }),
    ]);
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("search_companies", "url" , {
        type: Sequelize.STRING(20),
        unique :true
      }),
      queryInterface.changeColumn("search_companies", "name" , {
        type: Sequelize.STRING(50),
      }),
    ])
  }
};

'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("worksIns", "people_id", {
        type: Sequelize.BIGINT(11),
        references: { model: 'people', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      })
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("worksIns", "people_id",{
        type: Sequelize.INTEGER(11),
      }),
    ])
  }
};

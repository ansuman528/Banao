'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("company_websites", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      company_id: {
        type: Sequelize.INTEGER(11),
        references: { model: 'companies', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
      website: {
        type: Sequelize.INTEGER(11),
        references: { model: 'websites', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      },
    });
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable("company_website");
  }
};

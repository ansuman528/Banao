'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.changeColumn('companies', 'searchStatus', {
      type: Sequelize.ENUM("not_searched", "searched", "processing"),
      defaultValue: "not_searched"
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.changeColumn('companies', 'searchStatus', {
      type: Sequelize.ENUM("not_searched", "searched"),
      defaultValue: "not_searched"
    });
  }
};

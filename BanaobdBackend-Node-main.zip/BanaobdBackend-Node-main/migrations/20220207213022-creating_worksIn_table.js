'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("worksIns",
      {
        id: {
          allowNull: false,
          autoIncrement: true,
          primaryKey: true,
          type: Sequelize.INTEGER(11),
        },
        company_id: {
          type: Sequelize.INTEGER(11),
          references: { model: 'companies', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL',
        },
        people_id: {
          type: Sequelize.INTEGER(11),
          references: { model: 'people', key: 'id' },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL',
        },
        Designation: {
          type: Sequelize.STRING(50),
        },
        from_date: {
          type: Sequelize.STRING(20),
        },
        to_date: {
          type: Sequelize.STRING(20),
        },
        presently :{
          type : Sequelize.BOOLEAN,
          defaultValue: true
        }
      }
    );
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable('worksIns');
  }
};

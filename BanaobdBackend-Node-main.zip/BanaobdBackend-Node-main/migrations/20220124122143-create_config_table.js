'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("configs", {
      id: {
        type: Sequelize.INTEGER(11),
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
      },
      company_letter: {
        type: Sequelize.CHAR,
        required: true
      },
      page_no: {
        type: Sequelize.INTEGER,
      },
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable('configs');
  }
};

'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("emails", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      email_id: {
        type: Sequelize.STRING(50),
      },
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable("emails")
  }
};

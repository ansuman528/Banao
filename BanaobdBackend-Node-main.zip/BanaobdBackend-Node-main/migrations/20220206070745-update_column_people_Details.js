'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn('people_details', 'number', {
        type: Sequelize.STRING(20),
      }),
      queryInterface.changeColumn('people_details', 'people_id', {
        type: 'FOREIGN KEY',
        references: { model: 'people', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      }),
      queryInterface.changeColumn('people_details', 'experience', {
        type: Sequelize.JSON,
      }),
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn('people_details', 'number', {
        type: Sequelize.BIGINT(10),
      }),
      queryInterface.changeColumn('people_details', 'people_id', {
        type: Sequelize.INTEGER(11)
      }),
      queryInterface.changeColumn('people_details', 'experience', {
        type: Sequelize.STRING(100),
      }),
    ]);
  }
};

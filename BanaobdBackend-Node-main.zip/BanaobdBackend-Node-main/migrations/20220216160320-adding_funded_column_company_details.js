'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("company_details", "founded", {
        after : 'headquarter',
        type : Sequelize.STRING(10),
      })
    ]);
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("company_details", "founded"),
    ])
  }
};

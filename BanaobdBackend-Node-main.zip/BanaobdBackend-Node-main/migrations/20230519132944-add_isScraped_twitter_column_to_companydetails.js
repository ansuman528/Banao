'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn(
        'company_details', 'isScraped_twitter',
        {
          type: Sequelize.INTEGER(10),
          defaultValue: 0
        }
      ),
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn(
        'company_details', 'isScraped_twitter',
        {
          type: Sequelize.BOOLEAN,
          defaultValue: 0
        }
      ),
      
    ]);
  }
};

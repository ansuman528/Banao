'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn('people_details', 'twitter', {
        type: Sequelize.STRING(300),
      }),
      queryInterface.changeColumn('people_details', 'linkedin', {
        type: Sequelize.STRING(300),
      }),
      queryInterface.changeColumn('people_details', 'facebook', {
        type: Sequelize.STRING(300),
      }),

    ]);
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn('people_details', 'twitter', {
        type: Sequelize.STRING(50),
      }),
      queryInterface.changeColumn('people_details', 'linkedin', {
        type: Sequelize.STRING(50),
      }),
      queryInterface.changeColumn('people_details', 'facebook', {
        type: Sequelize.STRING(50),
      }),
    ]);
  }
};

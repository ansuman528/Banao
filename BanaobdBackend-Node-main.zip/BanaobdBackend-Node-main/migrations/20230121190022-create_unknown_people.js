'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.createTable("user_stats", {
      id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    company_id:{
        allowNull: false,
        refrences:{model: 'companies', key: 'id'},
        type: Sequelize.INTEGER(11)
    },
    position:{
        type: Sequelize.STRING(50)
    },
    location:{
        type: Sequelize.STRING(22)
    }
  
  })
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};

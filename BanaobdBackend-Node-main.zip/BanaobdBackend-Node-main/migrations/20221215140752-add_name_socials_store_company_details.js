'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'company_details', 'name',
        {
          type: Sequelize.STRING(200),
        }
      ),
      queryInterface.addColumn(
        'company_details', 'category',
        {
          type: Sequelize.STRING(200),
        }
      ),
      queryInterface.addColumn(
        'company_details', 'linkedin',
        {
          type: Sequelize.STRING(200),
        }
      ),
      queryInterface.addColumn(
        'company_details', 'facebook',
        {
          type: Sequelize.STRING(200),
        }
      ),
      queryInterface.addColumn(
        'company_details', 'twitter',
        {
          type: Sequelize.STRING(200),
        }
      ),
      queryInterface.addColumn(
        'company_details', 'play_store',
        {
          type: Sequelize.STRING(200),
        }
      ),
      queryInterface.addColumn(
        'company_details', 'app_store',
        {
          type: Sequelize.STRING(200),
        }
      ),
      queryInterface.addColumn(
        'company_details', 'people',
        {
          type: Sequelize.JSON,
        }
      )
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('company_details', 'name'),
      queryInterface.removeColumn('company_details', 'category'),
      queryInterface.removeColumn('company_details', 'linkedin'),
      queryInterface.removeColumn('company_details', 'facebook'),
      queryInterface.removeColumn('company_details', 'twitter'),
      queryInterface.removeColumn('company_details', 'play_store'),
      queryInterface.removeColumn('company_details', 'app_store'),
      queryInterface.removeColumn('company_details', 'people'),
    ]);
  }
};

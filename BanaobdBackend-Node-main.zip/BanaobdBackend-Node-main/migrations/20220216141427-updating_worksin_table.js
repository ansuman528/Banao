'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn('worksIns', 'search_company_id',{
        after: 'people_id',
        type: Sequelize.INTEGER(11),
        references: { model: 'search_companies', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      }),
    ]);
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('worksIns', 'search_company_id')
    ]);
  }
};

'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("companies", "priority", {
        type: Sequelize.INTEGER(11),
        defaultValue: 0
      })
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn("companies", "priority",{
        type : Sequelize.BOOLEAN,
        defaultValue: false 
      }),
    ])
  }
};

'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.createTable("updated_userStats", {
      id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    user_id:{
        allowNull: false,
        refrences:{model: 'users', key: 'id'},
        type: Sequelize.INTEGER(11)
    },
    date:{
        allowNull: false,
        type: Sequelize.DATEONLY,
    },
    location:{
      type: Sequelize.STRING(25)
    },
    status:{
        type: Sequelize.STRING(11)
    },
    requestSend:{
        type: Sequelize.INTEGER(11)
    },
    accepted:{
        type: Sequelize.INTEGER(11)
    },
    messaged:{
        type: Sequelize.INTEGER(11),
    },
    extension:{
        type: Sequelize.STRING(50)
    }
  })
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};

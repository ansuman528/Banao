'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'company_details', 'isScraped_linkedin',
        {
          type : Sequelize.BOOLEAN,
          defaultValue: false
        }
      ),
      queryInterface.addColumn(
        'company_details', 'priority',
        {
          type: Sequelize.INTEGER(11),
          defaultValue: 0
        }
      ),
      
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('company_details', 'isScraped_linkedin'),
      queryInterface.removeColumn('company_details', 'priority'),
      
    ]);
  }
};

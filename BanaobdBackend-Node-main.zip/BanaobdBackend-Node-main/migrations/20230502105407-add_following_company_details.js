"use strict";

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("company_details", "following", {
        after: "followers",
        type: Sequelize.INTEGER(10),
        defaultValue: 0
      }),
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("company_details", "following"),
    ]);
  },
};

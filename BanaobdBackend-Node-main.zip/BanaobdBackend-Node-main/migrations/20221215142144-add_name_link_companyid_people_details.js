'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'people_details', 'name',
        {
          type: Sequelize.STRING(50),
        }
      ),
      queryInterface.addColumn(
        'people_details', 'link',
        {
          type: Sequelize.STRING(50),
        }
      ),
      queryInterface.addColumn(
        'people_details', 'company_id',
        {
          type: Sequelize.INTEGER(11),
        }
      ),
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('people_details', 'name'),
      queryInterface.removeColumn('people_details', 'link'),
      queryInterface.removeColumn('people_details', 'company_id'),
    ]);
  }
};

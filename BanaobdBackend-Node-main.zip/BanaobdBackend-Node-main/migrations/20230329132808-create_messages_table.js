'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.createTable("messages", {
      id:{
        allowNull:false,
        autoIncrement:true,
        primaryKey:true,
        type: Sequelize.INTEGER(11),
    },
    user_id:{
        allowNull: false,
        refrences:{model: 'users', key: 'id'},
        type: Sequelize.INTEGER(11)
    },
    connection_id:{
        allowNull: false,
        refrences:{model: 'user_connection_details', key: 'id'},
        type: Sequelize.INTEGER(11)
    },
    sendDate:{
        type: Sequelize.DATEONLY
    },
    message:{
        type: Sequelize.STRING(500)
    },
    time:{
        type: Sequelize.TIME
    },
    sender:{
        type: Sequelize.STRING(50)
    }
  })
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};

'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn('company_details', 'company_id', {
        type: Sequelize.BIGINT(11),
        references: { model: 'companies', key: 'id' },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      }),
      queryInterface.changeColumn('company_details', 'rank', {
        type: Sequelize.STRING(20),
      }),
      queryInterface.changeColumn('company_details', 'employeeSize', {
        type: Sequelize.STRING(20),
      }),
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn('company_details', 'company_id', {
        type: Sequelize.INTEGER(11)
      }),
      queryInterface.changeColumn('company_details', 'rank', {
        type: Sequelize.INTEGER(11)
      }),
      queryInterface.changeColumn('company_details', 'employeeSize', {
        type: Sequelize.INTEGER(11)
      }),
    ]);
  }
};

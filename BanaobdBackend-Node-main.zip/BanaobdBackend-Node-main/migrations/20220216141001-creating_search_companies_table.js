'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("search_companies", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      url: {
        type: Sequelize.STRING(20),
        unique: true
      },
      name: {
        type: Sequelize.STRING(50),
      },
      linkedin_id: {
        type: Sequelize.STRING(20),
      },
      source: {
        type: Sequelize.ENUM("Linkedin", "crunchbase"),
        defaultValue: "Linkedin"
      }
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable("search_companies");
  }
};

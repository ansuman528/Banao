'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'company_details', 'insta_posts',
        {
          type:Sequelize.INTEGER(11)
        }
      ),
      queryInterface.addColumn(
        'company_details', 'insta_followers',
        {
          type:Sequelize.INTEGER(11)
        }
      ),
      queryInterface.addColumn(
        'company_details', 'insta_category',
        {
          type:Sequelize.STRING(200)
        }
      ),
      queryInterface.addColumn(
        'company_details', 'insta_description',
        {
          type:Sequelize.STRING(500)
        }
      ),
      queryInterface.addColumn(
        'company_details', 'insta_website',
        {
          type:Sequelize.STRING(500)
        }
      )
    ]);
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};

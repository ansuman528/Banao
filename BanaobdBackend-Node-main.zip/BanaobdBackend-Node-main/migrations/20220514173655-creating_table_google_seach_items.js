'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return queryInterface.createTable("google_search_items", {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: Sequelize.INTEGER(11),
      },
      items: {
        type: Sequelize.STRING(300),
      },
      fetched_status: {
        type: Sequelize.STRING(100),
      },
    })
  },

  down(queryInterface, Sequelize) {
    return queryInterface.dropTable('google_search_items');
  }
};

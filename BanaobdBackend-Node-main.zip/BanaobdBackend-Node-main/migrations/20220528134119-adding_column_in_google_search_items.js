'use strict';

module.exports = {
  up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn("google_search_items", "skill", {
        type: Sequelize.STRING(30),
        defaultValue: null
      }),
    ]);  
  },

  down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn("google_search_items", "skill")
    ]);
  }
};

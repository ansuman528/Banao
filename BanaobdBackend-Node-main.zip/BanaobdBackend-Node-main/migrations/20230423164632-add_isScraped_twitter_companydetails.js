'use strict';

module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'company_details', 'isScraped_twitter',
        {
          type: Sequelize.BOOLEAN,
          defaultValue: 0
        }
      ),
    ]);
  },

  async down (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.removeColumn('company_details', 'isScraped_twitter'),
      
    ]);
  }
};

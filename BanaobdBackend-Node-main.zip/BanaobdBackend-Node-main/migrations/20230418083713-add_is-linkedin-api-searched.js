'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.addColumn(
        'company_details', 'linkedin_api_searched',
        {
          type: Sequelize.INTEGER(5),
          defaultValue: 0
        }
      )
    ]);
  },

  async down (queryInterface, Sequelize) {
    queryInterface.removeColumn('company_details', 'linkedin_api_searched');
  }
};

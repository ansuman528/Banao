'use strict';

module.exports = {
  up(queryInterface, Sequelize) {
    return Promise.all([
      queryInterface.changeColumn('messages', 'user_id', {
        allowNull: false,
        refrences:{model: 'users', key: 'id'},
        type: Sequelize.INTEGER(11),
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      }),
      queryInterface.changeColumn('messages', 'connection_id', {
        allowNull: false,
        refrences:{model: 'user_connection_details', key: 'id'},
        type: Sequelize.INTEGER(11),
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL',
      }),
    ]);
  },

  down(queryInterface, Sequelize) {
    return Promise.all([
      
      queryInterface.changeColumn('messages', 'user_id', {
        type: Sequelize.INTEGER(11)
      }),
      queryInterface.changeColumn('messages', 'connection_id', {
        type: Sequelize.INTEGER(11)
      }),
    ]);
  }
};

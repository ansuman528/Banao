'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    return queryInterface.createTable("shorten_URL", {
      id:{
          allowNull:false,
          autoIncrement:true,
          primaryKey:true,
          type: Sequelize.INTEGER(11),
      },
      url : {
          type: Sequelize.STRING(100),
          unique: true
      },
      short_url : {
          type: Sequelize.STRING(100),
          unique: true
      },
      created_by : {
          type: Sequelize.STRING(50),
      },
      created_at:{
          type: Sequelize.DATE,
          defaultValue: Sequelize.NOW
      },
      updated_at:{
          type: Sequelize.DATE,
          defaultValue: Sequelize.NOW
      },
  }, {timestamps: false});
  },

  async down (queryInterface, Sequelize) {
    /**
     * Add reverting commands here.
     *
     * Example:
     * await queryInterface.dropTable('users');
     */
  }
};

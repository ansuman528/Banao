// Get the form element and add a submit event listener
let shortenerForm = document.getElementById('shortenerForm');
shortenerForm.addEventListener('submit', async function (event) {
    // Prevent the default form submission behavior
    event.preventDefault();

    // Get the info, url, and token elements
    let info = document.getElementById('info');
    let urlInput = document.getElementById('url');
    let tokenInput = document.getElementById('token');

    // Get the values of the url and token inputs
    let urlValue = urlInput.value;
    let tokenValue = tokenInput.value;

    // Send a POST request to the API to shorten the URL
    await fetch(`https://bbd.atg.party/api/shorten-url?url=${urlValue}&token=${tokenValue}`, {
        method: 'POST',
    })
    .then(response => response.json())
    .then(data => {
        // Display the shortened URL in the info element
        info.innerHTML = data.message;
        // Reset the values of the url and token inputs
        shortenerForm.reset();
    })
    .catch(error => console.error(error));
});



const editForm = document.getElementById('edit_form');
const editBtn = document.getElementById('edit_btn');
const saveBtn = document.getElementById('save_btn');
const info_edit = document.getElementById('info_edit');
let tokenInput = document.getElementById('token_edit');
let shortUrlInput = document.getElementById('short_url_edit');
let longUrlInput = document.getElementById('edited_url');

editBtn.addEventListener('click', async function (event) {
    event.preventDefault();
    let isLinkExist = false;
    let tokenValue = tokenInput.value;
    let shortUrlValue = shortUrlInput.value;

    await fetch(`https://bbd.atg.party/api/check-short-url?short_url=${shortUrlValue}&token=${tokenValue}`, {
        method: 'GET',
    })
    .then(response => response.json())
    .then(data => {
        if (data.message === true) {
            isLinkExist = true;
            document.getElementById('edited_url').style.display = 'block';
            editBtn.style.display = 'none';
            saveBtn.style.display = 'block';
            tokenInput.disabled = true;
            shortUrlInput.disabled = true;
            info_edit.innerHTML = 'Link exists. Please click on the save button to update the long URL.';
        } else if(data.message === false) {
            isLinkExist = false;
            
            info_edit.innerHTML = 'Link does not exist.';
        }
        else{
            info_edit.innerHTML = data.message;
        }
    })
    .catch(error => console.error(error));
});

saveBtn.addEventListener('click', async function (event) {
    event.preventDefault();

    let tokenValue = tokenInput.value;
    let shortUrlValue = shortUrlInput.value;
    let longUrlValue = longUrlInput.value;
    await fetch(`https://bbd.atg.party/api/edit-url?short_url=${shortUrlValue}&long_url=${longUrlValue}&token=${tokenValue}`)
    .then(response => response.json())
    .then(data => {
        info_edit.innerHTML = data.message;
        editForm.reset();
        document.getElementById('edited_url').style.display = 'none';
        tokenInput.disabled = false;
        shortUrlInput.disabled = false;
        editBtn.style.display = 'block';
        saveBtn.style.display = 'none';
    })
    .catch(error => {console.error(error);info_edit.innerHTML = data.name.errors[0];});
});

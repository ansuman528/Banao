let datesArray = [];
let payload = []
let token;
let userRole;
let messagesData=[];
let selectedEditItem=null;
// let API="http://localhost:8000"
let API="https://bbd.atg.party"

const dateInput = document.getElementById("date-input");
const getDate = document.getElementById('get-button')
let tableBody=document.getElementsByTagName("tbody");
const loader = document.querySelector('.loader');
const blockBtn=document.getElementById('block_btn')
let url = new URL(window.location);
token=url.searchParams.get('token')
document.getElementById('token').value=token
getPreviousSixDates(new Date())

// for (let i = 0; i< 7; i++) {
//     const currentDate = new Date();
//     currentDate.setDate(currentDate.getDate() - i);
//     const formattedDate = currentDate.toLocaleDateString("en-GB");
//     payload.push(currentDate.toLocaleDateString("sv-SE"))
//     //document.getElementById(`th${7-i}`).innerText = formattedDate  
//     let th=document.getElementById(`th${i+1}`);
//     let d=formattedDate.split("/")
//     th.innerText = formattedDate
//     if(new Date(`${d[1]}/${d[0]}/${d[2]}`).getDay()=='0')
//         th.classList.add("error")
//     else
//         th.className=''
//     payload.reverse()
// }

let slCol=document.querySelectorAll(".slno");
let nameCol=document.querySelectorAll(".name");
let locationCol=document.querySelectorAll(".location");
let tokenCol=document.querySelectorAll(".token");
let slColWidth=slCol[0].getBoundingClientRect().width;
let nameColWidth=nameCol[0].getBoundingClientRect().width;
let locationColWidth=locationCol[0].getBoundingClientRect().width;
let tokenColWidth=tokenCol[0].getBoundingClientRect().width;

function fixStyles(){
    slCol=document.querySelectorAll(".slno");
    nameCol=document.querySelectorAll(".name");
    locationCol=document.querySelectorAll(".location");
    tokenCol=document.querySelectorAll(".token");
    slColWidth=slCol[0].getBoundingClientRect().width;
    nameColWidth=nameCol[0].getBoundingClientRect().width;
    locationColWidth=locationCol[0].getBoundingClientRect().width;
    tokenColWidth=tokenCol[0].getBoundingClientRect().width;
    
    nameCol.forEach(i=>{
        i.style.position="sticky"
        i.style.left=slColWidth+"px"})
    locationCol.forEach(i=>{
        i.style.position="sticky"
    i.style.left=slColWidth+nameColWidth+"px"})
    tokenCol.forEach(i=>{
            i.style.position="sticky"
        i.style.left=slColWidth+nameColWidth+locationColWidth+"px"})
}
fixStyles()
if(token)
  {
    initializeTable()
   // getData()
}
function initializeTable(page=1,date=payload[0]){
    loader.style.display = "flex";
    let payload_date=[]
    payload_date.push(date)
    tableBody[0].innerHTML=''
    console.log(payload)
    
    fixStyles()
    fetch(`${API}/api/getUserScoreList?page=${page}`,{
        method: 'POST',
        body: JSON.stringify({'token':token}),
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then((data) =>{
            if(data?.success===false)
            {
                loader.style.display = "none";
              alert(data.message)
            }else{
                console.log(data)
                userRole=data.det[0].userType;
                if(userRole==='Captain' || userRole == "Admin"){
                    document.getElementById('right').style.display='inline-block';
                    document.getElementById('url_short').style.display='inline-block';
                    blockBtn.style.display='inline-block';
                }
                else{
                    document.getElementById('right').style.display='none';
                    document.getElementById('url_short').style.display='none';
                    blockBtn.style.display='none';
                }
            
            load_table(data.det[1].result)
            //getData()
            fixStyles()
            loader.style.display = "none";
            }})
            .catch(error => { 
            if (error?.response?.status === 500) {
              alert('User not found');
            } else {
              console.error('Error:', error);
            }
            loader.style.display = "none";
        });
}
function updateAttendance(colId){
    let total=0,present=0
    let statuses=document.querySelectorAll('.status')
    let th=document.getElementById(`${colId}`)
    let date=th.getAttribute('data-date')
    for(let i=0;i<statuses.length;i++)
    {
        if(statuses[i].parentElement.parentElement.classList.contains(date))
          {
            total++;
            if(statuses[i].innerText==='P')
            present++
          }
    }
    
     th.innerHTML=`${date.split("-").reverse().join("/")} <span class="highlight">(${present}/${total})</span>`
        
    
}
function setLoader(name)
{
    console.log("in",name)
  let tds=document.getElementsByTagName("td")
  for(let i=0;i<tds.length;i++)
    if(tds[i].classList.contains(name))
    tds[i].innerHTML='<div>loading...</div>'
    console.log("our")
}
function getData(page=1,date=payload[0],colId='th1') {
    //loader.style.display = "flex";
    let payload_date=[]
    payload_date.push(date)
    //tableBody[0].innerHTML=''
    console.log(payload)
    fixStyles()
    fetch(`${API}/api/getUserScore?page=${page}`,{

        method: 'POST',
        body: JSON.stringify({"dates": payload_date,'token':token}),
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then((data) =>{

            console.log(data);
            if(data?.success===false)
            {
                //loader.style.display = "none";
              alert(data.message)
            }else{
                console.log(data.det[0].userType);
                //console.log(data)
                userRole=data.det[0].userType;
                if(userRole==='Captain' || userRole == "Admin"){
                    document.getElementById('right').style.display='inline-block';
                    document.getElementById('url_short').style.display='inline-block';
                }
                else{
                    document.getElementById('right').style.display='none';
                    document.getElementById('url_short').style.display='none';
                }
                 let index=1;
                 if(!data.det)
                 {
                        alert("Data not found")
                        loader.style.display = "none";
                 }
                 else{
                    loader.style.display = "none";
                    
                    for(let i=0;i<data.det[3].result.length;i++){
                         
                             addEntry(data.det[3].result[i],i+1)
                            
                            updateAttendance(colId);
                    }
                    
                    
                    //checkBoxFunction();
                    if(data.det[1].current_page<data.det[2].pages)
                      getData(data.det[1].current_page +1,date,colId)
                 }
            }
             
        })
        .catch(error => {
            if (error?.response?.status === 500) {
              alert('User not found');
            } else {
              console.error('Error:', error);
            }
            loader.style.display = "none";
        });
}
function getSpecificUserData(token,index){
    //loader.style.display = "flex";
    setLoader(token)
    fetch(`${API}/api/getSpecificUserScore`,{

        method: 'POST',
        body: JSON.stringify({"dates": payload,'token':token}),
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then((data) =>{
            //loader.style.display = "none";
            console.log("user specific",data);
            for(let i=0;i<data.result.length;i++)
             addEntry(data.result[i],index)
            for(let i=0;i<payload.length;i++)
              updateAttendance(`th${i+1}`)
        }).catch(error => {console.log(error)})
}

blockBtn.addEventListener('click',async(e)=>{
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
                let blockids=[]
            checkboxes.forEach(checkbox => {
                if(checkbox.checked)
                  blockids.push(checkbox.getAttribute("data-user").split("--")[1])
            })

            console.log(blockids)
            if(blockids.length==0)
              alert("select people to block")
              else{
                 await fetch(`${API}/api/remove-user-from-bbd-dashboard`, {
                method: 'POST',
                body: JSON.stringify({"users": blockids,'token':token}),
                headers: {
                    'Content-Type': 'application/json'
                },
            })
            .then(res => res.json())
            .then((data) =>{
                console.log(data);
                alert(data.message);
                location.reload()
            })
            .catch(error => {
                if (error.response.status === 500) {
                alert('User not found');
                } else {
                console.error('Error:', error);
                }
            });
              }
})
function getMessages(date,token){
    loader.style.display = "flex";
    document.querySelector(".offcanvas-title").innerHTML=`<div>
    <div>Messages</div>
    <div class="small">From ${token}</div>
    </div>`
    // document.querySelector(".message-people-list").innerHTML=''
    // document.querySelector(".people-messages").innerHTML=''
    fetch(`${API}/api/getMessages`,{

        method: 'POST',
        body: JSON.stringify({"date": date,'token':token}),
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then(res => res.json())
        .then((data) =>{
            console.log(data)
            messagesData=data
            loader.style.display = "none";
            showMessages(messagesData,0)
        })
}
function to12HourFormat(time) {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice(1); // Remove full string match value
      time[5] = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    //console.log(time)
    return time[0]+time[1]+time[2]+" "+time[5]; // return adjusted time or original string
  }

// function to convert a link containing text into a clickable link
function linkify(text) {
    var urlRegex = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|]|www[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
    return text.replace(urlRegex, function(url) {
      if (url.startsWith("www")) {
        return `<a href="http://${url}" target="_blank">${url}</a>`;
      } else {
        return `<a href="${url}" target="_blank">${url}</a>`;
      }
    });
  }
  

function showMessages(data,userIndex){
    console.log(data[userIndex])
    let messagePeopleList=document.querySelector(".message-people-list")
    let messageList=document.querySelector(".message-list")
    let messageProfile=document.querySelector(".message-profile")
    messagePeopleList.innerHTML=''
    messageList.innerHTML=''
    messageProfile.innerHTML=''
    // document.querySelector(".message-people-list").innerHTML=''
    // document.querySelector(".people-messages").innerHTML=''
    if(data.length==0)
    {
        messageProfile.innerHTML=''
        messagePeopleList.innerHTML=`<li class="message-people-item">No people to show</li>`
        messageList.innerHTML=`<h2>no messages to show</h2>`
    }else{
        
        let markupPeople=data.map((item,index)=>
        {
           // console.log(item[index]?.msgDetails?.length>0)
            let timestamp=item.msgDetails.length>0 ? `
             <div class="message-item-timestamp">${to12HourFormat(item.msgDetails[item.msgDetails.length-1].time)},${item.msgDetails[item.msgDetails.length-1].sendDate}</div>
            `:''
            return `
            <li class="message-people-item  ${index===userIndex?"active-message-list":""}" data-userIndex="${index}">
             <div>${item.name}</div>
             ${timestamp}
            </li>`
        }
        ).join('')
        messagePeopleList.innerHTML=markupPeople
        messageProfile.innerHTML=data[userIndex]["name"]
        if(data[userIndex]?.["msgDetails"]?.length==0)
    {
        messageList.innerHTML=`<h2>no messages to show</h2>`
    }else{
        let markupMessages=`
            ${
                data[userIndex]["msgDetails"].map((item,index)=>`<li  class=${data[userIndex]["name"].trim()!=item.sender.trim()?"message-item-right":""}>
                <div class="message-item-user">${item.sender}</div>
                <div  class="message-item-timestamp">${item.sendDate},${to12HourFormat(item.time)}</div>
                <div class="message-content">${linkify(item.message)}</div>
        
            </li>`).join("")
            }
        
        `
        messageList.innerHTML=markupMessages
        messageList.scrollTo(0,messageList.scrollHeight)
    }
    }
    
    
}
getDate.addEventListener('click',()=>{  
    
    token= document.getElementById('token').value;
    const mainTable = document.querySelector(".main-table");
   const lastChild = mainTable.lastChild;
   for(let i=0;i<payload.length;i++){
    let th=document.getElementById(`th${i+1}`)
    th.innerHTML=`${payload[i].split("-").reverse().join("/")}`
        
}
   //console.log(lastChild)
    while((mainTable.lastChild).nodeName === "TR"){
        console.log("deleted")
        mainTable.removeChild(mainTable.lastChild)
    }
    const selectedDate = dateInput.value; 
    if(selectedDate && selectedDate!='')
    {console.log(selectedDate)
    updateDates(selectedDate)
    initializeTable()
    //getData(1);
}
})
btn = document.getElementById('token-button');
btn.addEventListener('click',()=>{
    token = document.getElementById('token').value;
    console.log(token);
    for(let i=0;i<payload.length;i++){
        let th=document.getElementById(`th${i+1}`)
        th.innerHTML=`${payload[i].split("-").reverse().join("/")}`
            
    }
    if(token === ''){
        alert('Please enter a token');
    }
    else{
        url = new URL(window.location);
        url.searchParams.set('token', token);
        window.history.pushState(null, '', url.toString());
        initializeTable()
        //getData();
    }
})
function getPreviousSixDates(selectedDate) {
    const currentDate = new Date(selectedDate);
    datesArray = [];
    payload = [];
    for(let i=0; i<7; i++) {
        datesArray.push(currentDate.toLocaleDateString("en-GB"));
        payload.push(currentDate.toLocaleDateString("sv-SE"))
        currentDate.setDate(currentDate.getDate() - 1);
        
    }
    for(let i=0;i<7;i++){
        {
            let th=document.getElementById(`th${i+1}`);
            th.setAttribute("data-date",payload[i])
            let d=datesArray[i].split("/")
            th.innerText = datesArray[i]
            
            if(new Date(`${d[1]}/${d[0]}/${d[2]}`).getDay()=='0')
              th.classList.add("error")
            else
            th.classList.remove("error")
        }
    }
}
  
function updateDates(selectedDate){
    getPreviousSixDates(selectedDate);
    // console.log(previousDates)
    // let array = previousDates.reverse()
    // for(let i=0;i<7;i++){
    //     {
    //         let th=document.getElementById(`th${i+1}`);
    //         let d=array[i].split("/")
    //         th.innerText = array[6-i]
            
    //         if(new Date(`${d[1]}/${d[0]}/${d[2]}`).getDay()=='0')
    //           th.classList.add("error")
    //         else
    //         th.className=''
    //     }
    // }
}
function addEntry(data,index){
    // console.log(data,data.token,data.date)
    //console.log(index)
    index=data.id
    let statusEl,lmEl,emEl,extEl,t=data.token;
    t=t.trim()
    if(t.split(" ").length==1)
    { statusEl=document.getElementById(`${data.token}--${data.date}--status`)
     lmEl=document.getElementById(`${data.token}--${data.date}--lm`)
     emEl=document.getElementById(`${data.token}--${data.date}--em`)
  extEl=document.getElementById(`${data.token}--${data.date}--ext`)
}
  if(statusEl && lmEl && emEl && extEl)
  {
      //console.log(statusEl)
    statusEl.innerHTML=` <div class="status-box">
    <div class="status">${data.status}</div>
    <select class="edit-status hide" name="status" value="${data.status}">
      <option value="A" ${data.status=='A'?'selected':''}>A</option>
      <option value="P" ${data.status=='P'?'selected':''}>P</option>
    </select>
    ${data.note ? `<div class="note--${data.date}--${index} note">${data.note}</div>`:``}
    <div class="add-note--${data.date}--${index} add-note hide">
    <textarea class="input-note" rows="5" cols="30" name="note"></textarea>
      <button class="submit-note submit-note--${data.token}--${data.date}--${index}">submit</button>
    </div>
 </div>`
   statusEl.className=`status--${data.date}--${index} ${data.status==='A' ? "error":(data.updated?"success-updated":"success")} update-status`
   statusEl.classList.add(data.date)
   statusEl.classList.add(data.token)
  
            let lmType="error";
        let lm=data.LM.split("/");
        if(+lm[0]>=25&& lm[1]===lm[2]&& lm[1]!=='0')
          lmType="success"
        else if(+lm[0]>0 || +lm[1]>0 || +lm[2]>0)
         lmType="warning";
        else
        lmType="error"
    lmEl.innerHTML=`
              <div class="lm-box">
            <div class="lm ${(userRole==='Captain' || userRole == "Admin") ? 'get-message':''}" data-date="${data.date}" data-token="${data.token}" ${(userRole==='Captain' || userRole == "Admin") && 'data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample"'} >${data.LM}</div>
           </div>
    `
  lmEl.className=`lm--${data.date}--${index} ${lmType}`
  lmEl.classList.add(data.date)
  lmEl.classList.add(data.token)
  
    emEl.innerHTML=`
    <div class="em-box">
                  <div class="em">${data.EM}</div>
               </div>
    `
  emEl.className=`em--${data.date}--${index}`
  emEl.classList.add(data.date)
  emEl.classList.add(data.token)
  
  let extType=true
  data.ext.forEach(ext=>{
    if(ext.name.includes("exe"))
     extType=extType&&ext.dur.check})
    extEl.innerHTML=`
    <div class="ext-box">
                  <div class="ext">${data.ext.map(et=>`<span>${et.name}</span>`).join(", ")}</div>
               </div>
    `
  extEl.className=`ext--${data.date}--${index} ${extType?'success':'error'}`
  extEl.classList.add(data.date)
  extEl.classList.add(data.token)
  }
   

fixStyles()
}
// function reset(id){
//     let editBtns=document.querySelectorAll(`.edit`)
//     editBtns.forEach(i=>i.classList.remove('hide'))
//     let cancelBtn=document.querySelector(`.cancel--${id}`)
//     cancelBtn.classList.add("hide")
//     let saveBtn=document.querySelector(`.save--${id}`)
//     saveBtn.classList.add("hide")
//     let status=document.querySelector(`.status--${id}`)
//     // //let location=document.querySelector(`.location--${id}`)
//     // let lm=document.querySelector(`.lm--${id}`)
//     // let em=document.querySelector(`.em--${id}`)
//     // let ext=document.querySelector(`.ext--${id}`)

//     // status.querySelector('.status').classList.remove('hide')
//     // status.querySelector('.edit-status').classList.add('hide')

//     // location.querySelector('.location').classList.remove('hide')
//     // location.querySelector('.edit-location').classList.add('hide')

//     // lm.querySelector('.lm').classList.remove('hide')
//     // lm.querySelector('.edit-lm').classList.add('hide')

//     // em.querySelector('.em').classList.remove('hide')
//     // em.querySelector('.edit-em').classList.add('hide')

//     // ext.querySelector('.ext').classList.remove('hide')
//     // ext.querySelector('.edit-ext').classList.add('hide')
// }
function load_table(rows){
   console.log("load",rows)
    for(let i=0;i<rows.length;i++)
    {
        let userMrkup=`
        <td class="slno left-sticky">
        ${userRole==="Normal"?'':`<input type="checkbox" id="todo" name="chek_box" data-user="user--${rows[i].id}"> `}
        <label for="chek_box" data-content="${i+1}">${i+1}</label>
        </td>
        <td class="name left-sticky " data-src="${rows[i].token}--${i+1}">
        <div class="user-box">
        ${rows[i].name}
        ${rows[i].captain ? `<div class="captain">${rows[i].captain}</div>`:``}
        </div>
        </td>
        <td class="location left-sticky">${rows[i].location}</td>
        <td class="token left-sticky">${rows[i].token}</td>
        `
        let blankrows='';
        for(let j=0;j<payload.length;j++)
        {
          blankrows+=`
          <td id="${rows[i].token}--${payload[j]}--status" class="${rows[i].token} ${payload[j]}"></td>
          <td id="${rows[i].token}--${payload[j]}--lm" class="${rows[i].token} ${payload[j]}"></td>
          <td id="${rows[i].token}--${payload[j]}--em" class="${rows[i].token} ${payload[j]}"></td>
          <td id="${rows[i].token}--${payload[j]}--ext" class="${rows[i].token} ${payload[j]}"></td>`
        }
        let marup=`
        <tr data-row="${rows[i].token}">
        ${userMrkup}${blankrows}</tr>
        `
       
        tableBody[0].insertAdjacentHTML("beforeend",marup)
    }
    setLoader(payload[0])
    getData()
}
document.addEventListener('click',(e)=>{
    if(e.target.closest(".col-date")){
        let el=e.target.closest(".col-date")
        let colDate=el.getAttribute("data-date")
        console.log(colDate)
        el.innerHTML=`${colDate.split("-").reverse().join("/")}`
        setLoader(colDate)
        getData(1,colDate,el.id)
    }
    if(e.target.closest(".name")){
        let el=e.target.closest(".name")
        let src=el.getAttribute("data-src")
        src=src.split("--")
        //console.log(src.split("--")[0],src.split("--")[1])
        getSpecificUserData(src[0],src[1])
        //getData(1,colDate)
    }
    if(e.target.closest(".get-message"))
    {
        let el=e.target.closest(".get-message")
        let date=el.getAttribute('data-date')
        let token=el.getAttribute('data-token')
        console.log(date,token)
        getMessages(date,token)
    }
    if(e.target.closest(".message-people-item")){
        let el=e.target.closest(".message-people-item")
        let userIndex=+el.getAttribute('data-userIndex')
        showMessages(messagesData,userIndex)
    }
    if(e.target.closest(".update-status") && (userRole==='Captain' || userRole == "Admin"))
    {
       if(!selectedEditItem)
       {
           let el=e.target.closest(".update-status")
           selectedEditItem=el.classList[0]
           console.log(el.classList[0])
           let date=el.classList[0].split("--")[1]
           let index=el.classList[0].split("--")[2]
           el.querySelector(".status").classList.add("hide")
           el.querySelector(".edit-status").classList.remove("hide")
           if(el.querySelector(`.note--${date}--${index}`))
           el.querySelector(`.note--${date}--${index}`).classList.add("hide")
           el.querySelector(`.add-note--${date}--${index}`).classList.remove("hide")
       }
       
    }
    if(e.target.closest(".submit-note")){
       let el=e.target.closest(".update-status")
       let btn=e.target.closest(".submit-note")
       let token=btn.classList[1].split("--")[1]
       let date=btn.classList[1].split("--")[2]
       let index=btn.classList[1].split("--")[3]
       let status=el.querySelector(".edit-status").value
       let note=el.querySelector(".input-note").value
       const newObj={
           "status":status,
           "note":note,
           "date":date,
           "token":token
       }
       console.log(newObj)
       if(status && note){
        fetch(`${API}/api/postDashboard`,{
        method: 'POST',
        body: JSON.stringify({newObj}),
        headers: {
            'Content-Type': 'application/json'
        },
    })
        .then((res) => {
            console.log(res)
         let status=document.querySelector(`.status--${date}--${index}`)
         status.querySelector(".status").innerHTML=newObj.status
         status.classList.remove("success");
         status.classList.remove("success-updated");
            status.classList.remove("error");
            status.classList.remove("error-updated");
            if(newObj.status==='A')
            {
               status.classList.add("error")
            }else{
               status.classList.add("success-updated");
            }
            el.querySelector(".input-note").value=""
           el.querySelector(".status").classList.remove("hide")
           el.querySelector(".edit-status").classList.add("hide")
           if(el.querySelector(`.note`))
           {
            el.querySelector(`.note`).classList.remove("hide")
            el.querySelector(`.note`).innerHTML=newObj.note
           }else{
            el.querySelector(".edit-status").insertAdjacentHTML('afterend',`<div class="note--${date}--${index} note">${newObj.note}</div>`)
           }
           el.querySelector(`.add-note`).classList.add("hide")
           selectedEditItem=null

        })
           
       }
      
    }
    if(selectedEditItem && !e.target.closest(`.${selectedEditItem}`))
   {
       let el=document.querySelector(`.${selectedEditItem}`)
       el.querySelector(".input-note").value=""
           el.querySelector(".status").classList.remove("hide")
           el.querySelector(".edit-status").classList.add("hide")
           if(el.querySelector(`.note`))
           el.querySelector(`.note`).classList.remove("hide")
           el.querySelector(`.add-note`).classList.add("hide")
           selectedEditItem=null
   }
   if(e.target.classList.contains("send-message")){
     console.log(e.target.getAttribute("data-user"))
   }
})


// document.addEventListener('change',(e)=>{
//     obj[e.target.name]=e.target.value;
//     console.log(e.target.value)
// })
//  <input class="edit-ext hide" name="ext" value="${item.ext}" />
// <input class="edit-status hide" name="status" value="${item.status}"/>

function isCSVFile(file) {
    return file.name.toLowerCase().endsWith(".csv");
}
function uploadFile()
{
    const loader = document.querySelector('.loader');
    var fileInput = document.getElementById("file_upload");
    var file = fileInput.files[0];
    if (fileInput.value === '') {
            alert('Please select a file');
            return;
    }
    else if(!isCSVFile(file)) {
            alert("Please upload a valid CSV file.");
            return;
    }
    else{
        loader.style.display = "flex";
        const reader = new FileReader();
        reader.readAsText(file);

        reader.onload = function(event) {
        const csvData = event.target.result;
          
        // Parse CSV to array of rows
        const csvRows = Papa.parse(csvData, { header: true,skipEmptyLines: true }).data;

            if (Object.keys(csvRows[0]).length != 7) {
                loader.style.display = "none";
                alert("Please upload a CSV file with correct format and refresh the page and try again");
                location.reload();
                return;
            }
            else{
                const jsonData = csvRows.map(row => {
                       return {
                            name: row['Name'],
                            token: row['token'],
                            captain: row['captain'],
                            status: row['status'],
                            type: row['type'],
                            email: row['email'],
                            location: row['location'],
                        };
                    });
        
                    // send JSON to backend API
                    fetch(`${API}/api/add-user`, {
                        method: "POST",
                        headers: {
                        "Content-Type": "application/json"
                        },
                        body: JSON.stringify(jsonData)
                    })
                    .then(response => {
                        if (response.ok) {
                        return response.blob();
                        } 
                        else if(response.status===404){
                            alert("No users found.");
                            throw new Error('No users found.');
                            location.reload();
                        }
                        else {
                            throw new Error('Network response was not ok.');
                        }
                    })
                    .then(blob => {
                        loader.style.display = "none";
                        const url = window.URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.style.display = 'none';
                        a.href = url;
                        a.download = 'users.csv';
                        document.body.appendChild(a);
                        a.click();
                        window.URL.revokeObjectURL(url);
                    })
                    .catch(error => {
                        loader.style.display = "none";
                        alert('please check correct format or server down and try again')
                        console.error('There was a problem with the fetch operation:', error);
                        location.reload();
                    });
                    };

            };
                
    }
}
document.getElementById('url_short').addEventListener('click', function() {
    window.open('urlShortner.html', '_blank');
});

document.getElementById('messaging_dashboard').addEventListener('click', function() {
    window.open('messaging-dashboard.html', '_blank');
});
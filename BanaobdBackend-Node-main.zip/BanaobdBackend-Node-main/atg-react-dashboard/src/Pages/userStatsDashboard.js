import React,{useEffect,useState} from "react";
import { Button,Container,TextField,TableCell,TableRow,TableContainer,Table,TableHead,TableBody,tableCellClasses } from "@mui/material";
import { styled } from '@mui/material/styles';
import Paper from "@mui/material/Paper";
import { userStatsData } from "../actions/userStatsActions";
import "./css/userStats.css";


const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
    border: '1px solid white'
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));

const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const UserStatsDashboard=()=>{
    return (
      
      <Container maxWidth='xl'>
        <div class="selection">
          <TextField id="date-input" label="Select a date:" type="date" defaultValue="23-03-2023" InputLabelProps={{shrink: true}}/>
          <Button variant='contained' className="custom-btn">Get</Button>
          <TextField id="token" label="Token" type="text"></TextField>
          <Button variant='contained' className="custom-btn">Get</Button>
          <div className="pagination">
            <Button variant="contained" className="prev-btn custom-btn" disabled>Prev</Button>
            <div className="current-page">Page 1</div>
            <Button variant="contained" className="next-btn custom-btn" disabled>Next</Button>
          </div>
        </div>
        <TableContainer component={Paper}>
          <Table aria-label="customized table">
            <TableHead>
              <TableRow>
                <StyledTableCell className="slno" align="right">Sl No.</StyledTableCell>
                <StyledTableCell className="name" align="right">Name</StyledTableCell>
                <StyledTableCell className="location" align="right">Location</StyledTableCell>
                <StyledTableCell className="token" align="right">Token</StyledTableCell>
                {days.map(day => (
                  <StyledTableCell key={day} align="center" colSpan={4} id={`th${day}`}>{day}</StyledTableCell>
                ))}
              </TableRow>
              <TableRow>
                <StyledTableCell className="slno"></StyledTableCell>
                <StyledTableCell className="name"></StyledTableCell>
                <StyledTableCell className="location"></StyledTableCell>
                <StyledTableCell className="token"></StyledTableCell>
                {days.map(day => (
                  <React.Fragment>
                    <StyledTableCell>Status</StyledTableCell>
                    <StyledTableCell>LM</StyledTableCell>
                    <StyledTableCell>EM</StyledTableCell>
                    <StyledTableCell>EXT</StyledTableCell>
                  </React.Fragment>
                ))}
              </TableRow>
            </TableHead>
          </Table>
        </TableContainer>
          
    </Container>
    );
}
export default UserStatsDashboard
import React, { useState, useEffect, useMemo } from 'react'
import { useNavigate} from "react-router-dom";
import { useDispatch, useSelector } from "react-redux"
import { getPlugAndPlayData } from '../actions/plug&playActions'
import Container from "@mui/material/Container";
import { Button } from '@mui/material';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { styled } from '@mui/material/styles';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  '&:last-child td, &:last-child th': {
    border: 0,
  },
}));


const PlugPlayDashboard = () => {
  const navigate = useNavigate();

  const handleEdit = () => {
    navigate("/edit-plug-n-play");
  };
  const handleLogs = () => {
    navigate("/show-log");
  };

  const [d, setd] = useState("");
  console.log(d);
  const dispatch = useDispatch();
  const [searchTerm, setSearchTerm] = useState("");
  const data = useSelector((state) => state.data);
  console.log(data)
  const isLoading = useSelector((state) => state.isLoading);
  const filteredRows = useMemo(() => {
  //  if (!searchTerm) return data;

    if (data.length > 0) {
      const attributes = Object.keys(data[0]);
      const list = [];
      for (const current of data) {
        if (JSON.stringify(current)?.toLowerCase().includes(searchTerm))
          list.push(current);
      }
      return list;
    }

    return [];
  }, [searchTerm, data]);

  useEffect(() => {
    dispatch(getPlugAndPlayData());
  }, [dispatch]);
 
  const handleRedirect = (pageURL,data) => {
      navigate(pageURL, {
        state: {
         data
        },
      });
  };
  return (
    <Container
      maxWidth='xl'
      sx={{ minWidth: 650, marginTop: 5 }}
      size='small'
      aria-label='a dense table'>
      <h1>Scraped Data</h1>
      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 700 }} aria-label='customized table'>
          <TableHead>
            <TableRow>
              <StyledTableCell>Chanel</StyledTableCell>
              <StyledTableCell align='right'>Total Crawled</StyledTableCell>
              <StyledTableCell align='right'>Total Scraped</StyledTableCell>
              <StyledTableCell align='right'>Crawled Today</StyledTableCell>
              <StyledTableCell align='right'>New Crawled</StyledTableCell>
              <StyledTableCell align='right'>Update</StyledTableCell>
              <StyledTableCell align='right'>Show Logs</StyledTableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {filteredRows?.map((d, i) => (
              <StyledTableRow
                key={i}
                onClick={() => handleRedirect("/scraping-dashboard", d)}>
                <StyledTableCell component='th' scope='row'>
                  {d.website}
                </StyledTableCell>
                <StyledTableCell align='right'>
                  {d.totalCrawled}
                </StyledTableCell>
                <StyledTableCell align='right'>
                  {d.totalScraped}
                </StyledTableCell>
                <StyledTableCell align='right'>
                  {d.scrapedToday}
                </StyledTableCell>
                <StyledTableCell align='right'>
                  {d.crawledToday}
                </StyledTableCell>
                <StyledTableCell align='right'>
                  <Button onClick={handleEdit}>Edit</Button>
                </StyledTableCell>
                <StyledTableCell align='right'>
                  <Button onClick={handleLogs}>Show Logs</Button>
                </StyledTableCell>
              </StyledTableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
  );
}

export default PlugPlayDashboard


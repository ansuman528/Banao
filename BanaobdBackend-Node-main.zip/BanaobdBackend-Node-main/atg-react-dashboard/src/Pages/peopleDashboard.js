import React, { useState, useEffect, useMemo } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import PeopleTable from "../components/PeopleTable";
import { peopleData } from "../actions/peopleAction";
import { useDispatch, useSelector } from "react-redux";
import { Box, FormControl, InputLabel, MenuItem, Select, Typography,Container } from "@mui/material";
const PeopleStatsDashboard = () => {
  const [fetch_status, setnum] = useState("0");

  const handleChange = (e) => {
    e.preventDefault();
    setnum(e.target.value);
  };

  const [searchTerm, setSearchTerm] = useState("");
  const dispatch = useDispatch();
  const data = useSelector((state) => state.data);
  let info = data.data
  console.log(info);
  const isLoading = useSelector((state) => state.isLoading);
  let content;

  const filteredRows = useMemo(() => {
    setSearchTerm(searchTerm.toLowerCase());
    if (!searchTerm) return 0;
    if (info.length > 0) {
      const attributes = Object.keys(info[0]);
      //console.log(attributes);
      const list = [];

      for (const current of info) {
        if (JSON.stringify(current)?.toLowerCase().includes(searchTerm))
          list.push(current);
      }
      return list;
    }

    return [];
  }, [searchTerm, info]);

  if (isLoading) {
    content = (
      <Box sx={{ display: "flex", justifyContent: "center" }}>
        <CircularProgress />
      </Box>
    );
  }

  if (!isLoading && !info) {
    content = <p>Nothing to show, data list is empty</p>;
  }

  if (!isLoading && info) {
    content = <PeopleTable key={info.country_code} info={info} filteredRows={filteredRows}></PeopleTable>;
  }

  useEffect(() => {
    dispatch(peopleData(fetch_status));
  }, [dispatch,fetch_status]);
 return (
   <Container maxWidth='xl'>
       <div>
         <div>
           <Typography
             style={{
               textAlign: "center",
               textTransform: "uppercase",
               fontWeight: "700",
               margin: "1rem",
             }}>
             People DashBoard
           </Typography>
           <div
             style={{
               display: "flex",
               alignItems: "center",
               justifyContent: "space-between",
             }}>
             <Box sx={{ minWidth: 120, marginTop: "1rem", marginLeft: "1rem" }}>
               <FormControl sx={{ minWidth: 120 }}>
                 <InputLabel id='demo-simple-select-label'>
                   Fetch_Status
                 </InputLabel>
                 <Select
                   labelId='demo-simple-select-label'
                   id='demo-simple-select'
                   value={fetch_status}
                   label='Fetch_Status'
                   onChange={handleChange}>
                   <MenuItem value={"0"}>0</MenuItem>
                   <MenuItem value={"1"}>1</MenuItem>
                   <MenuItem value={"2"}>2</MenuItem>
                 </Select>
               </FormControl>
             </Box>
             <div style={{ width: "25%", marginRight: "0.2rem" }}>
               <input
                 type='text'
                 placeholder='Search'
                 className='form-control'
                 style={{ padding: "1rem" }}
                 onChange={(e) => setSearchTerm(e.target.value)}
               />
             </div>
           </div>
           <div style={{ marginTop: "1.1rem", marginBottom: "1.1rem" }}>
             {content}
           </div>
         </div>
       </div>
   </Container>)
};
export default PeopleStatsDashboard;

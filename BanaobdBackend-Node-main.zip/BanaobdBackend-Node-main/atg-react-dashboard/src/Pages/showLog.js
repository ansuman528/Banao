import { Button } from "@mui/material";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import React from "react";
import SyntaxHighlighter from "react-syntax-highlighter";
import { docco } from "react-syntax-highlighter/dist/esm/styles/hljs";
const showLog = () => {
  const codeString = `src\\Pages\\plug&playDashboard.js
  Line 3:8:    'axios' is defined but never used                no-unused-vars
  Line 18:17:  'attributes' is assigned a value but never used  no-unused-vars

src\\components\\header.js
  Line 6:8:   'Typography' is defined but never used    no-unused-vars
  Line 7:8:   'Button' is defined but never used        no-unused-vars
  Line 15:8:  'ListItemIcon' is defined but never used  no-unused-vars

webpack compiled with 1 warning`;
  return (
    <div>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          margin: "1rem",
        }}>
        <h4>LOGS</h4>
        <Button variant='contained'><PlayArrowIcon/>Run</Button>
      </div>
      <div style={{ margin: "1rem" }}>
        <SyntaxHighlighter language='javascript' style={docco}>
          {codeString}
        </SyntaxHighlighter>
      </div>
    </div>
  );
};

export default showLog;

export {default as Login} from "./login"
export {default as Home} from "./home"
export {default as UserStatsDashboard} from "./userStatsDashboard"
export {default as PeopleStatsDashboard} from "./peopleDashboard"
export {default as ScrappingDashboard} from "./scrapingDashboard"
export {default as PlugPlayDashboard} from './plug&playDashboard'
export {default as ShowLog} from './showLog'
export {default as Edit_Plug_n_Play} from './editPlug_n_Play'

import { useState } from 'react'
import '../Pages/css/home.css'
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import Button from '@mui/material/Button';
import { spacing, Stack } from '@mui/system';
import useMediaQuery from '@mui/material/useMediaQuery';

const Edit_Plug_n_Play = () => {
    const dataTypeList = [{ label: "Const", value: "1" }, { label: "String", value: "2" }]
    const [formData, setFormData] = useState({
        addWebsite: "",
        name: "",
        priority: "",
        startingUrl: "",
        detailsUrl: "",
        paginationElement: ""
    })
    const [DataType, setDataType] = useState('');
    const [booleanValue, setBoolenValue] = useState('')
    const [Data, setData] = useState([{ dataType: "", customDataType: "" }])

    const handleDatatypeAdd = () => {
        setData([...Data, { dataType: "", customDataType: "" }])
        console.log(Data)
    }
    const handleDataChanged = (e, index) => {
        const { name, value } = e.target;
        const list = [...Data];
        list[index][name] = value;
        setData(list);
    }
    const handleDatatypeRemove = (index) => {
        const list = [...Data]
        list.splice(index, 1);
        setData(list)
    }
    const matches = useMediaQuery('(min-width:600px)');
    // const handleChange = (event) => {
    //     const data = event.target.value
    //     setDataType(data)
    //     if (event.target.value) {
    //         setBoolenValue(true)

    //     } else {
    //         setBoolenValue(false)
    //     }
    // };
    let name, value
    const Eventchange = (event) => {
        name = event.target.name;
        value = event.target.value
        setFormData({ ...formData, [name]: value })
        console.log(formData.name)
    }
    const formSubmitted = async (e) => {
        e.preventDefault()
        console.log(formData)
        console.log(Data)
    }
    return (
        <div>
            <h1>Edit Plug & Play Scraping</h1>
            <span>{`(min-width:600px) matches: ${matches}`}</span>;
            <form onSubmit={formSubmitted}>
                <TextField sx={{ width: 300, alignContent:'center' , marginLeft:100 ,paddingBottom:3}}  id="outlined-basic" name="addWebsite" label="Add Website" className='btn-space' variant="outlined" value={formData.addWebsite} onChange={Eventchange} required />
                <TextField sx={{ width: 300, alignContent:'center' , marginLeft:100,paddingBottom:3}}   id="outlined-basic" name="name" label="Name" className='btn-space' variant="outlined" value={formData.name} onChange={Eventchange} />
                <TextField sx={{ width: 300, alignContent:'center' , marginLeft:100 , paddingBottom:3}}  id="outlined-basic" name="priority" label="Priority" variant="outlined" value={formData.priority} onChange={Eventchange} />
                <TextField sx={{ width: 300, alignContent:'center' , marginLeft:100 , paddingBottom:3}}  id="outlined-basic" name="startingUrl" label="Starting URL" variant="outlined" value={formData.startingUrl} onChange={Eventchange} />
                <TextField sx={{ width: 300, alignContent:'center' , marginLeft:100 , paddingBottom:3}}  id="outlined-basic" name="detailsUrl" label="Details URL Element" variant="outlined" value={formData.detailsUrl} onChange={Eventchange} />
                <TextField sx={{ width: 300, alignContent:'center' , marginLeft:100 , paddingBottom:3}} id="outlined-basic" name="pythonScript" label="Python Script" variant="outlined" value={formData.pythonScript} onChange={Eventchange} />
                <TextField sx={{ width: 300, alignContent:'center' , marginLeft:100 ,paddingBottom:3}} id="outlined-basic" name="paginationElement" label="Pagination Element" variant="outlined" value={formData.paginationElement} onChange={Eventchange} />
                {Data.map((datatype, index) =>
                    <div key={index}  >
                        <Stack spacing={2} direction="row"  >
                            <FormControl sx={{ width: 220, marginLeft: 80 ,paddingBottom:3}}  >
                                <InputLabel id="demo-simple-select-label">DataType</InputLabel>
                                <Select
                                    labelId="demo-simple-select-label"
                                    id="demo-simple-select"
                                    name="dataType"
                                    value={Data.dataType}
                                    label="Data Type"
                                    onChange={(e) => handleDataChanged(e, index)}
                                >{dataTypeList.map(item =>
                                    <MenuItem value={item.value}>{item.label}</MenuItem>
                                )}
                                </Select>
                            </FormControl>
                            {/* {
                                        booleanValue && <input type="text" />
                        } */}
                         
                            <TextField sx={{ width: 220  }} id="outlined-basic" name="customDataType" label="Custom Data Type" variant="outlined" value={Data.customDataType} onChange={(e) => handleDataChanged(e, index)} />
                            <Button sx={{ width: 220, height: 55 ,lineHeight:2 }} variant="contained" onClick={() => handleDatatypeRemove(index)} name="remove" color='error'>Remove</Button>
                        </Stack>
                    </div>
                )}
                
                    <Button sx={{marginRight : 2 ,marginLeft:100}} variant="contained" onClick={handleDatatypeAdd} name="add">Add New Row</Button>
                    <Button   sx={{}}  variant="contained" type='submit' name="add">Submit</Button>
           
            </form>
        </div>
    )
}
export default Edit_Plug_n_Play 
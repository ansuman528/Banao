import GraphDisplay from "../components/GraphDisplay";
import DataTable from "../components/DataTable"
import { Button,Container } from "@mui/material";
import { useLocation } from "react-router-dom";
const ScrappingDashboard = () => {
  let location = useLocation()
  console.log(location.state)
  return (
    <Container maxWidth='xl'>
      <div>
        <div style={{
          margin:"2rem",
          textAlign: "center"
        }}>
          <h3>WEB DETAILS</h3>
        </div>
        <div
          style={{
            display: "flex",
            justifyContent:"center",
            gap: "1rem",
            marginBottom:'15px'
          }}>
          <Button variant='contained'>Test</Button>
          <Button variant='contained'>Edit</Button>
          <Button variant='contained'>Sample Data</Button>
          <Button variant='contained'>Run now</Button>
        </div>
      </div>
      <DataTable data={location.state}></DataTable>
      <div style={{ display: "flex", justifyContent: "center" }}>
        <GraphDisplay> </GraphDisplay>
      </div>
    </Container>
  );
};
export default ScrappingDashboard;

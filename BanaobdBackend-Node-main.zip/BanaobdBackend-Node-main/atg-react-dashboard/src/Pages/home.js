import { useState, useEffect } from 'react'
import '../Pages/css/home.css'
import TextField from '@mui/material/TextField';
import InputLabel from '@mui/material/InputLabel';
import { MenuItem, FormControl, Container, unstable_composeClasses } from '@mui/material';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import Button from '@mui/material/Button';
import { useDispatch } from "react-redux";
import { addWebsiteScrapedData } from '../actions/plug&playActions'
import { useNavigate } from 'react-router-dom'

const Home = () => {
    const dispatch = useDispatch();
    const navigate = useNavigate();

    const dataTypeList = [{ label: "Const", value: "1" }, { label: "String", value: "2" }]
    const [formData, setFormData] = useState({
        url: "",
        name: "",
        priority: "", //number
        scrapping_frquency: "", //number
        starting_url: "",
        py_script: "",
        url_element: "",
        pagination_element: ""
    })
    const [DataType, setDataType] = useState('');
    const [booleanValue, setBoolenValue] = useState('')
    const [dataTypeData, setDataTypeData] = useState(
        [{
            dataType: "",
            customDataType: ""
        }])

    const handleDatatypeAdd = () => {
        setDataTypeData([...dataTypeData, { dataType: "", customDataType: "" }])
        // console.log(Data)
    }
    const handleDataChanged = (e, index) => {
        const { name, value } = e.target;
        const list = [...dataTypeData];
        list[index][name] = value;
        setDataTypeData(list);
    }

    let name, value
    const Eventchange = (event) => {
        name = event.target.name;
        value = event.target.value
        setFormData({ ...formData, [name]: value })
    }

    const handleDatatypeRemove = (index) => {
        const list = [...dataTypeData]
        list.splice(index, 1);
        setDataTypeData(list)
    }

    const formSubmitted = async (e) => {
        e.preventDefault()
        let dataType = []
        dataTypeData.forEach((data) => {
            console.log(data)
            if (Object.keys(data).length > 0) {
                console.log("Empty")
                dataType.pop()
            } else {
                dataType.push()
                console.log(data)
            }
        });
        let form = formData
        form.data = dataTypeData
        console.log(form)

        if (dispatch(addWebsiteScrapedData(form, navigate))) {
            navigate('/user-stats-dashboard')
        } else {
            alert('error')
        }
    }
    return (
        <Container maxWidth='xl'>
            <h1>Plug & Play Scraping</h1>
            <form onSubmit={formSubmitted} >
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gridGap: '50px' }}>
                    <TextField id="outlined-basic" name="url" label="Add Website" className='btn-space' variant="outlined" value={formData.url} onChange={Eventchange} required />
                    <TextField id="outlined-basic" name="name" label="Name" className='btn-space' variant="outlined" value={formData.name} onChange={Eventchange} required/>
                    <TextField id="outlined-basic" name="priority" label="Priority" variant="outlined" value={formData.priority} onChange={Eventchange} />
                    <TextField id="outlined-basic" name="scrapping_frquency" label="Scrapping Frequency" variant="outlined" value={formData.scrapping_frquency} onChange={Eventchange} />
                    <TextField id="outlined-basic" name="starting_url" label="Starting URL" variant="outlined" value={formData.starting_url} onChange={Eventchange} />
                    <TextField id="outlined-basic" name="py_script" label="Python Script" variant="outlined" value={formData.py_script} onChange={Eventchange} />
                    <TextField id="outlined-basic" name="url_element" label="Url Element" variant="outlined" value={formData.url_element} onChange={Eventchange} />
                    <TextField id="outlined-basic" name="pagination_element" label="Pagination Element" variant="outlined" value={formData.pagination_element} onChange={Eventchange} />

                </div>
                {dataTypeData.map((datatype, index) =>
                    <div key={index} style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '50px', margin: '50px 0' }}>

                        <FormControl sx={{ width: 220, }}  >
                            <InputLabel id="demo-simple-select-label">DataType</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                name="dataType"
                                value={dataTypeData.dataType}
                                label="Data Type"
                                onChange={(e) => handleDataChanged(e, index)}
                            >{dataTypeList.map((item, index) =>
                                <MenuItem key={`item-${index}`} value={item.value}>{item.label}</MenuItem>
                            )}
                            </Select>
                        </FormControl>

                        <TextField id="outlined-basic" name="customDataType" label="Custom Data Type" variant="outlined" value={dataTypeData.customDataType} onChange={(e) => handleDataChanged(e, index)} />
                        <Button variant="contained" onClick={() => handleDatatypeRemove(index)} name="remove" color='error'>Remove</Button>

                    </div>
                )}
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '50px' }}>
                    <Button variant="contained" onClick={handleDatatypeAdd} name="add">Add New Row</Button>
                    <Button variant="contained" type='submit' name="add">Submit</Button>

                </div>

            </form>
        </Container>
    )
}
export default Home
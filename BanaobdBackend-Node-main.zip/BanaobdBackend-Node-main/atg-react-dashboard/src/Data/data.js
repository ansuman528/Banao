export const UserData = [{
        id: 1,
        date: "1/1/2023",
        Scraped_per_day: 80000,
        Crawled_per_day: 823,
        New_Per_day: 20
    },
    {
        id: 2,
        date: "2/2/2023",
        Scraped_per_day: 81000,
        Crawled_per_day: 820003,
        New_Per_day: 200
    },
    {
        id: 3,
        date: "3/2/2023",
        Scraped_per_day: 1056616,
        Crawled_per_day: 231121,
        New_Per_day: 203
    },
    {
        id: 4,
        date: "4/2/2023",
        Scraped_per_day: 800,
        Crawled_per_day: 82,
        New_Per_day: 15
    },
    {
        id: 5,
        date: "5/2/2023",
        Scraped_per_day: 80,
        Crawled_per_day: 823,
        New_Per_day: 10
    },
];
import * as actionType from "./../helpers/constants";
const initialState = {
  profile: null,
    isLoading:false,
    data:[],
}
const reducer = (state = initialState, action) => {
    switch (action.type) 
    {
      case actionType.SET_LOADING:
        return {...state,isLoading:action.payload}
      case actionType.SET_DATA:
        return {...state,data:action.payload}
        case actionType.SET_PROFILE:
          localStorage.setItem("profile",JSON.stringify(action.payload))
          return {...state, profile:action.payload}
      default:
        return {
        ...state,
        profile:JSON.parse(localStorage.getItem('profile'))
      };
    }
}
export default reducer;
import * as React from "react";
import { styled } from "@mui/material/styles";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell, { tableCellClasses } from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.black,
    color: theme.palette.common.white,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
  },
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

let rows = [
];

export default function DataTable({data}) {
  rows = []
  rows.push(data.data);
  console.log(rows)
  return (
    <TableContainer component={Paper}>
      <Table aria-label='customized table'>
        <TableHead>
          <TableRow>
            <StyledTableCell>Chanel</StyledTableCell>
            <StyledTableCell align='right'>Total Crawled</StyledTableCell>
            <StyledTableCell align='right'>Total Scraped</StyledTableCell>
            <StyledTableCell align='right'>Crawled Today</StyledTableCell>
            <StyledTableCell align='right'>New Crawled</StyledTableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <StyledTableRow key={row.website}>
              <StyledTableCell component='th' scope='row'>
                {row.website}
              </StyledTableCell>
              <StyledTableCell align='right'>
                {row.totalCrawled}
              </StyledTableCell>
              <StyledTableCell align='right'>
                {row.totalScraped}
              </StyledTableCell>
              <StyledTableCell align='right'>
                {row.scrapedToday}
              </StyledTableCell>
              <StyledTableCell align='right'>
                {row.crawledToday}
              </StyledTableCell>
            </StyledTableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}

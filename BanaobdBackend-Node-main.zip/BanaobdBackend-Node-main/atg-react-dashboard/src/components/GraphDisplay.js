import React, { useState } from "react";
import Graph from "./Graph";
import { UserData } from "../Data/data";

const GraphDisplay = () => {
  const [userData, setUserData] = useState({
    labels: UserData.map((data) => data.date),
    datasets: [
      {
        label: "Scraped per day",
        data: UserData.map((data) => data.Scraped_per_day),
        backgroundColor: [
          "rgba(75,192,192,1)",
          "#ecf0f1",
          "#50AF95",
          "#f3ba2f",
          "#2a71d0",
        ],
        borderColor: "black",
        borderWidth: 2,
      },
      {
        label: "Crawled per day",
        data: UserData.map((data) => data.Crawled_per_day),
        backgroundColor: [
          "rgba(75,192,192,1)",
          "#ecf0f1",
          "#50AF95",
          "#f3ba2f",
          "#2a71d0",
        ],
        borderColor: "black",
        borderWidth: 2,
      },
      {
        label: "New Per day",
        data: UserData.map((data) => data.New_Per_day),
        backgroundColor: [
          "rgba(75,192,192,1)",
          "#ecf0f1",
          "#50AF95",
          "#f3ba2f",
          "#2a71d0",
        ],
        borderColor: "black",
        borderWidth: 2,
      },
    ],
  });

  return (
    <div>
      <div
        style={{
          width: 700,
          marginTop: "50px",
          marginBottom: "50px",
        }}>
        <Graph chartData={userData} />{" "}
      </div>
    </div>
  );
};

export default GraphDisplay;

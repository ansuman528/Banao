import React,{useState} from 'react'
import { useNavigate } from "react-router-dom";
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import Link from '@mui/material/Link';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';
import { useDispatch, useSelector } from "react-redux";
import * as actionType from "../helpers/constants";

const Header=()=>{
    const navigate = useNavigate();
    const dispatch = useDispatch();
const handleLogout = ()=> {
  dispatch({type:actionType.SET_PROFILE, payload:null})
localStorage.removeItem('token');
  navigate("/login")
}
    const [drwarerState, setDrawerState] = useState(false)
    const pages=[
        {
            name:'People Dashboard',
            link:'/people-dashboard'
        },
        {
            name:'User Stats Dashboard',
            link:'/user-stats-dashboard'
        },
        // {
        //     name:'Scraping Dasboard',
        //     link:'/scraping-dashboard'
        // },
        {
          name:'Plug and Play Dasboard',
          link:'/plug-n-play-dashboard'
      }
    ]
    let user = useSelector(state=>state.profile)

    return (
      <AppBar position='static'>
        <Toolbar>
          <IconButton
            size='large'
            edge='start'
            color='inherit'
            aria-label='menu'
            sx={{ mr: 2 }}
            onClick={() => setDrawerState(true)}>
            <MenuIcon />
          </IconButton>
          <Link href='/' underline='none' color='inherit' sx={{ flexGrow: 1 }}>
            ATG Dashboard
          </Link>
          {user ? (
            <Link style={{cursor:'pointer'}} underline='none' color='inherit' onClick={handleLogout}>
              LOGOUT
            </Link>
          ) : (
            <Link href='/login' underline='none' color='inherit'>
              Login
            </Link>
          )}
        </Toolbar>
        <Drawer
          anchor='left'
          open={drwarerState}
          onClose={() => setDrawerState(false)}>
          <Box
            sx={{ width: 250 }}
            role='presentation'
            onClick={() => setDrawerState(false)}
            onKeyDown={() => setDrawerState(false)}>
            <List>
              {pages.map((item, index) => (
                <ListItem key={item.name} disablePadding>
                  <ListItemButton onClick={() => navigate(item.link)}>
                    {/* <ListItemIcon>
                        {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
                    </ListItemIcon> */}
                    <ListItemText primary={item.name} />
                  </ListItemButton>
                </ListItem>
              ))}
            </List>
          </Box>
        </Drawer>
      </AppBar>
    );
}
export default Header
import React from "react"
import { BrowserRouter, Routes, Route,Navigate} from "react-router-dom";
import {useSelector} from "react-redux"
import {Login,Home,UserStatsDashboard,PeopleStatsDashboard,ScrappingDashboard ,PlugPlayDashboard,ShowLog ,Edit_Plug_n_Play} from "./Pages"
import {Header} from "./components"
import CssBaseline from '@mui/material/CssBaseline';
import { ToastContainer } from "react-toastify";
import 'react-toastify/dist/ReactToastify.css';
import './App.css';
const App=()=>{
   const profile=useSelector(state=>state.profile)
   return (
     <BrowserRouter>
       <CssBaseline />
       <ToastContainer />
       <Header />
       <Routes>
         <Route
           path='/people-dashboard'
           element={profile !== "null" && profile ? <PeopleStatsDashboard /> : <Login />}
         />
         <Route
           path='/show-log'
           element={profile !== "null" && profile ? <ShowLog /> : <Login />}
         />
         <Route
           path='/user-stats-dashboard'
           element={profile !== "null" && profile ? <UserStatsDashboard /> : <Login />}
         />
         <Route
           path='/scraping-dashboard'
           element={profile !== "null" && profile ? <ScrappingDashboard /> : <Login />}
         />
         <Route
           path='/plug-n-play-dashboard'
           element={profile !== "null" && profile ? <PlugPlayDashboard /> : <Login />}
         />
         <Route
           path='/login'
           element={profile !== "null" && profile ? <Navigate replace to='/' /> : <Login />}
         />
         <Route
           path='/'
           element={
             profile !== "null" && profile ? <Home /> : <Navigate replace to='/login' />
           }
         />
       </Routes>
     </BrowserRouter>
   );
}
export default App
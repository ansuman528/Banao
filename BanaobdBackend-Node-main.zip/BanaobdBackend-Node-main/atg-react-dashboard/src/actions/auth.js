import {postData} from './index.js'
import * as actionType from "../helpers/constants"
import { notify } from '../helpers/utils.js';
export const login = (data) => async (dispatch)=>{
try {
  console.log(data)
            postData(
              `${process.env.REACT_APP_DASHBOARD_API}/plug&play/login`,
              data
            ).then((result) => {
              console.log(result);
              if (result.message === false) {
                console.log(result);
              } else {
                notify("success", "Welcome");
                dispatch({
                  type: actionType.SET_PROFILE,
                  payload: result.message,
                });
              }
            });
} catch (err) {
    console.log(err)
}
};
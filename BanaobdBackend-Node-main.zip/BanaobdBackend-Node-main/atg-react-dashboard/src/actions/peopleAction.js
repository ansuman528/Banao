import * as actionType from "../helpers/constants";
import { notify } from "../helpers/utils";
import { postData } from "./index";

export const peopleData = (fetch_status) => async (dispatch) => {
  try {
    dispatch({ type: actionType.SET_LOADING, payload: true });
    await postData(`${process.env.REACT_APP_DASHBOARD_API}/reactdisplayPeopleStat`,{ fetch_status }).then((data) => {
      console.log(data);
      dispatch({ type: actionType.SET_DATA, payload: data});
      dispatch({ type: actionType.SET_LOADING, payload: false });
    });
  } catch (error) {
    console.log(error);
    dispatch({ type: actionType.SET_LOADING, payload: false });
    notify("error", error.message);
  }
};

import React, { useState, useRef, useEffect } from 'react';

export const UserStatsData = () => {
  const [datesArray, setDatesArray] = useState([]);
  const [payload, setPayload] = useState([]);
  const [token, setToken] = useState('');
  const [userRole, setUserRole] = useState('');
  const [messagesData, setMessagesData] = useState([]);
  const [selectedEditItem, setSelectedEditItem] = useState(null);

  let API="http://localhost:8000";
  // let API="https://bbd.atg.party";
  
  const dateInput = useRef(null);
  const getDate = useRef(null);
  const tableBody = useRef(null);
  const loader = useRef(null);
  const nextBtn = useRef(null);
  const prevBtn = useRef(null);

  const slCol = useRef([]);
  const nameCol = useRef([]);
  const locationCol = useRef([]);
  const tokenCol = useRef([]);
  
  useEffect(() => {
    const url = new URL(window.location);
    const token = url.searchParams.get('token');
    setToken(token);
    // fixStyles();
    // if (token) {
    //   getData(1);
    // }
  }, []);

//   function fixStyles() {
    
//   }
  
}
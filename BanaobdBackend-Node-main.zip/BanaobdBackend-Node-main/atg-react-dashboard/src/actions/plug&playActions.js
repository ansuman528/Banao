import * as actionType from "../helpers/constants"
import { NEW_SCRAPTDATA_REQUEST, NEW_SCRAPTDATA_FAIL } from "../helpers/constants"
import { notify } from "../helpers/utils";
import { getData, postData } from "./index"
import {  useNavigate } from 'react-router-dom'


export const getPlugAndPlayData = () => async (dispatch) => {
  
  try {
    notify("info", "Loading . . .")
    dispatch({ type: actionType.SET_LOADING, payload: true })
      let tok = localStorage.getItem("token");
      await postData(
        `${process.env.REACT_APP_DASHBOARD_API}/plug&play/display_dashboard`,{token:tok}
      ).then((data) => {
        console.log(data);
        dispatch({ type: actionType.SET_DATA, payload: data });
        dispatch({ type: actionType.SET_LOADING, payload: false });
      });
  } catch (error) {
    console.log(error)
    dispatch({ type: actionType.SET_LOADING, payload: false })
    notify("error", error.message)
  }
}

export const addWebsiteScrapedData = (data , navigate) => async (dispatch) => {
  try {
    let url = `${process.env.REACT_APP_DASHBOARD_API}/plug&play/save-company-details`;
    await postData(url, data ).then((data) => {
      console.log(data)
      if(data.status == 200){
       notify("success", data.message)
        navigate('/home')
      }else{
        notify("error", data.message)
      }
    })
  } catch (error) {
    console.log(error)
    dispatch({ type: actionType.SET_LOADING, payload: false })
    notify("error", error.message)
  };
}

import axios from "axios";

let token=JSON.parse(localStorage.getItem("profile"))?.token
export const getData=async(url = '')=>{
    
    const response = await fetch(url, {
      method: 'GET', 
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `${token?`Bearer ${token}`:''}`
      },
    });
    //console.log(response)
    return response.json(); 
  }
export const postData=async(url = '', data={})=>{
    const response = await fetch(url, {
      method : "POST",
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `${token?`Bearer ${token}`:''}`
      },
      body: JSON.stringify(data)
    });
    console.log(response)
    return response.json();
  }

